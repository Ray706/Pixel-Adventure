import assert from "node:assert/strict";
import { access, readFile } from "node:fs/promises";
import { Game } from "../src/game.js";
import { InputController } from "../src/input.js";
import { intersects, moveBody, movePolygon, polygonIntersectsRect } from "../src/physics.js";
import { Renderer, wallSlideVisualNudge, wallSpriteOffset } from "../src/render.js";
import { ENTITY_TEMPLATES, buildCustomLevelExport, readCustomLevels, saveCustomLevel, serializeEntity, validateEntity, validateEntityList } from "../src/editor.js";

class MemoryStorage {
  values = new Map();
  getItem(key) { return this.values.get(key) ?? null; }
  setItem(key, value) { this.values.set(key, String(value)); }
  clear() { this.values.clear(); }
}

class EventHub {
  listeners = new Map();
  addEventListener(type, listener) {
    const handlers = this.listeners.get(type) ?? [];
    handlers.push(listener);
    this.listeners.set(type, handlers);
  }
  dispatchEvent(event) {
    for (const listener of this.listeners.get(event.type) ?? []) listener(event);
    return true;
  }
}

class ControlButton extends EventHub {
  constructor(control) {
    super();
    this.dataset = { control };
  }
  setPointerCapture() {}
}

function inputEvent(type, values = {}) {
  return { type, ...values, preventDefault() { this.defaultPrevented = true; } };
}

function testPhysics() {
  const floor = { left: -2, right: 2, bottom: 0, top: 1 };
  const landingBody = { x: 0, y: 2, halfWidth: 0.35, bottomOffset: -1, topOffset: 0.5 };
  const landing = moveBody(landingBody, 0, -0.5, [floor], [], () => {});
  assert.equal(landing.grounded, true, "downward movement lands on solid terrain");
  assert.equal(landingBody.y, 2, "landing resolves to the terrain top");

  const wallBody = { x: 0, y: 2, halfWidth: 0.35, bottomOffset: -1, topOffset: 0.5 };
  const wall = moveBody(wallBody, 1, 0, [{ left: 1, right: 2, bottom: 0, top: 3 }], [], () => {});
  assert.equal(wall.wall, 1, "horizontal movement detects a right wall");
  assert.equal(wallBody.x, 0.65, "wall contact resolves without overlap");
  const wallSlide = moveBody(wallBody, 0, -0.1, [{ left: 1, right: 2, bottom: 0, top: 3 }], [], () => {});
  assert.equal(wallSlide.wall, 1, "wall contact persists while the body slides downward without horizontal input");
  assert.equal(wallSlide.wallRect.left, 1, "wall-slide contact retains the actual wall plane");

  let ceilingHit = false;
  const ceilingBody = { x: 0, y: 0, halfWidth: 0.35, bottomOffset: -1, topOffset: 0.5 };
  const ceiling = moveBody(ceilingBody, 0, 0.75, [{ left: -2, right: 2, bottom: 1, top: 2 }], [], () => { ceilingHit = true; });
  assert.equal(ceiling.ceiling, true, "upward movement detects a solid ceiling");
  assert.equal(ceilingHit, true, "ceiling callback fires for box interactions");

  const oneWayBody = { x: 0, y: 0, halfWidth: 0.35, bottomOffset: -1, topOffset: 0.5 };
  const platform = { left: -2, right: 2, bottom: 1, top: 1.25, oneWay: true };
  const upward = moveBody(oneWayBody, 0, 1, [], [platform], () => {});
  assert.equal(upward.grounded, false, "one-way platforms do not block upward movement");
  assert.equal(intersects({ left: 0, right: 1, bottom: 0, top: 1 }, { left: 1, right: 2, bottom: 0, top: 1 }), false, "touching edges are not overlaps");

  const polygon = [[-1, -1], [1, -1], [1, 1], [-1, 1]];
  assert.equal(polygonIntersectsRect(polygon, 0, 0, { left: 1, right: 2, bottom: -0.5, top: 0.5 }), false, "touching polygon edges remain non-overlapping");
  const polygonBody = { x: 0, y: 0 };
  const polygonMove = movePolygon(polygonBody, 2, 0, polygon, [{ left: 1, right: 2, bottom: -0.5, top: 0.5 }], () => {});
  assert.equal(polygonMove.wall, 1, "actual convex collider geometry stops at a tile edge");
  assert.ok(polygonBody.x <= 0.001, "swept polygon collision prevents tunneling through a wall");
}

function testInput() {
  const root = new EventHub();
  const buttons = ["left", "right", "jump"].map((name) => new ControlButton(name));
  root.querySelectorAll = () => buttons;
  const windowTarget = new EventHub();
  globalThis.window = windowTarget;
  let pauseCalls = 0;
  const input = new InputController(root, () => pauseCalls++);

  windowTarget.dispatchEvent(inputEvent("keydown", { code: "ArrowLeft", repeat: false }));
  assert.equal(input.read().move, -1, "keyboard moves left");
  windowTarget.dispatchEvent(inputEvent("keyup", { code: "ArrowLeft" }));
  windowTarget.dispatchEvent(inputEvent("keydown", { code: "Space", repeat: false }));
  assert.equal(input.read().jumpPressed, true, "keyboard jump is edge-triggered");
  assert.equal(input.read().jumpPressed, false, "jump press is consumed once");
  windowTarget.dispatchEvent(inputEvent("keyup", { code: "Space" }));

  const selectTarget = { closest(selector) { return selector.includes("select") ? this : null; } };
  const selectArrow = inputEvent("keydown", { code: "ArrowDown", repeat: false, target: selectTarget });
  windowTarget.dispatchEvent(selectArrow);
  assert.equal(input.read().move, 0, "focused selects do not receive gameplay movement");
  assert.equal(selectArrow.defaultPrevented, undefined, "focused selects keep native arrow-key behavior");
  const buttonTarget = { closest() { return this; } };
  const buttonSpace = inputEvent("keydown", { code: "Space", repeat: false, target: buttonTarget });
  windowTarget.dispatchEvent(buttonSpace);
  const buttonSpaceUp = inputEvent("keyup", { code: "Space", target: buttonTarget });
  windowTarget.dispatchEvent(buttonSpaceUp);
  assert.equal(input.read().jumpPressed, false, "focused buttons do not trigger gameplay jump");
  assert.equal(buttonSpace.defaultPrevented, undefined, "focused buttons keep native Space activation");
  assert.equal(buttonSpaceUp.defaultPrevented, undefined, "focused button keyup remains native");
  windowTarget.dispatchEvent(inputEvent("keydown", { code: "Escape", repeat: false }));
  assert.equal(pauseCalls, 1, "Escape toggles pause globally");

  buttons[0].dispatchEvent(inputEvent("pointerdown", { pointerId: 1 }));
  buttons[1].dispatchEvent(inputEvent("pointerdown", { pointerId: 2 }));
  assert.equal(input.read().move, 0, "opposite touch directions cancel");
  buttons[0].dispatchEvent(inputEvent("pointerup", { pointerId: 1 }));
  assert.equal(input.read().move, 1, "releasing one touch keeps the other held");
  windowTarget.dispatchEvent(inputEvent("pointerup", { pointerId: 2 }));
  assert.equal(input.read().move, 0, "window-level pointerup clears a captured direction touch");
  buttons[1].dispatchEvent(inputEvent("pointerdown", { pointerId: 5 }));
  windowTarget.dispatchEvent(inputEvent("pointercancel", { pointerId: 5 }));
  assert.equal(input.read().move, 0, "window-level pointercancel clears a cancelled direction touch");
  buttons[2].dispatchEvent(inputEvent("pointerdown", { pointerId: 3 }));
  assert.equal(input.read().jumpPressed, true, "touch jump is edge-triggered");
  buttons[2].dispatchEvent(inputEvent("pointerup", { pointerId: 3 }));
  buttons[2].dispatchEvent(inputEvent("pointerdown", { pointerId: 4 }));
  windowTarget.dispatchEvent(inputEvent("blur"));
  assert.equal(input.read().move, 0, "window blur clears held controls");
  assert.equal(input.read().jumpPressed, false, "window blur clears an unconsumed jump press");
}

function finishSpawn(game) {
  for (let frame = 0; frame < 240 && game.player.spawning; frame++) {
    game.update(1 / 60, { move: 0, jumpPressed: false });
  }
  assert.equal(game.player.spawning, false, "spawn finishes within four seconds");
}

function testSpawnSequence(data) {
  globalThis.localStorage.clear();
  const game = new Game(data);
  for (let index = 0; index < data.levels.length; index++) {
    game.loadLevel(index, false);
    const [x, y] = game.level.spawn;
    assert.equal(game.player.state, "appearing");
    assert.equal(game.player.x, x);
    assert.equal(game.player.y, y + 2, "appearing center is 32 source pixels above the start");
    const frozenEntities = JSON.stringify(game.entities);
    game.particles.push({ x: 0, y: 0, age: 0, life: 5, vx: 1, vy: 1, gravity: 1 });
    let sawDrop = false;
    for (let frame = 0; frame < 240 && game.player.spawning; frame++) {
      const previousState = game.player.state;
      game.update(1 / 60, { move: 1, jumpPressed: true });
      assert.equal(game.player.x, x, "movement stays locked through landing");
      assert.equal(JSON.stringify(game.entities), frozenEntities, "all entity motion and timers stay frozen");
      assert.equal(game.elapsed, 0, "world animation clock stays frozen");
      assert.equal(game.particles[0].age, 0, "particle animation stays frozen");
      assert.equal(game.player.deadTimer, 0, "intro cannot trigger hazards");
      if (previousState === "appearing" && game.player.state === "jump") {
        assert.equal(game.player.y, y + 2, "Jump starts at the exact appearing center");
        assert.equal(game.player.vy, 0, "drop starts without upward impulse");
      }
      if (game.player.spawning && game.player.state === "jump") {
        sawDrop = true;
        assert.ok(game.player.y > y && game.player.y <= y + 2);
        assert.ok(game.player.vy <= 0, "Jump sprite falls instead of jumping");
      }
    }
    assert.ok(sawDrop, "appearing completes before the Jump drop");
    assert.equal(game.player.spawning, false);
    assert.equal(game.player.y, y, "landing clamps to the exact authored start");
    assert.equal(game.player.state, "idle");
    assert.equal(game.player.animTime, 0, "idle begins at its first frame");
    assert.equal(game.player.grounded, true);
    assert.equal(game.player.vy, 0);
    game.update(1 / 60, { move: 1, jumpPressed: true });
    assert.ok(game.elapsed > 0, "world resumes after idle starts");
    assert.ok(game.player.x > x, "movement resumes after idle starts");
    assert.ok(game.player.vy > 0, "jump input resumes after idle starts");
  }
  game.respawn();
  assert.equal(game.player.state, "appearing", "respawning replays the intro");
  assert.equal(game.spawnRevealWait, 0, "respawning does not replay the level wipe");
  finishSpawn(game);
  game.restart();
  assert.equal(game.player.spawning, true, "restarting replays the intro");
}

function testDeathSequence(data) {
  const game = new Game(data);
  game.loadLevel(0, false);
  const sources = [
    { kind: "fruit", name: "Apple", x: 0, y: 0 },
    { kind: "box", name: "Box1", x: 3, y: 0 },
    { kind: "hazard", name: "Arrow", x: 6, y: 0 }
  ];
  game.setEntities(sources);
  finishSpawn(game);
  game.entities[0].active = false;
  game.entities[1].active = false;
  game.entities[2].active = false;
  game.collected = 1;
  game.player.x = 10;
  game.player.y = 3;
  game.player.vx = 9;
  game.player.vy = -20;
  game.player.animTime = 100;
  game.die();
  const deadPlayer = game.player;
  assert.equal(deadPlayer.state, "hit");
  assert.equal(deadPlayer.animTime, 0, "Hit animation starts at its first frame");
  for (let frame = 0; frame < 30 && deadPlayer.state === "hit"; frame++) {
    game.update(1 / 60, { move: -1, jumpPressed: true });
    assert.equal(deadPlayer.x, 10, "input cannot move the damaged character");
    assert.ok(deadPlayer.y <= 5, "death rise never exceeds 32 source pixels");
  }
  assert.equal(deadPlayer.state, "disappearing");
  assert.equal(deadPlayer.y, 5, "disappearing starts exactly 32 pixels above the damage position");
  assert.equal(deadPlayer.vy, 0);
  assert.equal(deadPlayer.animTime, 0);
  game.die();
  assert.equal(deadPlayer.state, "disappearing", "repeated damage cannot restart the sequence");
  game.update(0.34, { move: 1, jumpPressed: true });
  assert.equal(deadPlayer.state, "disappearing", "disappearing plays its full seven frames");
  assert.equal(deadPlayer.y, 5, "disappearing stays centered at the final player position");
  game.update(0.01, { move: 0, jumpPressed: false });
  assert.equal(deadPlayer.state, "deathWait");
  assert.equal(deadPlayer.deadTimer, 2.5, "reset delay starts only after disappearing completes");

  let drawCalls = 0;
  Renderer.prototype.drawPlayer.call({ ctx: { drawImage() { drawCalls++; } } }, game);
  assert.equal(drawCalls, 0, "no player, effect, or shadow is drawn during the delay");
  game.update(2.49, { move: 1, jumpPressed: true });
  assert.equal(game.player, deadPlayer, "level does not reset before 2.5 seconds");
  assert.equal(game.collected, 1);
  game.update(0.01, { move: 1, jumpPressed: true });
  assert.notEqual(game.player, deadPlayer, "level resets after the full delay");
  assert.equal(game.levelIndex, 0, "reset stays on the current level");
  assert.equal(game.collected, 0, "reset clears fruit progress");
  assert.equal(game.entities.length, sources.length, "reset preserves custom placements");
  assert.ok(game.entities.every((entity) => entity.active), "reset restores fruit, boxes, and obstacles");
  assert.equal(game.entities[1].hits, 1);
  assert.equal(game.player.state, "appearing", "reset replays the spawn intro");
  assert.equal(game.elapsed, 0);
  assert.equal(game.transitionAge, 0);
  finishSpawn(game);
}

function testMovementIntegration(data) {
  globalThis.localStorage.clear();
  const game = new Game(data);
  const root = new EventHub();
  const buttons = ["left", "right", "jump"].map((name) => new ControlButton(name));
  root.querySelectorAll = () => buttons;
  const windowTarget = new EventHub();
  globalThis.window = windowTarget;
  const input = new InputController(root, () => {});

  finishSpawn(game);
  const startX = game.player.x;
  windowTarget.dispatchEvent(inputEvent("keydown", { code: "ArrowRight", repeat: false }));
  for (let frame = 0; frame < 30; frame++) game.update(1 / 60, input.read());
  windowTarget.dispatchEvent(inputEvent("keyup", { code: "ArrowRight" }));
  assert.ok(game.player.x > startX + 0.5, "keyboard input moves the simulated player");

  const touchStartX = game.player.x;
  buttons[0].dispatchEvent(inputEvent("pointerdown", { pointerId: 11 }));
  for (let frame = 0; frame < 60; frame++) game.update(1 / 60, input.read());
  buttons[0].dispatchEvent(inputEvent("pointerup", { pointerId: 11 }));
  assert.ok(game.player.x < touchStartX - 0.2, "touch input moves the simulated player");
}

function testCampaign(data) {
  assert.equal(data.levels.length, 18, "all included worlds load");
  for (const [index, level] of data.levels.entries()) {
    assert.equal(level.id, index + 1, "world ids are ordered and contiguous");
    assert.ok(level.layers.every((layer) => layer.cells.every((cell) => cell.slice(0, 2).every(Number.isFinite))), "world " + level.id + " has valid tile coordinates");
    assert.ok(level.entities.every((entity) => Number.isFinite(entity.x) && Number.isFinite(entity.y)), "world " + level.id + " has valid entity coordinates");
  }

  globalThis.localStorage.clear();
  let game = new Game(data);
  game.loadLevel(4, false);
  assert.equal(game.transitionAge, 0, "each world load restarts the tile-wipe transition");
  game.update(1 / 60, { move: 0, jumpPressed: false });
  assert.ok(game.transitionAge > 0, "the level transition advances with simulation time");
  game = new Game(data);
  assert.equal(game.level.id, 5, "saved world resumes on the next game instance");
  game.previous();
  assert.equal(game.level.id, 4, "previous navigates to the prior world");
  game.next();
  assert.equal(game.level.id, 5, "next navigates to the following world");
  game.loadLevel(data.levels.length - 1, false);
  assert.equal(game.next(), "complete", "next from the final world completes the campaign");
  assert.equal(game.complete, true, "campaign completion state is set");
}

function testMovingHazards(data) {
  const game = new Game(data);
  game.loadLevel(11, false);
  const rockHead = game.entities.find((entity) => entity.name === "Rock Head" && entity.x === 1);
  assert.deepEqual(rockHead.direction, [1, 0], "world 12 retains the authored Rock Head direction");
  assert.equal(rockHead.linear, true, "world 12 retains the authored linear path mode");
  assert.equal(rockHead.speed, 0.4, "world 12 retains the authored Rock Head speed");
  const savedHead = validateEntityList([rockHead], game.level.bounds)[0];
  assert.deepEqual(savedHead.direction, [1, 0], "editor serialization preserves moving-head paths");
  const startX = rockHead.x;
  for (let frame = 0; frame < 45; frame++) game.updateEntityMotion(1 / 60);
  assert.ok(Math.abs(rockHead.x - startX) > 0.02 || Math.abs(rockHead.y + 7) > 0.02, "authored Rock Heads move during the simulation");

  game.loadLevel(12, false);
  const spikeHeads = game.entities.filter((entity) => entity.name === "Spike Head");
  const spikeStarts = spikeHeads.map((entity) => [entity.x, entity.y]);
  for (let frame = 0; frame < 30; frame++) game.updateEntityMotion(1 / 60);
  for (const [index, head] of spikeHeads.entries()) {
    assert.ok(Math.hypot(head.x - spikeStarts[index][0], head.y - spikeStarts[index][1]) > 0.1, head.label + " moves along its source raycast route");
    assert.equal(head.motionSpeed, head.speed * 50, head.label + " reaches the Unity FixedUpdate speed after acceleration");
  }

  game.loadLevel(4, false);
  const fan = game.entities.find((entity) => entity.kind === "fan");
  assert.equal(fan.fanOn, false, "fan begins in its authored off state");
  for (let frame = 0; frame < 301; frame++) game.updateEntityMotion(1 / 60);
  assert.equal(fan.fanOn, true, "fan cycles on after its authored five-second interval");
  assert.ok(game.particles.some((particle) => particle.texture && particle.vy > 0), "active fan emits upward particles");

  game.loadLevel(7, false);
  game.updateEntityMotion(1 / 60);
  assert.ok(game.particles.some((particle) => particle.texture && particle.vy < 0), "idle falling platforms emit downward particles");
}

function testWorldSevenPlatforms(data) {
  const game = new Game(data);
  game.loadLevel(6, false);
  const platforms = game.entities.filter((entity) => entity.kind === "platform");
  assert.equal(platforms.length, 3, "World 7 includes both interactive platforms and its automatic platform");
  const interactive = platforms.find((entity) => entity.label === "Platform (1)");
  const landingGame = new Game(data);
  landingGame.loadLevel(6, false);
  const landingPlatform = landingGame.entities.find((entity) => entity.label === "Platform (1)");
  const landingRect = landingGame.dynamicSolidRects({ left: landingPlatform.x - 2, right: landingPlatform.x + 2, bottom: landingPlatform.y - 2, top: landingPlatform.y + 2 }).find((rect) => rect.entity === landingPlatform);
  landingGame.player.x = landingPlatform.x;
  landingGame.player.y = landingRect.top - landingGame.player.bottomOffset + 0.02;
  landingGame.player.vy = -2;
  landingGame.updatePlayer(1 / 60, { move: 0, jumpPressed: false });
  assert.equal(landingGame.player.ridingEntity, landingPlatform, "landing on an interactive platform activates its rider interaction");
  const movingStartY = interactive.y;
  game.updateEntityMotion(0.1);
  assert.equal(interactive.y, movingStartY, "interactive platforms remain at the lower stop until ridden");
  game.player.ridingEntity = interactive;
  game.updateEntityMotion(0.1);
  assert.ok(Math.abs(interactive.y - movingStartY - 0.5) < 1e-9, "riding an interactive platform moves it toward its upper stop at source speed");
  const platformRect = game.dynamicSolidRects({ left: interactive.x - 2, right: interactive.x + 2, bottom: interactive.y - 2, top: interactive.y + 2 }).find((rect) => rect.entity === interactive);
  assert.equal(platformRect.oneWay, true, "World 7 platforms can be passed through from below");
  const undersideBody = { x: interactive.x, y: platformRect.bottom - 0.55, halfWidth: 0.35, bottomOffset: -1, topOffset: 0.5 };
  const undersideCollision = moveBody(undersideBody, 0, 0.2, [], [platformRect], () => {});
  assert.equal(undersideCollision.ceiling, false, "jumping through an interactive platform does not hit its underside");
  assert.ok(undersideBody.y > platformRect.bottom - 0.55, "the player continues upward through the platform");
  const platformTop = interactive.y + interactive.colliderOffsetY + interactive.colliderHeight / 2;
  game.player.x = interactive.x;
  game.player.y = platformTop - game.player.bottomOffset;
  game.player.grounded = true;
  const playerY = game.player.y;
  game.updateEntityMotion(0.1);
  game.updatePlayer(0.1, { move: 0, jumpPressed: false });
  assert.ok(Math.abs(game.player.y - playerY - 0.5) < 1e-9, "the player is carried by a rising World 7 platform");
  game.player.ridingEntity = null;
  const movingY = interactive.y;
  game.updateEntityMotion(0.1);
  assert.ok(Math.abs(interactive.y - movingY + 0.5) < 1e-9, "an unoccupied interactive platform returns to its lower stop");

  game.loadLevel(6, false);
  const resetPlatforms = game.entities.filter((entity) => entity.kind === "platform");
  const automatic = resetPlatforms.find((entity) => entity.label === "Static Platform");
  assert.equal(automatic.style, "grey", "the automatic World 7 platform retains its gray source style");
  const startX = automatic.x;
  game.updateEntityMotion(0.9);
  game.updateEntityMotion(0.1);
  assert.ok(Math.abs(automatic.x - startX) < 1e-9, "the automatic platform waits one second before moving");
  game.updateEntityMotion(0.1);
  assert.ok(Math.abs(automatic.x - startX - 0.5) < 1e-9, "the automatic platform moves at five units per second");
  game.updateEntityMotion(1.9);
  assert.ok(Math.abs(automatic.x - automatic.path[1][0]) < 1e-9, "the automatic platform reaches its far endpoint");
  assert.equal(automatic.platformTarget, 0, "the automatic platform reverses at its endpoint");
  assert.ok(validateEntityList(resetPlatforms, game.level.bounds), "World 7 platform routes remain valid for editor save and export");
  assert.ok(ENTITY_TEMPLATES.some((template) => template.kind === "platform"), "the editor exposes platforms for placement");
}

function testLevelEighteenMarkers(data) {
  const game = new Game(data);
  game.loadLevel(17, false);
  const markers = game.entities.filter((entity) => entity.kind === "checkpoint");
  assert.deepEqual(markers.map((entity) => [entity.name, entity.x, entity.y]), [
    ["Start", -5, -1], ["End", 16.5, -2], ["Checkpoint", 6, -3]
  ], "World 18 retains its source Start, End, and Checkpoint markers");

  const start = markers.find((entity) => entity.name === "Start");
  const startRect = game.dynamicSolidRects({ left: start.x - 3, right: start.x + 3, bottom: start.y - 3, top: start.y + 3 }).find((rect) => rect.entity === start);
  game.player.x = start.x + 0.5;
  game.player.y = startRect.top - game.player.bottomOffset + 0.02;
  game.player.vy = -2;
  game.updatePlayer(1 / 60, { move: 0, jumpPressed: false });
  assert.equal(start.triggered, true, "touching the Start marker plays its source one-shot animation");
  const startTime = start.triggerTime;
  game.updateEntityMotion(0.2);
  assert.ok(start.triggerTime < startTime, "Start animation advances then returns to idle");

  const end = markers.find((entity) => entity.name === "End");
  const endRect = game.dynamicSolidRects({ left: end.x - 3, right: end.x + 3, bottom: end.y - 3, top: end.y + 3 }).find((rect) => rect.entity === end);
  game.player.contacts.clear();
  game.player.grounded = false;
  game.player.x = end.x;
  game.player.y = endRect.top - game.player.bottomOffset + 0.02;
  game.player.vy = -2;
  game.updatePlayer(1 / 60, { move: 0, jumpPressed: false });
  assert.equal(end.triggered, true, "touching the End marker plays its source one-shot animation");
  const confetti = game.particles.filter((particle) => particle.confetti);
  assert.equal(confetti.length, 96, "touching the World 18 trophy starts a shower of confetti");
  assert.deepEqual([...new Set(confetti.map((particle) => particle.spriteFrame))].sort(), [0, 1, 2, 3, 4, 5], "the confetti shower uses every color in the sprite sheet");
  assert.ok(confetti.every((particle) => particle.y > game.player.y + 7.4), "confetti begins above the player and screen");
  const confettiY = confetti.map((particle) => particle.y);
  const confettiRotation = confetti.map((particle) => particle.rotation);
  game.updateParticles(0.1);
  assert.ok(confetti.every((particle, index) => particle.y < confettiY[index]), "confetti falls down from above");
  assert.ok(confetti.some((particle, index) => particle.rotation !== confettiRotation[index]), "confetti tumbles as it falls");
  game.activateCheckpoint(end);
  assert.equal(game.particles.filter((particle) => particle.confetti).length, 96, "the trophy only emits confetti once");

  const checkpoint = markers.find((entity) => entity.name === "Checkpoint");
  game.player.x = checkpoint.x - 0.5;
  game.player.y = checkpoint.y - 0.5;
  game.collectAndTrigger();
  assert.equal(checkpoint.triggered, true, "entering the checkpoint trigger plays its one-shot animation");
  game.updateEntityMotion(1.31);
  assert.equal(checkpoint.flagged, true, "the checkpoint finishes with its source flagged idle animation");
  assert.equal(game.level.spawn[0], -4.5, "the source checkpoint animation does not change spawn progression");
}

function testArrowTrap(data) {
  const game = new Game(data);
  game.loadLevel(5, false);
  const arrow = game.entities.find((entity) => entity.kind === "hazard" && entity.name === "Arrow");
  assert.deepEqual(arrow.direction, [0, 1], "Level 6 Arrow triggers retain their authored upward direction");
  game.player.x = arrow.x;
  game.player.y = arrow.y;
  game.player.vx = 3;
  game.player.vy = -4;
  game.player.grounded = true;
  game.collectAndTrigger(1 / 60);
  assert.ok(Math.abs(game.player.vy - 22.5) < 1e-9, "Arrow hit resets vertical speed and applies its source force for one game step");
  assert.equal(game.player.vx, 3, "an upward Arrow trigger preserves horizontal velocity");
  assert.equal(game.player.deadTimer, 0, "Arrow triggers launch the player instead of killing them");
  assert.equal(arrow.arrowTriggered, true, "each Arrow only triggers once");
  assert.ok(arrow.arrowHitTime > 0, "a triggered Arrow plays its hit animation before disappearing");
  game.collectAndTrigger(1 / 60);
  assert.ok(Math.abs(game.player.vy - 22.5) < 1e-9, "overlapping an activated Arrow does not apply the force repeatedly");
  game.updateEntityMotion(0.3);
  assert.equal(arrow.active, false, "an Arrow disappears after its hit animation");
}

function testSawRoutes(data) {
  const game = new Game(data);
  game.loadLevel(9, false);
  const saws = game.entities.filter((entity) => entity.name === "Saw");
  assert.equal(saws.length, 4, "world 10 includes all four authored saws");
  const routeSaws = saws.filter((entity) => entity.motion === "waypoints");
  assert.equal(routeSaws.length, 2, "world 10 includes two four-point route saws");
  assert.deepEqual(routeSaws[0].path, [[4, 1], [4, -3], [-3, -3], [-3, 1]], "the four-point route retains the Unity child-transform positions");
  assert.equal(routeSaws[0].pathIndex, 0, "the first blade starts at the first route waypoint");
  assert.equal(routeSaws[1].pathIndex, 2, "the second blade starts at the opposite route waypoint");
  const oscillators = saws.filter((entity) => entity.motion === "oscillate");
  assert.equal(oscillators.length, 2, "world 10 includes two endpoint oscillators");
  assert.deepEqual(oscillators.map((entity) => entity.path), [[[11.1, 0.98], [11.1, 5.98]], [[20, -0.3], [13, -0.3]]], "endpoint paths retain their serialized Unity positions");
  const serialized = validateEntityList(saws, game.level.bounds);
  assert.deepEqual(serialized.map((entity) => entity.path), saws.map((entity) => entity.path), "editor serialization preserves authored saw routes");

  const firstRouteSaw = routeSaws[0];
  const routeStart = [firstRouteSaw.x, firstRouteSaw.y];
  game.updateEntityMotion(0.1);
  assert.ok(firstRouteSaw.y < routeStart[1], "four-point saws move along their authored route at 2.5 units per second");
  assert.ok(routeSaws[1].y > -3, "the opposite route saw follows the next segment from its own start waypoint");
  const verticalSaw = oscillators[0];
  const horizontalSaw = oscillators[1];
  game.updateEntityMotion(0.5);
  assert.ok(verticalSaw.y > 0.98 && verticalSaw.y < 5.98, "vertical endpoint saw oscillates between its two points");
  assert.ok(horizontalSaw.x < 20 && horizontalSaw.x > 13, "horizontal endpoint saw oscillates between its two points");
}

function testTileSpriteColliders(data) {
  const shapeId = data.sprites.findIndex((sprite) => sprite.name === "Terrain (16x16)_32");
  const fullId = data.sprites.findIndex((sprite) => sprite.name === "Terrain (16x16)_18");
  assert.ok(shapeId >= 0 && fullId >= 0, "the used terrain sprites are mapped to their actual source atlas entries");
  assert.deepEqual(data.sprites[shapeId].collisionMask.slice(0, 14), Array(14).fill(0), "the serialized Unity top-edge shape leaves the transparent sprite area non-solid");
  assert.deepEqual(data.sprites[shapeId].collisionMask.slice(14), [65535, 65535], "the explicit Unity physics shape is retained at its source pixel rows");
  assert.equal(data.sprites[shapeId].collisionSource, "unity-physics-shape", "custom terrain collision comes from Unity sprite physics metadata");
  assert.equal(data.sprites[fullId].collisionMask.every((row) => row === 65535), true, "fallback terrain collision follows the fully opaque source sprite");

  const layer = { name: "Ground", origin: [0, 0], cells: [[0, 0, shapeId]] };
  const level = { ...data.levels[0], layers: [layer], entities: [] };
  const testData = { ...data, levels: data.levels.map((source) => source.id === 1 ? level : source) };
  const game = new Game(testData);
  game.loadLevel(0, false);
  const rects = game.getTileRects([layer], { left: 0, right: 1, bottom: 0, top: 1 });
  assert.equal(rects.length, 1, "pixel runs with the same span merge into one exact collision rectangle");
  assert.equal(rects[0].bottom, 0.875, "sprite physics begins at the Unity-authored 14-pixel boundary");
  assert.equal(rects[0].top, 1, "sprite physics reaches the authored top edge");

  for (const campaignLevel of data.levels) {
    for (const collisionLayer of campaignLevel.layers.filter((item) => ["Ground", "Blocks", "Sand", "Mud", "Ice", "Platforms"].includes(item.name))) {
      for (const [, , id] of collisionLayer.cells) {
        assert.ok(id < 0 || data.sprites[id]?.collisionMask?.length === 16, "every colliding tile references a sprite-derived mask");
      }
    }
  }

  const campaign = new Game(data);
  for (const sourceLevel of data.levels) {
    campaign.loadLevel(sourceLevel.id - 1, false);
    const collisionLayer = campaign.level.layers.find((item) => ["Ground", "Blocks", "Sand", "Mud", "Ice", "Platforms"].includes(item.name) && item.cells.some(([, , id]) => id >= 0 && campaign.tileCollisionShapes[id]?.length));
    assert.ok(collisionLayer, "world " + sourceLevel.id + " has a sprite-derived solid surface");
    const [cellX, cellY, id] = collisionLayer.cells.find(([, , spriteId]) => spriteId >= 0 && campaign.tileCollisionShapes[spriteId]?.length);
    const [originX, originY] = collisionLayer.origin;
    const tile = campaign.getTileRects([collisionLayer], { left: cellX + originX, right: cellX + originX + 0.99, bottom: cellY + originY, top: cellY + originY + 0.99 }).find((rect) => rect.layer === collisionLayer);
    assert.ok(tile, "world " + sourceLevel.id + " resolves the selected tile sprite collider");
    const body = { x: tile.left - 0.15, y: (tile.bottom + tile.top) / 2, halfWidth: 0.05, bottomOffset: -0.05, topOffset: 0.05 };
    const collision = moveBody(body, 0.2, 0, [tile], [], () => {});
    assert.equal(collision.wall, 1, "world " + sourceLevel.id + " blocks against its actual tile sprite edge");
    assert.ok(body.x + body.halfWidth <= tile.left + 1e-9, "world " + sourceLevel.id + " resolves the wall flush without crossing it");
  }
}

function testRockHeadCarryCollision(data) {
  const createGame = (cells) => {
    const layer = { name: "Ground", origin: [0, 0], cells };
    const level = {
      ...data.levels[11],
      layers: [layer],
      entities: [{ kind: "hazard", name: "Rock Head", label: "Test Rock Head", x: 0, y: -2.05, direction: [1, 0], linear: true, speed: 0.4 }]
    };
    const testData = { ...data, levels: data.levels.map((source) => source.id === 12 ? level : source) };
    const game = new Game(testData);
    game.loadLevel(11, false);
    return { game, head: game.entities[0] };
  };

  globalThis.localStorage.clear();
  let { game, head } = createGame([]);
  head.x = 0;
  head.y = 0;
  head.motionSpeed = 20;
  game.player.x = 2.6;
  game.player.y = 0;
  game.updateMovingHead(head, 0.1);
  assert.ok(game.player.deadTimer > 0, "a Rock Head damages the player when its leading side strikes them");

  ({ game, head } = createGame([]));
  head.x = 0;
  head.y = 0;
  head.direction = [-1, 0];
  head.motionSpeed = 20;
  game.player.x = 2.6;
  game.player.y = 0;
  game.updateMovingHead(head, 0.1);
  assert.equal(game.player.deadTimer, 0, "a Rock Head moving away from the player does not deal a side-hit");

  ({ game, head } = createGame([]));
  head.x = 0;
  head.y = 0;
  head.direction = [0, 1];
  head.motionSpeed = 20;
  game.player.x = 0;
  game.player.y = 2.6;
  game.updateMovingHead(head, 0.1);
  assert.ok(game.player.deadTimer > 0, "a rising Rock Head damages a player in front of its leading face");

  ({ game, head } = createGame([]));
  head.x = 0;
  head.y = 0;
  head.direction = [0, 1];
  head.motionSpeed = 20;
  game.player.x = 0;
  game.player.y = 2;
  game.player.ridingEntity = head;
  game.updateMovingHead(head, 0.1);
  assert.equal(game.player.deadTimer, 0, "riding on top of a Rock Head remains safe while it rises");

  ({ game, head } = createGame([[2, 0, 5], [2, 1, 5], [2, 2, 5]]));
  game.player.x = 0;
  game.player.y = head.y + 2;
  game.player.grounded = true;
  game.player.ridingEntity = head;
  head.x = 2;
  head.deltaX = 2;
  game.updatePlayer(1 / 60, { move: 0, jumpPressed: false });
  assert.ok(game.player.x + game.player.halfWidth <= 2.001, "a carried player collides with the actual solid sprite wall");
  assert.equal(game.player.ridingEntity, head, "the player remains supported while the block is beside the wall");

  head.x = 4;
  head.deltaX = 2;
  game.updatePlayer(1 / 60, { move: 0, jumpPressed: false });
  assert.ok(game.player.x + game.player.halfWidth <= 2.001, "the rider is not pushed through the wall as the block moves away");
  assert.equal(game.player.ridingEntity, null, "the player slides off when the moving block leaves the player's support");

  ({ game, head } = createGame([[0, 1, 5]]));
  game.player.x = 0;
  game.player.y = head.y + 2;
  game.player.grounded = true;
  game.player.ridingEntity = head;
  head.y += 2;
  head.deltaY = 2;
  game.updatePlayer(1 / 60, { move: 0, jumpPressed: false });
  assert.ok(game.player.y + game.player.topOffset <= 1.001, "a carried player collides with the actual ceiling sprite");
  assert.equal(game.player.ridingEntity, null, "a rider detaches when ceiling collision interrupts the block carry");

  ({ game, head } = createGame([]));
  game.player.x = 0;
  game.player.y = head.y + 2;
  game.player.grounded = true;
  game.player.ridingEntity = head;
  for (let frame = 0; frame < 6; frame++) {
    head.x += 0.003;
    head.y += 0.002;
    head.deltaX = 0.003;
    head.deltaY = 0.002;
    game.updatePlayer(1 / 60, { move: 1, jumpPressed: false });
    assert.equal(game.player.grounded, true, "horizontal input keeps the player supported on the moving collider");
    assert.equal(game.player.ridingEntity, head, "horizontal input does not detach the moving support");
    assert.ok(Math.abs(game.player.y - head.y - 2) < 1e-9, "rider position remains flush with the block without vertical vibration");
  }

  ({ game, head } = createGame([[2, -1, 5], [2, 0, 5]]));
  head.x = 0;
  head.y = 0;
  head.motionSpeed = 20;
  game.updateMovingHead(head, 0.1);
  assert.ok(Math.abs(head.x - 1) < 1e-9, "Rock Head's authored 2x2 collider stops flush against the source sprite wall");
  assert.ok(head.direction[0] === -1 && head.direction[1] === 0, "Rock Head reverses at the actual sprite collider edge");
}

function testWallSpriteOffsets(data) {
  assert.ok(Math.abs(wallSpriteOffset({ x: 4.3, wall: 1, wallX: 5, state: "wall" }) + 0.3) < 1e-9, "wall-slide sprite edge is flush against a right wall");
  assert.ok(Math.abs(wallSpriteOffset({ x: 5.7, wall: -1, wallX: 5, state: "wall" }) - 0.3) < 1e-9, "wall-slide sprite edge is flush against a left wall");
  assert.ok(Math.abs(wallSpriteOffset({ x: 4.3, wall: 0, wallX: null, wallJumpFrom: 1, wallJumpWallX: 5, state: "wallJump" }) + 0.3) < 1e-9, "wall-jump sprite remains flush until it clears the wall");
  assert.ok(Math.abs(wallSpriteOffset({ x: 4.3, wall: 1, wallX: 5, state: "wall" }, { left: 4, right: 28 }) + 0.05) < 1e-9, "wall alignment uses the opaque right edge instead of transparent frame padding");
  assert.ok(Math.abs(wallSpriteOffset({ x: 5.7, wall: -1, wallX: 5, state: "wall" }, { left: 4, right: 28 }) - 0.05) < 1e-9, "flipped sprite alignment uses its opaque left edge");
  assert.equal(wallSlideVisualNudge({ wall: 1, state: "wall" }, 128), 4, "ordinary wall slides retain their small visual nudge");
  assert.equal(wallSlideVisualNudge({ wall: -1, state: "wall", wallEntity: { kind: "hazard", name: "FireLeft" } }, 128), -16, "fire walls nudge four source pixels toward the contacted side");
  assert.equal(wallSlideVisualNudge({ wall: 1, state: "fall", wallEntity: { kind: "hazard", name: "FireLeft" } }, 128), 0, "fire wall nudge only applies while sliding");

  const fire = { kind: "hazard", name: "FireLeft", label: "Test Fire", x: 0, y: 0 };
  const level = { ...data.levels[0], spawn: [-0.71, 0], layers: [], entities: [fire] };
  const fireGame = new Game({ ...data, levels: data.levels.map((source, index) => index === 0 ? level : source) });
  fireGame.loadLevel(0, false);
  fireGame.player.x = -0.71;
  fireGame.player.y = 0;
  fireGame.player.vy = -1;
  fireGame.updatePlayer(1 / 60, { move: 0, jumpPressed: false });
  const fireRect = fireGame.dynamicSolidRects({ left: -2, right: 2, bottom: -2, top: 2 }).find((rect) => rect.entity.name === "FireLeft");
  assert.deepEqual([fireRect.left, fireRect.right, fireRect.bottom, fireRect.top], [0, 1, -0.5, 0.5], "rotated FireLeft uses the visible solid base edge as its wall plane");
  assert.equal(fireGame.player.wallEntity?.name, "FireLeft", "wall contact records the rotated fire emitter for trap-specific sprite offset");
  assert.equal(fireGame.player.state, "wall", "the fire trap contact enters wall-slide state");
}

function testRequestedBehaviors(data) {
  const game = new Game(data);

  game.loadLevel(3, false);
  const emptyBox = game.entities.find((entity) => entity.name === "EmptyBox");
  const fruitsBeforeEmptyBox = game.totalFruit;
  game.hitBox(emptyBox, "bottom");
  assert.equal(emptyBox.active, false, "Level 4 empty crates break on their first collision");
  assert.equal(game.totalFruit, fruitsBeforeEmptyBox, "empty crates do not drop fruit");
  assert.equal(emptyBox.breaking, true, "broken crates play their break frames");
  const cratePieces = game.particles.filter((particle) => particle.debris);
  assert.equal(cratePieces.length, 4, "broken crates scatter four sprite-based debris pieces");
  assert.ok(cratePieces.every((piece) => piece.sprite === "Items/Boxes/Box1/Break.png"), "crate pieces use the matching break sprite");
  assert.ok(cratePieces.some((piece) => piece.vx < 0) && cratePieces.some((piece) => piece.vx > 0), "crate pieces scatter in both horizontal directions");
  assert.ok(cratePieces.every((piece) => piece.flashStart === null), "crate pieces wait to flash until they hit the ground");

  const fullTileId = data.sprites.findIndex((sprite) => sprite.name === "Terrain (16x16)_18");
  const debrisLayer = { name: "Ground", origin: [0, 0], cells: [[0, 0, fullTileId]] };
  const debrisLevel = { ...data.levels[0], layers: [debrisLayer], entities: [{ kind: "box", name: "EmptyBox", label: "Debris Test", x: 0.5, y: 1.5 }] };
  const debrisData = { ...data, levels: data.levels.map((source, index) => index === 0 ? debrisLevel : source) };
  const debrisGame = new Game(debrisData);
  const debrisCrate = debrisGame.entities[0];
  debrisGame.hitBox(debrisCrate);
  const shard = debrisGame.particles.find((particle) => particle.debris);
  shard.x = 0.5;
  shard.y = 1.45;
  shard.vx = 0;
  shard.vy = -3;
  for (let frame = 0; frame < 20 && shard.bounces === 0; frame++) debrisGame.updateParticles(1 / 60);
  assert.equal(shard.bounces, 1, "crate debris bounces once when it hits the tile ground");
  assert.ok(shard.vy > 0, "crate debris rebounds slightly after landing");
  assert.ok(shard.flashStart > shard.age && shard.flashStart < shard.life, "crate debris starts flashing just after its bounce");
  shard.age = shard.life - 0.02;
  debrisGame.updateParticles(0.03);
  assert.equal(debrisGame.particles.includes(shard), false, "crate debris disappears after flashing");

  game.loadLevel(1, false);
  const floorBox = game.entities.find((entity) => entity.name === "Box1" && entity.x === 0.5);
  game.player.x = floorBox.x;
  game.player.y = floorBox.y + 3;
  game.player.vy = -12;
  for (let frame = 0; frame < 120 && floorBox.active; frame++) game.updatePlayer(1 / 60, { move: 0, jumpPressed: false });
  assert.equal(floorBox.active, false, "a floor crate breaks when landed on from above");
  assert.equal(game.totalFruit, 3, "breaking a floor Box1 grants its three fruit");
  assert.ok(game.player.vy > 0, "hitting a crate from above bounces the player upward");

  game.loadLevel(14, false);
  const sand = game.level.layers.find((layer) => layer.name === "Sand");
  const [sandX, sandY] = sand.cells[0];
  const worldX = sandX + sand.origin[0] + 0.5;
  const worldTop = sandY + sand.origin[1] + 1;
  game.player.x = worldX;
  game.player.y = worldTop + 1;
  game.player.grounded = true;
  assert.equal(game.currentSurface()?.name, "Sand", "sand is a colliding movement surface");
  assert.ok(game.staticTileLayers().includes(sand), "sand participates in solid tile collision");
  game.updatePlayer(0.1, { move: 0, jumpPressed: false });
  const sandSink = game.player.sink;
  assert.ok(sandSink > 0, "sand visually sinks the player while grounded");

  game.loadLevel(15, false);
  const mud = game.level.layers.find((layer) => layer.name === "Mud");
  const [mudX, mudY] = mud.cells[0];
  game.player.x = mudX + mud.origin[0] + 0.5;
  game.player.y = mudY + mud.origin[1] + 2;
  game.player.grounded = true;
  game.updatePlayer(0.1, { move: 0, jumpPressed: false });
  assert.ok(game.player.sink > sandSink, "mud sinks faster than sand");

  game.loadLevel(16, false);
  const ice = game.level.layers.find((layer) => layer.name === "Ice");
  const [iceX, iceY] = ice.cells[0];
  game.player.x = iceX + ice.origin[0] + 0.5;
  game.player.y = iceY + ice.origin[1] + 2;
  game.player.vx = 5;
  game.player.grounded = true;
  game.updatePlayer(1 / 60, { move: 0, jumpPressed: false });
  assert.ok(game.player.grounded, "ice supports the player instead of letting them fall through");
  assert.equal(game.player.vx, 5, "ice preserves horizontal momentum after input release");
  assert.equal(game.player.state, "idle", "the player idles while coasting on ice without directional input");

  game.loadLevel(10, false);
  const fire = game.entities.find((entity) => entity.name === "FireUp");
  assert.ok(game.dynamicSolidRects({ left: fire.x - 2, right: fire.x + 2, bottom: fire.y - 2, top: fire.y + 2 }).some((rect) => rect.entity === fire), "fire emitters have solid bases");
  game.player.x = fire.x;
  game.player.y = fire.y + 0.5;
  game.collectAndTrigger();
  assert.equal(game.player.deadTimer, 0, "the idle emitter body is not lethal");
  fire.fireState = "on";
  game.collectAndTrigger();
  assert.ok(game.player.deadTimer > 0, "the active flame collider is lethal");

  game.loadLevel(4, false);
  const fan = game.entities.find((entity) => entity.kind === "fan");
  fan.fanOn = true;
  game.player.x = fan.x;
  game.player.y = fan.y + 4;
  game.player.vy = 0;
  game.player.grounded = false;
  game.updatePlayer(1 / 60, { move: 0, jumpPressed: false });
  assert.ok(game.player.vy > 0, "the active fan area effector lifts the player");

  game.loadLevel(11, false);
  const rockHead = game.entities.find((entity) => entity.name === "Rock Head" && entity.x === 3);
  game.player.x = rockHead.x;
  game.player.y = rockHead.y + 2.04;
  game.player.vy = -2;
  game.player.grounded = false;
  game.updatePlayer(1 / 60, { move: 0, jumpPressed: false });
  assert.equal(game.player.ridingEntity, rockHead, "the top of a moving Rock Head is rideable");
  const carriedX = game.player.x;
  rockHead.deltaX = 0.4;
  game.updatePlayer(1 / 60, { move: 0, jumpPressed: false });
  assert.ok(Math.abs(game.player.x - carriedX - 0.4) < 0.001, "a riding player is carried with the Rock Head");
  assert.equal(game.player.deadTimer, 0, "standing on a moving Rock Head does not cause damage");

  game.loadLevel(13, false);
  const pendulum = game.entities.find((entity) => entity.name === "Spiked Ball");
  assert.ok(pendulum.pendulum.length > 0, "Level 14 pendulum length is loaded from its prefab");
  const pendulumAnchors = Object.fromEntries(game.entities.filter((entity) => entity.pendulum).map((entity) => [entity.label, [entity.x, entity.y]]));
  assert.deepEqual(pendulumAnchors, {
    "Spiked Ball (3)": [14.5, -3.5],
    "Spiked Ball (1)": [4.5, 5.5],
    "Spiked Ball (2)": [15.5, 2.5],
    "Spiked Ball": [2.5, -1.54]
  }, "Level 14 pendulums use each Unity parent transform position, not a child offset");
  const serialized = validateEntityList([pendulum], game.level.bounds)[0];
  assert.equal(serialized.pendulum.length, pendulum.pendulum.length, "custom saves preserve pendulum metadata");
  game.elapsed = 0.05;
  game.updateEntityMotion(1 / 60);
  assert.notEqual(pendulum.ballX, pendulum.x, "the spiked ball swings away from its chain anchor");
}

function testInteractions(data) {
  const fruitLevel = data.levels.findIndex((level) => level.entities.some((entity) => entity.kind === "fruit"));
  const game = new Game(data);
  game.loadLevel(fruitLevel, false);
  const fruit = game.entities.find((entity) => entity.kind === "fruit");
  game.player.x = fruit.x;
  game.player.y = fruit.y + 0.25;
  game.collectAndTrigger();
  assert.equal(fruit.active, false, "overlapping fruit is collected");
  assert.equal(fruit.collecting, true, "fruit plays its brief collected animation");
  assert.equal(game.collected, 1, "fruit collection increments the HUD count");

  const boxLevel = data.levels.findIndex((level) => level.entities.some((entity) => entity.kind === "box" && entity.name === "Box1"));
  game.loadLevel(boxLevel, false);
  const box = game.entities.find((entity) => entity.kind === "box" && entity.name === "Box1");
  const totalBefore = game.totalFruit;
  game.hitBox(box);
  assert.equal(box.active, false, "Box1 breaks after its authored hit count");
  assert.equal(game.totalFruit, totalBefore + 3, "Box1 emits its fruit reward");

  const hazardLevel = data.levels.findIndex((level) => level.entities.some((entity) => entity.kind === "hazard" && entity.name !== "Arrow"));
  game.loadLevel(hazardLevel, false);
  finishSpawn(game);
  const hazard = game.entities.find((entity) => entity.kind === "hazard");
  game.player.x = hazard.x;
  game.player.y = hazard.y;
  game.collectAndTrigger();
  assert.ok(game.player.deadTimer > 0, "overlapping hazard starts death state");
  for (let frame = 0; frame < 240 && game.player.deadTimer > 0; frame++) {
    game.update(1 / 60, { move: 0, jumpPressed: false });
  }
  assert.equal(game.player.x, game.level.spawn[0], "death resets to the authored world spawn after disappearing and waiting");
  assert.equal(game.player.y, game.level.spawn[1] + 2, "respawn begins above the authored world height");
  assert.equal(game.player.state, "appearing", "death restarts the appearing animation");
  finishSpawn(game);
  assert.equal(game.player.y, game.level.spawn[1], "spawn drop restores the authored world height");
}

function testEditorUtilities(data) {
  for (const level of data.levels) {
    assert.ok(validateEntityList(level.entities, level.bounds), "world " + level.id + " entities are supported by the editor palette");
  }
  const level = data.levels[0];
  const source = { kind: "fruit", name: "Apple", label: "Apple", x: level.spawn[0], y: level.spawn[1] };
  assert.equal(validateEntity(source, level.bounds), null, "supported entity positions validate inside level bounds");
  assert.ok(validateEntity({ ...source, kind: "enemy", name: "Unknown" }, level.bounds), "unsupported entity kinds are rejected");
  assert.ok(validateEntity({ ...source, x: Number.NaN }, level.bounds), "non-finite positions are rejected");
  assert.ok(validateEntity({ ...source, x: level.bounds[2] + 1 }, level.bounds), "out-of-bounds positions are rejected");
  assert.ok(validateEntity(source, level.bounds, 512), "entity limit is enforced");
  assert.ok(ENTITY_TEMPLATES.length >= 20, "palette covers current supported runtime entities");

  const storage = new MemoryStorage();
  saveCustomLevel(level.id, [source], storage);
  const saved = readCustomLevels(storage)[String(level.id)];
  assert.deepEqual(saved, [serializeEntity(source)], "custom entities persist in a separate storage record");
  assert.deepEqual(validateEntityList(saved, level.bounds), [serializeEntity(source)], "saved entity lists are validated before applying");
  assert.equal(validateEntityList([{ ...source, name: "Unverified Enemy" }], level.bounds), null, "invalid saved entities are ignored");
  const exported = buildCustomLevelExport(level, [source]);
  assert.equal(exported.format, "pixel-adventure-custom-level", "export schema is explicit");
  assert.equal(exported.sourceLevelId, level.id, "export retains its source level reference");
  assert.deepEqual(exported.level.entities, [serializeEntity(source)], "export serializes only validated entities");
  assert.equal(buildCustomLevelExport(level, [{ ...source, x: Number.NaN }]), null, "invalid custom levels cannot be exported");
  assert.notEqual(level.entities, saved, "custom level saves do not mutate campaign entity data");

  const game = new Game(data);
  const originalCount = data.levels[game.levelIndex].entities.length;
  game.setEntities([...data.levels[game.levelIndex].entities, source]);
  assert.equal(game.entities.length, originalCount + 1, "custom runtime entities are applied");
  assert.equal(data.levels[game.levelIndex].entities.length, originalCount, "applying custom entities leaves campaign data unchanged");
}

async function testAssets(data) {
  const paths = new Set(data.sprites.map((sprite) => sprite.src));
  paths.add("Main Characters/Appearing (96x96).png");
  paths.add("Main Characters/Desappearing (96x96).png");
  for (const template of ENTITY_TEMPLATES) paths.add(template.image);
  for (const name of ["Blue", "Brown", "Gray", "Green", "Pink", "Purple", "Yellow"]) paths.add("Background/" + name + ".png");
  for (const skin of ["Mask Dude", "Ninja Frog", "Pink Man", "Virtual Guy"]) {
    for (const state of ["Idle", "Run", "Jump", "Fall", "Double Jump", "Wall Jump", "Hit"]) paths.add("Main Characters/" + skin + "/" + state + " (32x32).png");
  }
  for (const fruit of ["Apple", "Bananas", "Cherries", "Kiwi", "Melon", "Orange", "Pineapple", "Strawberry"]) paths.add("Items/Fruits/" + fruit + ".png");
  for (const box of ["Box1", "Box2", "Box3"]) {
    paths.add("Items/Boxes/" + box + "/Idle.png");
    paths.add("Items/Boxes/" + box + "/Hit (28x24).png");
    paths.add("Items/Boxes/" + box + "/Break.png");
  }
  for (const path of [
    "Traps/Platforms/Brown On (32x8).png", "Traps/Platforms/Grey On (32x8).png", "Traps/Falling Platforms/On (32x10).png", "Traps/Falling Platforms/Off.png",
    "Traps/Fan/On (24x8).png", "Traps/Fan/Off.png", "Traps/Trampoline/Idle.png", "Traps/Trampoline/Jump (28x28).png",
    "Traps/Fire/On (16x32).png", "Traps/Fire/Off.png", "Traps/Fire/Hit (16x32).png", "Traps/Arrow/Idle (18x18).png",
    "Traps/Spike Head/Idle.png", "Traps/Rock Head/Idle.png", "Traps/Spiked Ball/Spiked Ball.png", "Traps/Spiked Ball/Chain.png", "Traps/Saw/On (38x38).png",
    "Traps/Sand Mud Ice/Sand Particle.png", "Traps/Sand Mud Ice/Mud Particle.png", "Traps/Sand Mud Ice/Ice Particle.png",
    ...["Blink", "Bottom Hit", "Left Hit", "Right Hit", "Top Hit"].flatMap((frame) => [
      "Traps/Rock Head/" + frame + " (42x42).png",
      "Traps/Spike Head/" + frame + " (54x52).png"
    ]),
    "Items/Fruits/Collected.png", "Other/Dust Particle.png", "Other/Transition.png", "Other/Confetti (16x16).png",
    "Items/Checkpoints/Checkpoint/Checkpoint (No Flag).png", "Items/Checkpoints/Checkpoint/Checkpoint (Flag Idle)(64x64).png", "Items/Checkpoints/Checkpoint/Checkpoint (Flag Out) (64x64).png",
    "Items/Checkpoints/Start/Start (Idle).png", "Items/Checkpoints/Start/Start (Moving) (64x64).png", "Items/Checkpoints/End/End (Idle).png", "Items/Checkpoints/End/End (Pressed) (64x64).png",
    "Items/Boxes/Box1/Break.png", "Items/Boxes/Box2/Break.png", "Items/Boxes/Box3/Break.png",
    "Traps/Spiked Ball/Chain.png", "Traps/Fire/Hit (16x32).png",
    "Traps/Sand Mud Ice/Sand Particle.png", "Traps/Sand Mud Ice/Mud Particle.png", "Traps/Sand Mud Ice/Ice Particle.png",
    ...["Blink", "Bottom Hit", "Left Hit", "Right Hit", "Top Hit"].flatMap((frame) => [
      "Traps/Rock Head/" + frame + " (42x42).png",
      "Traps/Spike Head/" + frame + " (54x52).png"
    ]),
    "Traps/Spikes/SpikesUp.png", "Traps/Spikes/SpikesDown.png", "Traps/Spikes/SpikesLeft.png", "Traps/Spikes/SpikesRight.png"
  ]) paths.add(path);
  for (const path of paths) await access(new URL("../assets/PixelAdventureSprites/" + path, import.meta.url));
}

const data = JSON.parse(await readFile(new URL("../data/levels.json", import.meta.url), "utf8"));
globalThis.localStorage = new MemoryStorage();
testPhysics();
testInput();
testSpawnSequence(data);
testDeathSequence(data);
testMovementIntegration(data);
testCampaign(data);
testTileSpriteColliders(data);
testMovingHazards(data);
testWorldSevenPlatforms(data);
testLevelEighteenMarkers(data);
testArrowTrap(data);
testSawRoutes(data);
testRequestedBehaviors(data);
testRockHeadCarryCollision(data);
testWallSpriteOffsets(data);
testInteractions(data);
testEditorUtilities(data);
await testAssets(data);
console.log("Passed: sprite-derived tile collision, polygon sweeps, pixel-aligned rendering geometry, keyboard/touch release, campaign navigation, saw routes, stable rideable hazards, wall alignment, boxes, surfaces, editor persistence, and runtime assets.");
