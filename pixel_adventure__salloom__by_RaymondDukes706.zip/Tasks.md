# Pixel Adventure Web Conversion Tasks

Source: [salloom-domani/Pixel-Adventure](https://github.com/salloom-domani/Pixel-Adventure), a Unity adaptation of Pixel Frog's Pixel Adventure. The 18 browser layouts recreate demo levels shown on Pixel Frog's itch.io asset page; the project credits Bardent tutorials for core logic. Runtime target: static HTML/CSS/JavaScript with no build step.

## Conversion

- [x] Audit repository structure, gameplay scripts, scene count, and source asset provenance.
- [x] Convert all 18 demo-level recreations into compact browser-loadable data, retaining tile positions, object placements, layer ordering, and surface properties.
- [x] Bundle the upstream PNG sprite assets and document attribution / licensing limits in ATTRIBUTION.md.
- [x] Implement a modular fixed-step platformer simulation: acceleration, friction, gravity, coyote time, fixed / double jump, wall slide/jump, and stable tile collision.
- [x] Implement the pixel-art renderer: nearest-neighbor scaling, tile layers, animated character / fruit / hazard sprites, parallax or source backgrounds, and camera follow / bounds.
- [x] Port authored gameplay interactions: fruit collection, spawn-based death / respawn, breakable boxes, hazards, moving/falling platforms, trampoline and surface-specific sand/mud/ice behavior where supported by source data. Unity Level18 has three checkpoint animation triggers, but they do not alter respawn or persistent progression.
- [x] Implement 18-stage progression, restart / previous / next navigation, persistent current-world resume, and a clear completion state.
- [x] Build compact responsive HUD and keyboard + touch controls, with pause / resume and basic accessible semantics.
- [x] Verify data integrity and run the live page check; fix conversion or runtime defects found.

## Review And Remediation

- [x] Complete a professional code, gameplay, visual, accessibility, and asset-provenance review after conversion tasks are complete; record findings and enhancement opportunities in Review.md.
- [x] Add every actionable review enhancement / remediation to this file as a separate post-review backlog item, clearly distinguishing deferred opportunities from completed conversion scope.

## Post-Review Backlog

These are follow-up enhancements and remediations extracted from Review.md. They are not part of the completed baseline conversion and remain open for the next iteration.

- [x] R1 - Retain the demo-level recreations in the project as requested. Do not remove or replace them. Track any permission/platform-policy check as a release-only follow-up (R18).
- [x] R2 - Map original Unity tile collider shapes and composite-collider behavior to the converted tile IDs. (All used terrain and Sand/Mud/Ice sprites now carry source physics-shape masks or alpha-derived fallback masks in data/levels.json.)
- [x] R3 - Inventory upstream trap scripts, prefab/scene configuration, routes, trigger states, and timing values by family. (Completed from GitHub source; findings are recorded in Review.md. The Arrow is a stationary knockback trap, not a projectile.)
- [x] R4 - Keep respawn anchored to each recreated world's spawn and omit unsupported checkpoint-save handling. Level18 has three Checkpoint.cs instances, but the script only plays a one-shot animation and never changes the spawn or saved progress.
- [x] R5 - Add repeatable, dependency-free regression coverage in tests/run.js for keyboard/touch-to-simulation movement, collision primitives, fruit, boxes, hazards, spawn respawn, world navigation, saved resume, editor validation/export, and custom-save isolation; run with node --experimental-default-type=module tests/run.js.
- [x] R6 - Add direct selection of all 18 included worlds through the existing world HUD readout.
- [x] R7 - Respect prefers-reduced-motion by snapping camera follow, stopping sprite animation and decorative bob/rotation, and removing death flashing.
- [x] R8 - Remove 203 unused PNGs (all enemy/menu art plus unused frames and effects); retain the 71 image files referenced by level data, the HUD, and runtime rendering, and trim unused image requests from the loader.
- [x] R9 - Preserve native keyboard activation for focused HUD controls and clear stale jump input on blur; add regression coverage for focused select/button keydown/keyup and blur cleanup.
- [x] R10 - Disable text selection and touch callouts across the game surface, especially touch controls, while preserving button, select, keyboard, and pointer behavior; verified pointer movement and native controls still work.
- [x] R11 - Add a persistent accessible setting to show/hide the on-canvas control guide without hiding authored level art or changing gameplay; verified in the pause dialog.
- [x] R12 - Audit the upstream Unity source for implemented enemy, projectile, powerup, and related systems; map implemented behavior, assets, and dependencies. (Completed from GitHub source; no enemy/powerup system or projectile spawning is present. The static Arrow trap is tracked in R23.)
- [x] R13 - No enemy behavior exists to port in the audited source: enemy artwork is present, but there are no enemy scripts, prefabs, or scene instances. Keep enemy art out of the runtime palette unless behavior is later sourced.
- [x] R14 - Confirm whether the source implements projectile spawning/movement and avoid inventing it. (Completed: no projectile system exists; the static Arrow trigger is tracked separately in R23.)
- [x] R15 - Confirm whether the source implements powerups and avoid inventing them. (Completed: no powerup scripts/prefabs exist; Fruit is a collectible, not a powerup.)
- [x] R16 - Build a mouse/touch toolbelt palette for the 27 currently supported entity templates, half-unit placement, and camera pan controls; do not expose unverified enemies or powerups.
- [x] R17 - Add separate local custom-level overrides, JSON export, erase/undo, bounds/schema validation, and regression coverage without mutating the 18 authored campaign levels.
- [ ] R19 - Browser-verify Save & Exit persistence across reload/world changes and verify the downloaded JSON schema without modifying campaign data.
- [x] R20 - Implement tile-shape and composite collision behavior using the metadata obtained in R2. (Sprite masks are resolved as a continuous union for player and moving-head collision.)
- [x] R21 - Add terrain edge/corner regression cases and validate collision behavior across all 18 worlds. (Regression coverage resolves a sprite-backed wall in every campaign world.)
- [x] R22 - Port verified Spike Head/Rock Head movement using Level12/13 direction, linearity, speed, one-second wall waits, and direction-specific hit-frame sheets. Rock Heads are rideable, damage on leading-face impacts, and still crush when pinning the player against terrain.
- [x] R23 - Port the verified static Arrow trap interaction: Level6 has six up-facing trigger instances; Arrow.cs zeros vertical velocity then applies direction * ArrowForce (1350 from TrapsData.asset). The trigger now plays the source hit frames and removes itself; it is not a moving projectile.
- [x] R24 - Port the verified Level10 MovingSaw four-child routes and Saw endpoint motion from scene serialization. (Implemented both four-waypoint routes and both sinusoidal endpoint paths with source-derived coordinates/speeds; runtime and editor serialization are covered by tests.)
- [ ] R18 - Before public/WebSim release, check whether reusing demo-level recreations requires permission under platform policy and seek the asset owner's permission if required. Keep the layouts in the project meanwhile.

## Three-Cycle Run

- [x] Cycle 1 - Work the current task list to the best available extent, update Review.md, and extract R1-R3 and R9 from findings. R4-R8 are complete; R1-R3 remain blocked by unavailable rights/source metadata.
- [x] Cycle 2 - Reassess all open tasks, fix R9, rerun regression/page checks, update Review.md, and confirm R1-R3 remain blocked by unavailable rights/source metadata.
- [x] Cycle 3 - Implemented R10-R11, R16-R17, and the 2026-10-21 behavior/effect follow-up. R2/R20/R21, R22, R23, and R24 are complete. R18 is release-only and R19 awaits browser save/export verification.

## Upstream Source Audit Follow-Up (2026-10-21)

- Audited the GitHub main branch directly. It contains BaseLevel plus Level1-Level18, gameplay scripts, prefabs, serialized TrapsData, and the source scene instances; earlier source-missing blocker notes referred only to the web workspace and are superseded here.
- R3 and R12-R15 are resolved as marked above. Enemy sprites and Bee/Plant/Trunk bullet art do not correspond to implemented enemy or projectile behavior. The only Arrow behavior is a static trigger hazard that knocks the player upward.
- R2/R20/R21 are now complete: converted sprite IDs carry the Unity physics shapes or alpha-fallback masks, and campaign collision tests cover all 18 worlds. Level18's three Checkpoint.cs instances are animation-only and do not alter the spawn-based respawn model in R4.
- R22 has since been implemented: moving-head route metadata, source speed scaling, impact frame cycles, Rock Head riding/crush handling. R24 is now implemented with the Level10 saw paths; R23 Arrow remains actionable. R18 remains the release-only layout policy/permission check, and R19 still awaits browser verification of custom save/export.

## Gameplay and Controls Follow-Up (2026-10-21)

- [x] G1 - Make breakable boxes respond to floor, side, and ceiling contacts with source hit counts, top bounce, fruit rewards, and break frames; configure Level4 EmptyBox to break once without dropping fruit.
- [x] G2 - Keep floor crates breakable by landing on them and bouncing repeatedly; document the authored contact behavior in tests.
- [x] G3 - Move the HUD above the canvas, keep the pause overlay within the play stage, and verify navigation controls remain reachable while paused.
- [x] G4 - Clear held controls on navigation/pause, add global pointerup/cancel/lost-capture and page-visibility cleanup, and cover touch-release regressions.
- [x] G5 - Match Level12/13 moving-head speeds to Unity 50Hz FixedUpdate values and render all directional wall-hit frames.
- [x] G6 - Make Rock Heads solid and rideable, carrying players with the moving body and dealing damage on leading-face impacts or when a head pins the player against terrain.
- [x] G7 - Add continuous run dust, authored fan lift/side force, and down-blowing falling-platform particles.
- [x] G8 - Treat fire emitters as solid bases; only the active flame collider is lethal and its timing follows the Unity prefab data.
- [x] G9 - Restore Level14 Spiked Ball chains, source pendulum lengths/orientations, and serialized swing modes.
- [x] G10 - Make Sand/Mud/Ice solid surfaces; draw Sand/Mud in front, sink and slow the player in Sand/Mud, preserve ice momentum, and emit surface-specific particles.
- [x] G11 - Add the four Level10 saw hazards using the serialized Unity routes, endpoint motion, and movement speeds; preserve route metadata in custom-level serialization and draw saws behind terrain for the authored half-submerged appearance.
- [x] G12 - Resolve Rock Head carry displacement through terrain collision so riders stop at walls/ceilings and fall when the moving support leaves them; cover floating-point edge contact and route collision regressions.
- [x] G13 - Replace full-cell terrain collision with source Unity physics shapes and sprite-alpha fallback masks; use the authored Rock Head box, Spike Head polygon, and player collider.
- [x] G14 - Snap tile sprites to shared pixel boundaries, keep riders stable while they move, and align wall-slide/jump sprite pixels to the contacting wall.
- [x] G15 - Correct Level14 pendulum anchors from the Unity parent transforms and assert all four serialized world positions.
- [x] G16 - Tile background art through the full viewport over a persistent black canvas fill, and snap the wall-contacting player frame edge to the wall pixel.
- [x] G17 - Draw chain sprites along both Level10 endpoint-saw tracks, matching their horizontal and vertical oscillation routes.
- [x] G18 - Audit all campaign entity interactions, port the Level6 Arrow launch and restore Level18 Start/End/Checkpoint animations without inventing checkpoint respawn progression.
- [x] G19 - Damage the player when a moving Rock Head strikes their leading side; keep riders on top safe and test horizontal/vertical approach directions.
