export const SPRITE_ROOT = "./assets/PixelAdventureSprites/";

export const PLAYER_SKINS = ["Mask Dude", "Ninja Frog", "Pink Man", "Virtual Guy"];
export const PLAYER_STATES = ["Idle", "Run", "Jump", "Fall", "Double Jump", "Wall Jump", "Hit"];
export const APPEARING = { path: "Main Characters/Appearing (96x96).png", frames: 7, fps: 20 };
export const DISAPPEARING = { path: "Main Characters/Desappearing (96x96).png", frames: 7, fps: 20 };
export const LEVEL_REVEAL_DURATION = 2;
export const FRUITS = ["Apple", "Bananas", "Cherries", "Kiwi", "Melon", "Orange", "Pineapple", "Strawberry"];

const EXTRA_ASSETS = [
  APPEARING.path, DISAPPEARING.path,
  ...PLAYER_SKINS.flatMap((skin) => PLAYER_STATES.map((state) => "Main Characters/" + skin + "/" + state + " (32x32).png")),
  ...FRUITS.map((fruit) => "Items/Fruits/" + fruit + ".png"),
  ...["Box1", "Box2", "Box3"].flatMap((box) => ["Items/Boxes/" + box + "/Idle.png", "Items/Boxes/" + box + "/Hit (28x24).png", "Items/Boxes/" + box + "/Break.png"]),
  "Traps/Platforms/Brown On (32x8).png", "Traps/Platforms/Grey On (32x8).png",
  "Traps/Falling Platforms/On (32x10).png", "Traps/Falling Platforms/Off.png",
  "Traps/Fan/On (24x8).png", "Traps/Fan/Off.png",
  "Traps/Trampoline/Idle.png", "Traps/Trampoline/Jump (28x28).png",
  "Traps/Fire/On (16x32).png", "Traps/Fire/Off.png", "Traps/Fire/Hit (16x32).png",
  "Traps/Arrow/Idle (18x18).png",
  ...["Blink", "Bottom Hit", "Left Hit", "Right Hit", "Top Hit"].map((name) => "Traps/Spike Head/" + name + " (54x52).png"),
  ...["Blink", "Bottom Hit", "Left Hit", "Right Hit", "Top Hit"].map((name) => "Traps/Rock Head/" + name + " (42x42).png"),
  "Traps/Spike Head/Idle.png", "Traps/Rock Head/Idle.png", "Traps/Spiked Ball/Spiked Ball.png", "Traps/Spiked Ball/Chain.png",
  "Traps/Sand Mud Ice/Sand Particle.png", "Traps/Sand Mud Ice/Mud Particle.png", "Traps/Sand Mud Ice/Ice Particle.png",
  "Traps/Saw/On (38x38).png",
  "Items/Fruits/Collected.png", "Other/Dust Particle.png", "Other/Transition.png", "Other/Confetti (16x16).png",
  "Items/Checkpoints/Checkpoint/Checkpoint (No Flag).png",
  "Items/Checkpoints/Checkpoint/Checkpoint (Flag Idle)(64x64).png",
  "Items/Checkpoints/Checkpoint/Checkpoint (Flag Out) (64x64).png",
  "Items/Checkpoints/Start/Start (Idle).png", "Items/Checkpoints/Start/Start (Moving) (64x64).png",
  "Items/Checkpoints/End/End (Idle).png", "Items/Checkpoints/End/End (Pressed) (64x64).png",
  "Traps/Spikes/SpikesUp.png", "Traps/Spikes/SpikesDown.png", "Traps/Spikes/SpikesLeft.png", "Traps/Spikes/SpikesRight.png"
];

export function imageUrl(path) {
  return SPRITE_ROOT + path.split("/").map(encodeURIComponent).join("/");
}

export async function loadImages(levelData) {
  const paths = new Set(["Background/Blue.png", "Background/Brown.png", "Background/Gray.png", "Background/Green.png", "Background/Pink.png", "Background/Purple.png", "Background/Yellow.png", ...EXTRA_ASSETS]);
  for (const sprite of levelData.sprites) paths.add(sprite.src);
  const images = new Map();
  await Promise.all([...paths].map((path) => new Promise((resolve) => {
    const image = new Image();
    image.onload = () => { images.set(path, image); resolve(); };
    image.onerror = () => resolve();
    image.src = imageUrl(path);
  })));
  return images;
}

export function getImage(images, path) {
  return images.get(path) ?? null;
}
