import { loadImages } from "./assets.js";
import { Game } from "./game.js";
import { InputController } from "./input.js";
import { Renderer } from "./render.js";
import { LevelEditor, readCustomLevels, validateEntityList } from "./editor.js";

const canvas = document.querySelector("#game-canvas");
const app = document.querySelector("#app");
const worldSelect = document.querySelector("#world-select");
const previousButton = document.querySelector("#previous-button");
const restartButton = document.querySelector("#restart-button");
const nextButton = document.querySelector("#next-button");
const editButton = document.querySelector("#edit-button");
const stageTotal = document.querySelector("#stage-total");
const fruitCount = document.querySelector("#fruit-count");
const fruitTotal = document.querySelector("#fruit-total");
const pauseButton = document.querySelector("#pause-button");
const modal = document.querySelector("#modal");
const modalTitle = document.querySelector("#modal-title");
const modalCopy = document.querySelector("#modal-copy");
const resumeButton = document.querySelector("#resume-button");
const modalRestartButton = document.querySelector("#modal-restart-button");
const modalNextButton = document.querySelector("#modal-next-button");
const toast = document.querySelector("#toast");
const keyboardHint = document.querySelector("#keyboard-hint");
const guideToggle = document.querySelector("#guide-toggle");
const editorPanel = document.querySelector("#editor-panel");
const editorPalette = document.querySelector("#editor-palette");
const editorStatus = document.querySelector("#editor-status");
const GUIDE_PREFERENCE_KEY = "pixel-adventure-guides-v1";

function readGuidePreference() {
  try {
    return localStorage.getItem(GUIDE_PREFERENCE_KEY) !== "hidden";
  } catch {
    return true;
  }
}

function syncGuidePreference() {
  keyboardHint.hidden = !guideToggle.checked;
  try {
    localStorage.setItem(GUIDE_PREFERENCE_KEY, guideToggle.checked ? "shown" : "hidden");
  } catch {
    // The guide toggle still works for this visit if storage is unavailable.
  }
}

guideToggle.checked = readGuidePreference();
keyboardHint.hidden = !guideToggle.checked;
guideToggle.addEventListener("change", syncGuidePreference);

let game;
let renderer;
let editor;
let previousTime = 0;
let accumulator = 0;
let toastTimer;
let modalReturnFocus = null;

function setModalVisibility(visible) {
  const wasHidden = modal.hidden;
  modal.hidden = !visible;
  if (visible && wasHidden) {
    modalReturnFocus = document.activeElement;
    requestAnimationFrame(() => resumeButton.focus({ preventScroll: true }));
  } else if (!visible && !wasHidden) {
    const target = modalReturnFocus;
    modalReturnFocus = null;
    if (target instanceof HTMLElement && target.isConnected) target.focus({ preventScroll: true });
  }
}

function showToast(message) {
  toast.textContent = message;
  toast.classList.add("visible");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("visible"), 950);
}

function applySavedCustomLevel() {
  const saved = readCustomLevels()[String(game.level.id)];
  if (!Array.isArray(saved)) return;
  const entities = validateEntityList(saved, game.level.bounds);
  if (entities) game.setEntities(entities);
}

function loadLevelWithCustom(index, announce = true) {
  input.clear();
  game.loadLevel(index, announce);
  applySavedCustomLevel();
}

function restartWorld() {
  loadLevelWithCustom(game.levelIndex, true);
}

function previousWorld() {
  if (game.levelIndex <= 0) return;
  input.clear();
  game.previous();
  applySavedCustomLevel();
}

function nextWorld() {
  input.clear();
  if (game.next() === "next") applySavedCustomLevel();
}

function syncHud(state) {
  worldSelect.value = String(state.level);
  stageTotal.textContent = String(state.totalLevels).padStart(2, "0");
  fruitCount.textContent = String(state.collected);
  fruitTotal.textContent = String(state.totalFruit);
  const editing = Boolean(editor?.active);
  previousButton.disabled = editing || state.level <= 1;
  restartButton.disabled = editing;
  nextButton.disabled = editing;
  worldSelect.disabled = editing;
  editButton.disabled = editing || state.complete;
  editButton.textContent = editing ? "EDITING" : "EDIT";
  pauseButton.disabled = editing;
  pauseButton.textContent = editing ? "PAUSED" : state.paused && !state.complete ? "RESUME" : "PAUSE";
  pauseButton.setAttribute("aria-label", editing ? "Game paused in level editor" : state.paused && !state.complete ? "Resume game" : "Pause game");

  if (editing) {
    setModalVisibility(false);
    modalRestartButton.hidden = true;
    modalNextButton.hidden = true;
    return;
  }

  if (state.complete) {
    setModalVisibility(true);
    modalTitle.textContent = "ADVENTURE COMPLETE";
    modalCopy.textContent = "All 18 worlds are behind you. Ready for another run?";
    resumeButton.textContent = "PLAY AGAIN";
    modalRestartButton.hidden = true;
    modalNextButton.hidden = false;
    modalNextButton.textContent = "REPLAY WORLD 18";
  } else if (state.paused) {
    setModalVisibility(true);
    modalTitle.textContent = "PAUSED";
    modalCopy.textContent = "Take a breath. Your run is waiting.";
    resumeButton.textContent = "RESUME";
    modalRestartButton.hidden = false;
    modalNextButton.hidden = true;
  } else {
    setModalVisibility(false);
    modalRestartButton.hidden = false;
    modalNextButton.hidden = true;
  }
}

function togglePause() {
  if (game && !editor?.active) {
    input.clear();
    game.togglePause();
  }
}

function enableTouchActivation(button) {
  let synthesizedClickUntil = 0;
  let dispatchingTouchClick = false;
  button.addEventListener("click", (event) => {
    if (dispatchingTouchClick || performance.now() > synthesizedClickUntil) return;
    event.preventDefault();
    event.stopImmediatePropagation();
  }, true);
  button.addEventListener("keydown", (event) => {
    if (event.key === "Enter" || event.key === " ") synthesizedClickUntil = 0;
  });
  button.addEventListener("pointerup", (event) => {
    if (event.pointerType !== "touch" || button.disabled) return;
    event.preventDefault();
    synthesizedClickUntil = performance.now() + 750;
    dispatchingTouchClick = true;
    button.click();
    dispatchingTouchClick = false;
  });
}

const input = new InputController(app, togglePause);

try {
  const response = await fetch("./data/levels.json");
  if (!response.ok) throw new Error("Could not load campaign data (" + response.status + ")");
  const data = await response.json();
  for (const level of data.levels) {
    const option = document.createElement("option");
    option.value = String(level.id);
    option.textContent = String(level.id).padStart(2, "0");
    worldSelect.append(option);
  }
  const images = await loadImages(data);
  game = new Game(data, syncHud, showToast);
  renderer = new Renderer(canvas, data, images);
  editor = new LevelEditor({
    game, renderer, canvas, panel: editorPanel, palette: editorPalette, panControls: document.querySelector("#editor-pan"), status: editorStatus, editButton,
    undoButton: document.querySelector("#editor-undo"),
    eraseButton: document.querySelector("#editor-erase"),
    exportButton: document.querySelector("#editor-export"),
    cancelButton: document.querySelector("#editor-cancel"),
    saveButton: document.querySelector("#editor-save"),
    input, onToast: showToast
  });
  applySavedCustomLevel();

  worldSelect.addEventListener("change", () => loadLevelWithCustom(Number(worldSelect.value) - 1, true));
  previousButton.addEventListener("click", previousWorld);
  restartButton.addEventListener("click", restartWorld);
  nextButton.addEventListener("click", nextWorld);
  pauseButton.addEventListener("click", togglePause);
  resumeButton.addEventListener("click", () => {
    if (game.complete) loadLevelWithCustom(0, true);
    else game.setPaused(false);
  });
  modalRestartButton.addEventListener("click", restartWorld);
  modalNextButton.addEventListener("click", () => loadLevelWithCustom(game.data.levels.length - 1, true));
  for (const button of [previousButton, editButton, restartButton, pauseButton, nextButton, resumeButton, modalRestartButton, modalNextButton]) {
    enableTouchActivation(button);
  }
  app.addEventListener("game-restart", () => { if (!editor.active) restartWorld(); });
  modal.addEventListener("keydown", (event) => {
    if (event.key !== "Tab") return;
    const controls = [...app.querySelectorAll("button:not([hidden]), select:not([hidden]), input:not([hidden])")].filter((control) => !control.disabled && control.getClientRects().length > 0);
    const first = controls[0];
    const last = controls[controls.length - 1];
    if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
    else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
  });

  const fixedStep = 1 / 60;
  function animate(now) {
    const delta = previousTime ? Math.min((now - previousTime) / 1000, 0.08) : fixedStep;
    previousTime = now;
    if (!game.paused) {
      accumulator = Math.min(accumulator + delta, fixedStep * 5);
      while (accumulator >= fixedStep) {
        if (game.player.spawning || game.player.deadTimer > 0) input.clear();
        game.update(fixedStep, input.read());
        accumulator -= fixedStep;
      }
    } else {
      accumulator = 0;
    }
    renderer.draw(game, delta);
    requestAnimationFrame(animate);
  }
  requestAnimationFrame(animate);
} catch (error) {
  console.error("Pixel Adventure could not start", error);
  const context = canvas.getContext("2d");
  context.fillStyle = "#18222e";
  context.fillRect(0, 0, canvas.width || 960, canvas.height || 540);
  context.fillStyle = "#f6f0dd";
  context.font = "16px ui-monospace, monospace";
  context.fillText("Unable to load Pixel Adventure.", 28, 42);
}
