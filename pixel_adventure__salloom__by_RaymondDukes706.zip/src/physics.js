export function bodyBounds(body, x = body.x, y = body.y) {
  return {
    left: x - body.halfWidth,
    right: x + body.halfWidth,
    bottom: y + body.bottomOffset,
    top: y + body.topOffset
  };
}

export function intersects(a, b) {
  const tolerance = 1e-9;
  return a.left < b.right - tolerance && a.right > b.left + tolerance && a.bottom < b.top - tolerance && a.top > b.bottom + tolerance;
}

export function moveBody(body, dx, dy, solidRects, platformRects, onCollision) {
  const tolerance = 1e-9;
  let wall = 0;
  let wallRect = null;
  const beforeX = bodyBounds(body);
  const targetX = body.x + dx;
  const afterX = bodyBounds(body, targetX, body.y);
  if (dx > 0) {
    for (const rect of solidRects) {
      const verticalOverlap = beforeX.bottom < rect.top - tolerance && beforeX.top > rect.bottom + tolerance;
      if (!verticalOverlap || beforeX.right > rect.left + 0.04 || afterX.right <= rect.left + tolerance) continue;
      if (!wallRect || rect.left < wallRect.left) wallRect = rect;
    }
    if (wallRect) {
      body.x = wallRect.left - body.halfWidth;
      wall = 1;
    } else body.x = targetX;
  } else if (dx < 0) {
    for (const rect of solidRects) {
      const verticalOverlap = beforeX.bottom < rect.top - tolerance && beforeX.top > rect.bottom + tolerance;
      if (!verticalOverlap || beforeX.left < rect.right - 0.04 || afterX.left >= rect.right - tolerance) continue;
      if (!wallRect || rect.right > wallRect.right) wallRect = rect;
    }
    if (wallRect) {
      body.x = wallRect.right + body.halfWidth;
      wall = -1;
    } else body.x = targetX;
  }
  if (wallRect) onCollision?.(wallRect, "side");

  const beforeY = bodyBounds(body);
  const targetY = body.y + dy;
  const afterY = bodyBounds(body, body.x, targetY);
  let grounded = false;
  let ceiling = false;
  let landing = null;

  if (dy <= 0) {
    for (const rect of [...solidRects, ...platformRects]) {
      if (rect.oneWay && dy > 0) continue;
      const horizontalOverlap = afterY.left < rect.right - tolerance && afterY.right > rect.left + tolerance;
      const crossedTop = beforeY.bottom >= rect.top - 0.045 && afterY.bottom <= rect.top + 0.045;
      if (!horizontalOverlap || !crossedTop) continue;
      if (!landing || rect.top > landing.top) landing = rect;
    }
    if (landing) {
      body.y = landing.top - body.bottomOffset;
      grounded = true;
      onCollision?.(landing, "top");
    } else body.y = targetY;
  } else {
    let hit = null;
    for (const rect of solidRects) {
      const horizontalOverlap = afterY.left < rect.right - tolerance && afterY.right > rect.left + tolerance;
      const crossedBottom = beforeY.top <= rect.bottom + 0.045 && afterY.top >= rect.bottom - 0.045;
      if (!horizontalOverlap || !crossedBottom) continue;
      if (!hit || rect.bottom < hit.bottom) hit = rect;
    }
    if (hit) {
      body.y = hit.bottom - body.topOffset;
      ceiling = true;
      onCollision?.(hit, "bottom");
    } else body.y = targetY;
  }

  if (wall === 0 && Math.abs(dx) <= tolerance) {
    const bounds = bodyBounds(body);
    let nearest = 0.045;
    for (const rect of solidRects) {
      const verticalOverlap = bounds.bottom < rect.top - tolerance && bounds.top > rect.bottom + tolerance;
      if (!verticalOverlap) continue;
      const rightGap = Math.abs(bounds.right - rect.left);
      const leftGap = Math.abs(bounds.left - rect.right);
      if (rightGap < nearest) { wall = 1; wallRect = rect; nearest = rightGap; }
      if (leftGap < nearest) { wall = -1; wallRect = rect; nearest = leftGap; }
    }
    if (wallRect) onCollision?.(wallRect, "side");
  }

  return { wall, wallRect, grounded, ceiling, landing };
}

function projectPolygon(points, x, y, axis) {
  let min = Infinity;
  let max = -Infinity;
  for (const [px, py] of points) {
    const projection = (px + x) * axis.x + (py + y) * axis.y;
    min = Math.min(min, projection);
    max = Math.max(max, projection);
  }
  return [min, max];
}

function projectRect(rect, axis) {
  const corners = [
    [rect.left, rect.bottom], [rect.left, rect.top],
    [rect.right, rect.bottom], [rect.right, rect.top]
  ];
  let min = Infinity;
  let max = -Infinity;
  for (const [x, y] of corners) {
    const projection = x * axis.x + y * axis.y;
    min = Math.min(min, projection);
    max = Math.max(max, projection);
  }
  return [min, max];
}

export function polygonIntersectsRect(points, x, y, rect) {
  const axes = [{ x: 1, y: 0 }, { x: 0, y: 1 }];
  for (let i = 0; i < points.length; i++) {
    const [x1, y1] = points[i];
    const [x2, y2] = points[(i + 1) % points.length];
    const axis = { x: y1 - y2, y: x2 - x1 };
    if (axis.x || axis.y) axes.push(axis);
  }
  for (const axis of axes) {
    const [polygonMin, polygonMax] = projectPolygon(points, x, y, axis);
    const [rectMin, rectMax] = projectRect(rect, axis);
    if (polygonMax <= rectMin + 1e-9 || polygonMin >= rectMax - 1e-9) return false;
  }
  return true;
}

function sweptPolygonRect(points, x, y, dx, dy, rect) {
  const axes = [{ x: 1, y: 0 }, { x: 0, y: 1 }];
  for (let i = 0; i < points.length; i++) {
    const [x1, y1] = points[i];
    const [x2, y2] = points[(i + 1) % points.length];
    const axis = { x: y1 - y2, y: x2 - x1 };
    if (axis.x || axis.y) axes.push(axis);
  }

  let enter = -Infinity;
  let exit = Infinity;
  const tolerance = 1e-9;
  for (const axis of axes) {
    const [polygonMin, polygonMax] = projectPolygon(points, x, y, axis);
    const [rectMin, rectMax] = projectRect(rect, axis);
    const speed = dx * axis.x + dy * axis.y;
    if (Math.abs(speed) < tolerance) {
      if (polygonMax <= rectMin + tolerance || polygonMin >= rectMax - tolerance) return null;
      continue;
    }
    const first = (rectMin - polygonMax) / speed;
    const second = (rectMax - polygonMin) / speed;
    enter = Math.max(enter, Math.min(first, second));
    exit = Math.min(exit, Math.max(first, second));
    if (enter > exit + tolerance) return null;
  }
  if (exit <= tolerance || enter > 1 + tolerance) return null;
  return Math.max(0, enter);
}

export function movePolygon(body, dx, dy, localPoints, solidRects, onCollision) {
  let hit = null;
  let hitTime = Infinity;
  for (const rect of solidRects) {
    const time = sweptPolygonRect(localPoints, body.x, body.y, dx, dy, rect);
    if (time !== null && time < hitTime) {
      hit = rect;
      hitTime = time;
    }
  }
  if (!hit) {
    body.x += dx;
    body.y += dy;
    return { wall: 0, wallRect: null, grounded: false, ceiling: false, landing: null };
  }

  body.x += dx * hitTime;
  body.y += dy * hitTime;
  const wall = dx > 0 ? 1 : dx < 0 ? -1 : 0;
  const grounded = dy < 0;
  const ceiling = dy > 0;
  const side = wall ? "side" : ceiling ? "bottom" : "top";
  onCollision?.(hit, side);
  return { wall, wallRect: wall ? hit : null, grounded, ceiling, landing: grounded ? hit : null };
}
