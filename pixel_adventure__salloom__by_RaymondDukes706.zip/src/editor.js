export const EDITOR_SAVE_KEY = "pixel-adventure-custom-levels-v1";
export const MAX_EDITOR_ENTITIES = 512;

const fruits = ["Apple", "Bananas", "Cherries", "Kiwi", "Melon", "Orange", "Pineapple", "Strawberry"];
const boxes = ["Box1", "Box2", "Box3", "EmptyBox"];
const hazards = ["FireUp", "FireLeft", "FireRight", "Arrow", "Spike Head", "Rock Head", "Spiked Ball", "Saw"];

export const ENTITY_TEMPLATES = Object.freeze([
  ...fruits.map((name) => ({ kind: "fruit", name, label: name, image: "Items/Fruits/" + name + ".png" })),
  ...boxes.map((name) => ({ kind: "box", name, label: name, image: "Items/Boxes/" + (name === "EmptyBox" ? "Box1" : name) + "/Idle.png" })),
  { kind: "platform", name: "Platform", label: "Moving Platform", image: "Traps/Platforms/Brown On (32x8).png" },
  { kind: "checkpoint", name: "Start", label: "Start Marker", image: "Items/Checkpoints/Start/Start (Idle).png" },
  { kind: "checkpoint", name: "End", label: "End Marker", image: "Items/Checkpoints/End/End (Idle).png" },
  { kind: "checkpoint", name: "Checkpoint", label: "Checkpoint", image: "Items/Checkpoints/Checkpoint/Checkpoint (No Flag).png" },
  ...hazards.map((name) => ({
    kind: "hazard",
    name,
    label: name,
    image: name.startsWith("Fire") ? "Traps/Fire/Off.png" : name === "Arrow" ? "Traps/Arrow/Idle (18x18).png" : name === "Spike Head" ? "Traps/Spike Head/Idle.png" : name === "Rock Head" ? "Traps/Rock Head/Idle.png" : name === "Saw" ? "Traps/Saw/On (38x38).png" : "Traps/Spiked Ball/Spiked Ball.png"
  })),
  { kind: "fallingPlatform", name: "Falling Platform", label: "Falling Platform", image: "Traps/Falling Platforms/On (32x10).png" },
  { kind: "fan", name: "Fan", label: "Fan", image: "Traps/Fan/On (24x8).png" },
  { kind: "trampoline", name: "Trampoline", label: "Trampoline", image: "Traps/Trampoline/Idle.png" }
]);

const allowedTemplates = new Set(ENTITY_TEMPLATES.map((template) => template.kind + ":" + template.name));

export function serializeEntity(entity) {
  const serialized = {
    kind: entity.kind,
    name: entity.name,
    label: entity.label || entity.name,
    x: Number(entity.x),
    y: Number(entity.y)
  };
  if (entity.kind === "platform" && Array.isArray(entity.path) && entity.path.length === 2 && entity.path.every((point) => Array.isArray(point) && point.length === 2 && point.every(Number.isFinite)) && Number.isFinite(entity.speed) && entity.speed > 0 && ["interactive", "oscillate"].includes(entity.platformMode)) {
    serialized.platformMode = entity.platformMode;
    serialized.path = entity.path.map((point) => point.slice());
    serialized.speed = entity.speed;
    if (entity.platformMode === "oscillate" && Number.isInteger(entity.platformTarget)) serialized.platformTarget = entity.platformTarget;
    if (Number.isFinite(entity.waitTime)) serialized.waitTime = entity.waitTime;
    if (entity.style === "brown" || entity.style === "grey") serialized.style = entity.style;
    if (Number.isFinite(entity.colliderHeight)) serialized.colliderHeight = entity.colliderHeight;
    if (Number.isFinite(entity.colliderOffsetY)) serialized.colliderOffsetY = entity.colliderOffsetY;
  }
  const movingHead = entity.kind === "hazard" && (entity.name === "Rock Head" || entity.name === "Spike Head");
  const direction = entity.direction;
  if (movingHead && Array.isArray(direction) && direction.length === 2 && direction.every(Number.isFinite) && Math.abs(direction[0]) + Math.abs(direction[1]) === 1 && Number.isFinite(entity.speed) && entity.speed > 0) {
    serialized.direction = direction.slice();
    serialized.linear = entity.linear !== false;
    serialized.speed = entity.speed;
  }
  const sawPath = entity.path;
  if (entity.kind === "hazard" && entity.name === "Saw" && Array.isArray(sawPath) && sawPath.every((point) => Array.isArray(point) && point.length === 2 && point.every(Number.isFinite)) && Number.isFinite(entity.speed) && entity.speed > 0) {
    serialized.motion = entity.motion;
    serialized.path = sawPath.map((point) => point.slice());
    serialized.speed = entity.speed;
    if (entity.motion === "waypoints") serialized.pathIndex = entity.pathIndex;
    if (entity.motion === "oscillate") {
      serialized.motionPhase = entity.motionPhase;
      serialized.motionTime = entity.motionTime;
    }
  }
  const pendulum = entity.pendulum;
  if (entity.kind === "hazard" && entity.name === "Spiked Ball" && pendulum && [pendulum.length, pendulum.rotation, pendulum.thetaZero, pendulum.w, pendulum.direction].every(Number.isFinite) && pendulum.length > 0 && pendulum.w > 0) {
    serialized.pendulum = {
      length: pendulum.length, rotation: pendulum.rotation, thetaZero: pendulum.thetaZero,
      w: pendulum.w, circleMotion: Boolean(pendulum.circleMotion), direction: pendulum.direction
    };
  }
  return serialized;
}

export function validateEntity(entity, bounds, entityCount = 0) {
  if (!entity || !allowedTemplates.has(entity.kind + ":" + entity.name)) return "Unsupported entity.";
  if (!Number.isFinite(entity.x) || !Number.isFinite(entity.y)) return "Position must be finite.";
  if (!Array.isArray(bounds) || bounds.length !== 4 || !bounds.every(Number.isFinite)) return "Level bounds are invalid.";
  if (entity.x < bounds[0] || entity.x > bounds[2] || entity.y < bounds[1] || entity.y > bounds[3]) return "Position is outside the level bounds.";
  if (entity.kind === "platform" && (entity.path !== undefined || entity.platformMode !== undefined)) {
    if (!Array.isArray(entity.path) || entity.path.length !== 2 || !entity.path.every((point) => Array.isArray(point) && point.length === 2 && point.every(Number.isFinite)) || !["interactive", "oscillate"].includes(entity.platformMode) || !Number.isFinite(entity.speed) || entity.speed <= 0) return "Platform route data is invalid.";
    if (entity.platformMode === "oscillate" && (!Number.isInteger(entity.platformTarget) || entity.platformTarget < 0 || entity.platformTarget > 1)) return "Platform route data is invalid.";
    if (entity.waitTime !== undefined && (!Number.isFinite(entity.waitTime) || entity.waitTime < 0)) return "Platform wait time is invalid.";
    if (entity.style !== undefined && !["brown", "grey"].includes(entity.style)) return "Platform style is invalid.";
    if (entity.colliderHeight !== undefined && (!Number.isFinite(entity.colliderHeight) || entity.colliderHeight <= 0)) return "Platform collider is invalid.";
    if (entity.colliderOffsetY !== undefined && !Number.isFinite(entity.colliderOffsetY)) return "Platform collider is invalid.";
  }
  if (entity.kind === "hazard" && entity.name === "Saw" && (entity.motion !== undefined || entity.path !== undefined)) {
    const expectedPoints = entity.motion === "waypoints" ? 4 : entity.motion === "oscillate" ? 2 : 0;
    if (entity.path?.length !== expectedPoints || !entity.path.every((point) => Array.isArray(point) && point.length === 2 && point.every(Number.isFinite)) || !Number.isFinite(entity.speed) || entity.speed <= 0) return "Saw route data is invalid.";
    if (entity.motion === "waypoints" && (!Number.isInteger(entity.pathIndex) || entity.pathIndex < 0 || entity.pathIndex >= expectedPoints)) return "Saw route data is invalid.";
    if (entity.motion === "oscillate" && (!Number.isFinite(entity.motionPhase) || !Number.isFinite(entity.motionTime))) return "Saw route data is invalid.";
  }
  if (entityCount >= MAX_EDITOR_ENTITIES) return "The level entity limit has been reached.";
  return null;
}

export function validateEntityList(entities, bounds) {
  if (!Array.isArray(entities) || entities.length > MAX_EDITOR_ENTITIES) return null;
  const result = [];
  for (const entity of entities) {
    if (validateEntity(entity, bounds, 0)) return null;
    result.push(serializeEntity(entity));
  }
  return result;
}

export function buildCustomLevelExport(level, entities) {
  const cleanEntities = validateEntityList(entities, level.bounds);
  if (!cleanEntities) return null;
  return {
    format: "pixel-adventure-custom-level",
    version: 1,
    sourceLevelId: level.id,
    level: { ...level, entities: cleanEntities }
  };
}

export function readCustomLevels(storage = globalThis.localStorage) {
  try {
    const value = JSON.parse(storage.getItem(EDITOR_SAVE_KEY) || "{}");
    return value && typeof value === "object" && !Array.isArray(value) ? value : {};
  } catch {
    return {};
  }
}

export function saveCustomLevel(levelId, entities, storage = globalThis.localStorage) {
  const levels = readCustomLevels(storage);
  levels[String(levelId)] = entities.map(serializeEntity);
  storage.setItem(EDITOR_SAVE_KEY, JSON.stringify(levels));
}

export class LevelEditor {
  constructor({ game, renderer, canvas, panel, palette, panControls, status, editButton, undoButton, eraseButton, exportButton, cancelButton, saveButton, input, onToast = () => {} }) {
    this.game = game;
    this.renderer = renderer;
    this.canvas = canvas;
    this.panel = panel;
    this.palette = palette;
    this.panControls = panControls;
    this.status = status;
    this.editButton = editButton;
    this.undoButton = undoButton;
    this.eraseButton = eraseButton;
    this.exportButton = exportButton;
    this.cancelButton = cancelButton;
    this.saveButton = saveButton;
    this.input = input;
    this.onToast = onToast;
    this.active = false;
    this.selectedTool = null;
    this.eraseMode = false;
    this.undoStack = [];
    this.cancelState = null;

    for (const [index, template] of ENTITY_TEMPLATES.entries()) {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "entity-tool";
      button.dataset.toolIndex = String(index);
      button.setAttribute("aria-pressed", "false");
      const image = document.createElement("img");
      image.src = "./assets/PixelAdventureSprites/" + template.image.split("/").map(encodeURIComponent).join("/");
      image.alt = "";
      const label = document.createElement("span");
      label.textContent = template.label;
      button.append(image, label);
      palette.append(button);
    }

    palette.addEventListener("click", (event) => {
      const button = event.target.closest("button[data-tool-index]");
      if (!button) return;
      const index = Number(button.dataset.toolIndex);
      this.selectedTool = this.selectedTool === index ? null : index;
      this.eraseMode = false;
      this.updateTools();
      this.setStatus(this.selectedTool === null ? "Choose an asset, then tap or click the level to place it." : "Place " + ENTITY_TEMPLATES[this.selectedTool].label + ".");
    });
    editButton.addEventListener("click", () => this.enter());
    undoButton.addEventListener("click", () => this.undo());
    for (const button of panControls.querySelectorAll("[data-pan-x], [data-pan-y]")) {
      button.addEventListener("click", () => this.panView(Number(button.dataset.panX || 0), Number(button.dataset.panY || 0)));
    }
    window.addEventListener("keydown", (event) => {
      if (!this.active) return;
      const directions = { ArrowLeft: [-1, 0], KeyA: [-1, 0], ArrowRight: [1, 0], KeyD: [1, 0], ArrowUp: [0, 1], KeyW: [0, 1], ArrowDown: [0, -1], KeyS: [0, -1] };
      const direction = directions[event.code];
      if (!direction) return;
      event.preventDefault();
      this.panView(direction[0], direction[1]);
    });
    eraseButton.addEventListener("click", () => {
      this.eraseMode = !this.eraseMode;
      this.selectedTool = null;
      this.updateTools();
      this.setStatus(this.eraseMode ? "Tap or click an entity to remove it." : "Choose an asset, then tap or click the level to place it.");
    });
    exportButton.addEventListener("click", () => this.exportLevel());
    cancelButton.addEventListener("click", () => this.close(false));
    saveButton.addEventListener("click", () => this.saveAndExit());
    canvas.addEventListener("pointerdown", (event) => this.placeAtPointer(event));
  }

  enter() {
    if (this.active || this.game.complete) return;
    this.active = true;
    document.body.classList.add("editor-mode");
    this.panel.hidden = false;
    this.input.clear();
    this.cancelState = { entities: this.game.entities, collected: this.game.collected, totalFruit: this.game.totalFruit };
    this.game.setPaused(true);
    this.renderer.resize();
    this.renderer.scale = this.renderer.height / 14.5;
    this.renderer.camera = this.renderer.cameraTarget(this.game);
    this.renderer.cameraLocked = true;
    const stored = readCustomLevels()[String(this.game.level.id)];
    const restored = validateEntityList(stored, this.game.level.bounds);
    this.game.setEntities(restored || this.game.level.entities.map(serializeEntity));
    this.selectedTool = null;
    this.eraseMode = false;
    this.undoStack = [];
    this.updateTools();
    this.setStatus(restored ? "Saved custom placements loaded. Choose an asset to edit." : "Choose an asset, then tap or click the level to place it.");
  }

  close(keepChanges) {
    if (!this.active) return;
    if (!keepChanges && this.cancelState) {
      this.game.entities = this.cancelState.entities;
      this.game.collected = this.cancelState.collected;
      this.game.totalFruit = this.cancelState.totalFruit;
      this.game.notify();
    }
    this.cancelState = null;
    this.active = false;
    this.panel.hidden = true;
    this.renderer.cameraLocked = false;
    document.body.classList.remove("editor-mode");
    this.input.clear();
    this.game.setPaused(false);
    this.editButton.focus({ preventScroll: true });
  }

  panView(dx, dy) {
    if (!this.active || !this.renderer.camera) return;
    const bounds = this.game.level.bounds;
    const halfWidth = this.renderer.width / this.renderer.scale / 2;
    const halfHeight = this.renderer.height / this.renderer.scale / 2;
    const clamp = (value, min, max, half) => max - min <= half * 2 ? (min + max) / 2 : Math.max(min + half, Math.min(max - half, value));
    this.renderer.camera.x = clamp(this.renderer.camera.x + dx * 2, bounds[0] - 0.5, bounds[2] + 0.5, halfWidth);
    this.renderer.camera.y = clamp(this.renderer.camera.y + dy * 2, bounds[1] - 0.5, bounds[3] + 0.5, halfHeight);
  }

  setStatus(message) {
    this.status.textContent = message;
  }

  updateTools() {
    for (const button of this.palette.querySelectorAll("[data-tool-index]")) {
      button.setAttribute("aria-pressed", String(Number(button.dataset.toolIndex) === this.selectedTool));
    }
    this.eraseButton.setAttribute("aria-pressed", String(this.eraseMode));
    this.undoButton.disabled = this.undoStack.length === 0;
  }

  remember() {
    this.undoStack.push(this.game.entities.map(serializeEntity));
    if (this.undoStack.length > 50) this.undoStack.shift();
    this.updateTools();
  }

  undo() {
    const previous = this.undoStack.pop();
    if (!previous) return;
    this.game.setEntities(previous);
    this.updateTools();
    this.setStatus("Last placement change undone.");
  }

  placeAtPointer(event) {
    if (!this.active || event.button !== 0 || !this.renderer.camera || !this.renderer.scale) return;
    event.preventDefault();
    const rect = this.canvas.getBoundingClientRect();
    const x = Math.round((this.renderer.camera.x + (event.clientX - rect.left - rect.width / 2) / this.renderer.scale) * 2) / 2;
    const y = Math.round((this.renderer.camera.y - (event.clientY - rect.top - rect.height / 2) / this.renderer.scale) * 2) / 2;

    if (this.eraseMode) {
      let nearest = -1;
      let distance = 1.35;
      for (let index = 0; index < this.game.entities.length; index++) {
        const entity = this.game.entities[index];
        const candidate = Math.hypot(entity.x - x, entity.y - y);
        if (candidate < distance) { distance = candidate; nearest = index; }
      }
      if (nearest < 0) { this.setStatus("No entity near that position."); return; }
      this.remember();
      const entities = this.game.entities.map(serializeEntity);
      entities.splice(nearest, 1);
      this.game.setEntities(entities);
      this.setStatus("Entity removed. Undo is available.");
      return;
    }

    if (this.selectedTool === null) { this.setStatus("Choose an asset first."); return; }
    const template = ENTITY_TEMPLATES[this.selectedTool];
    const source = { kind: template.kind, name: template.name, label: template.label, x, y };
    const error = validateEntity(source, this.game.level.bounds, this.game.entities.length);
    if (error) { this.setStatus(error); return; }
    this.remember();
    this.game.setEntities([...this.game.entities.map(serializeEntity), source]);
    this.setStatus(template.label + " placed. Tap again to place another.");
  }

  currentEntities() {
    const entities = validateEntityList(this.game.entities.map(serializeEntity), this.game.level.bounds);
    if (!entities) throw new Error("This level contains invalid entity data.");
    return entities;
  }

  saveAndExit() {
    try {
      saveCustomLevel(this.game.level.id, this.currentEntities());
      this.setStatus("Custom placements saved.");
      this.onToast("CUSTOM LEVEL SAVED");
      this.close(true);
    } catch (error) {
      this.setStatus("Could not save: " + error.message);
    }
  }

  exportLevel() {
    try {
      const payload = buildCustomLevelExport(this.game.level, this.currentEntities());
      if (!payload) throw new Error("This level contains invalid entity data.");
      const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = "pixel-adventure-world-" + String(level.id).padStart(2, "0") + "-custom.json";
      document.body.append(link);
      link.click();
      link.remove();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
      this.setStatus("Custom level exported as JSON.");
      this.onToast("LEVEL JSON EXPORTED");
    } catch (error) {
      this.setStatus("Could not export: " + error.message);
    }
  }
}
