import { APPEARING, DISAPPEARING, LEVEL_REVEAL_DURATION, PLAYER_SKINS } from "./assets.js";
import { bodyBounds, intersects, moveBody, movePolygon, polygonIntersectsRect } from "./physics.js";

const ROCK_HEAD_COLLIDER = [[-1, -1], [1, -1], [1, 1], [-1, 1]];
const SPIKE_HEAD_COLLIDER = [[1.38, -0.56], [1.38, 0.5], [0.56, 1.31], [-0.5, 1.31], [-1.3, 0.5], [-1.3, -0.56], [-0.5, -1.35], [0.56, -1.35]];
const FIXED_GRAVITY = 9.81;
const PLAYER_HALF_WIDTH = 0.7;
const PLAYER_BOTTOM = -1;
const PLAYER_TOP = 0.5;
const SAVE_KEY = "pixel-adventure-progress-v1";

function readProgress() {
  try {
    const value = JSON.parse(localStorage.getItem(SAVE_KEY) || "{}");
    return { last: Math.max(1, Math.min(18, Number(value.last) || 1)) };
  } catch {
    return { last: 1 };
  }
}

function cellKey(x, y) {
  return x + "," + y;
}

function tileMaskRects(mask) {
  if (!Array.isArray(mask) || mask.length !== 16) return [];
  const rects = [];
  let active = new Map();
  for (let y = 0; y < 16; y++) {
    const spans = [];
    for (let x = 0; x < 16;) {
      if ((mask[y] & (1 << x)) === 0) { x++; continue; }
      const start = x++;
      while (x < 16 && (mask[y] & (1 << x)) !== 0) x++;
      spans.push([start, x]);
    }
    const next = new Map();
    for (const [start, end] of spans) {
      const key = start + ":" + end;
      const rect = active.get(key) || { left: start / 16, right: end / 16, bottom: y / 16, top: (y + 1) / 16 };
      rect.top = (y + 1) / 16;
      next.set(key, rect);
    }
    for (const [key, rect] of active) if (!next.has(key)) rects.push(rect);
    active = next;
  }
  rects.push(...active.values());
  return rects;
}

function entitySize(entity) {
  if (entity.kind === "box") return { width: entity.name === "EmptyBox" ? 1.25 : 1.3, height: 1.25 };
  if (entity.kind === "fallingPlatform" || entity.kind === "platform") return { width: 2, height: 0.55 };
  if (entity.kind === "trampoline") return { width: 1.55, height: 0.48 };
  if (entity.kind === "hazard") {
    const name = entity.name.toLowerCase();
    if (name.includes("spike head")) return { width: 2.68, height: 2.66 };
    if (name.includes("rock head")) return { width: 2, height: 2 };
    if (name.includes("fire")) return { width: 0.9, height: 1.45 };
    if (name.includes("spiked ball")) return { width: 1.7, height: 1.7 };
    if (name.includes("arrow")) return { width: 0.9, height: 0.9 };
    if (name.includes("saw")) return { width: 2.4, height: 2.4 };
    return { width: 1, height: 1 };
  }
  return { width: 1, height: 1 };
}

function entityRect(entity) {
  if (isFire(entity)) {
    // The prefab's base collider is offset down before its directional rotation.
    const name = entity.name.toLowerCase();
    if (name.includes("left")) return { left: entity.x, right: entity.x + 1, bottom: entity.y - 0.5, top: entity.y + 0.5, entity };
    if (name.includes("right")) return { left: entity.x - 1, right: entity.x, bottom: entity.y - 0.5, top: entity.y + 0.5, entity };
    if (name.includes("down")) return { left: entity.x - 0.5, right: entity.x + 0.5, bottom: entity.y, top: entity.y + 1, entity };
    return { left: entity.x - 0.5, right: entity.x + 0.5, bottom: entity.y - 1, top: entity.y, entity };
  }
  if (entity.kind === "checkpoint") {
    if (entity.name === "Start") return { left: entity.x - 0.375, right: entity.x + 1.75, bottom: entity.y - 2, top: entity.y - 1.5, entity };
    if (entity.name === "End") return { left: entity.x - 1.0625, right: entity.x + 1.0625, bottom: entity.y - 2, top: entity.y + 0.75, entity };
    return { left: entity.x - 1, right: entity.x, bottom: entity.y - 2, top: entity.y + 1, entity };
  }
  if (entity.kind === "platform" && Number.isFinite(entity.colliderHeight)) {
    const offsetY = Number.isFinite(entity.colliderOffsetY) ? entity.colliderOffsetY : 0;
    return {
      left: entity.x - 1, right: entity.x + 1,
      bottom: entity.y + offsetY - entity.colliderHeight / 2,
      top: entity.y + offsetY + entity.colliderHeight / 2,
      entity
    };
  }
  const size = entitySize(entity);
  const x = entity.pendulum ? entity.ballX : entity.x;
  const y = entity.pendulum ? entity.ballY : entity.y;
  return { left: x - size.width / 2, right: x + size.width / 2, bottom: y - size.height / 2, top: y + size.height / 2, entity };
}

function isFire(entity) {
  return entity.kind === "hazard" && entity.name.toLowerCase().includes("fire");
}

function isMovingHead(entity) {
  return entity.kind === "hazard" && (entity.name === "Rock Head" || entity.name === "Spike Head") && Array.isArray(entity.direction);
}

function isRockHead(entity) {
  return entity.kind === "hazard" && entity.name === "Rock Head";
}

function fireFlameRect(entity) {
  const name = entity.name.toLowerCase();
  if (name.includes("left")) return { left: entity.x - 1, right: entity.x - 0.1, bottom: entity.y - 0.35, top: entity.y + 0.35 };
  if (name.includes("right")) return { left: entity.x + 0.1, right: entity.x + 1, bottom: entity.y - 0.35, top: entity.y + 0.35 };
  if (name.includes("down")) return { left: entity.x - 0.35, right: entity.x + 0.35, bottom: entity.y - 1, top: entity.y - 0.1 };
  return { left: entity.x - 0.35, right: entity.x + 0.35, bottom: entity.y + 0.1, top: entity.y + 1 };
}

export class Game {
  constructor(levelData, onChange = () => {}, onToast = () => {}) {
    this.data = levelData;
    this.onChange = onChange;
    this.onToast = onToast;
    this.tileCollisionShapes = this.data.sprites.map((sprite) => tileMaskRects(sprite.collisionMask));
    this.progress = readProgress();
    this.levelIndex = this.progress.last - 1;
    this.paused = false;
    this.complete = false;
    this.loadLevel(this.levelIndex, false);
  }

  persist() {
    try {
      localStorage.setItem(SAVE_KEY, JSON.stringify(this.progress));
    } catch {
      // The game remains playable if browser storage is unavailable.
    }
  }

  loadLevel(index, announce = true, entitySources = null) {
    this.levelIndex = Math.max(0, Math.min(this.data.levels.length - 1, index));
    this.level = this.data.levels[this.levelIndex];
    this.progress.last = this.level.id;
    this.persist();
    this.elapsed = 0;
    this.transitionAge = 0;
    this.particles = [];
    this.shakeTime = 0;
    this.shakeDuration = 0;
    this.shakeMagnitude = 0;
    this.paused = false;
    this.complete = false;
    this.collected = 0;
    this.layerCellSets = new Map(this.level.layers.map((layer) => [layer, new Set(layer.cells.map(([x, y]) => cellKey(x, y)))]));
    this.layerCellIds = new Map(this.level.layers.map((layer) => [layer, new Map(layer.cells.map(([x, y, id]) => [cellKey(x, y), id]))]));
    this.surfaceLayers = this.getLayers(["Sand", "Mud", "Ice"]);
    this.entitySources = entitySources ?? this.level.entities;
    this.entities = this.createEntities(this.entitySources);
    this.totalFruit = this.entities.filter((entity) => entity.kind === "fruit").length;
    this.player = {
      x: this.level.spawn[0], y: this.level.spawn[1], vx: 0, vy: 0,
      halfWidth: PLAYER_HALF_WIDTH, bottomOffset: PLAYER_BOTTOM, topOffset: PLAYER_TOP,
      facing: 1, grounded: false, wall: 0, wallX: null, wallEntity: null, wallJumpFrom: 0, wallJumpWallX: null, jumpsLeft: 2, coyote: 0,
      deadTimer: 0, state: "fall", animTime: 0,
      sink: 0, moveDustClock: 0, iceDustClock: 0, ridingEntity: null, contacts: new Set(),
      skin: PLAYER_SKINS[Math.floor(Math.random() * PLAYER_SKINS.length)]
    };
    this.respawn();
    this.spawnRevealWait = LEVEL_REVEAL_DURATION;
    this.onChange(this.snapshot());
    if (announce) this.onToast("WORLD " + String(this.level.id).padStart(2, "0"));
  }

  createEntities(sources) {
    return sources.map((source) => ({
      ...source,
      active: true,
      hits: source.kind === "box" ? (source.name === "Box1" || source.name === "EmptyBox" ? 1 : 5) : 0,
      fireClock: 0,
      fireState: "idle",
      fanOn: source.kind === "fan" ? false : true,
      fanClock: 0,
      bounceTime: 0,
      fallClock: 0,
      falling: false,
      baseY: source.y,
      vy: 0,
      direction: Array.isArray(source.direction) ? source.direction.slice() : source.name === "Rock Head" || source.name === "Arrow" ? [0, 1] : source.name === "Spike Head" ? [1, 0] : null,
      arrowHitTime: 0,
      arrowTriggered: false,
      triggerTime: 0,
      triggered: false,
      flagged: false,
      linear: source.linear !== false,
      speed: source.speed ?? (source.name === "Rock Head" ? 0.4 : source.name === "Spike Head" ? 0.35 : 0),
      motionSpeed: 0,
      waitClock: 0,
      platformWaitClock: source.platformMode === "oscillate" ? Math.max(0, source.waitTime || 0) : 0,
      platformTarget: Number.isInteger(source.platformTarget) ? source.platformTarget : 1,
      deltaX: 0,
      deltaY: 0,
      hitDirection: null,
      hitElapsed: 0,
      breakTime: 0,
      breaking: false,
      fireHitTime: 0,
      effectClock: 0,
      pendulum: source.pendulum ? { ...source.pendulum, angle: 0 } : null,
      path: Array.isArray(source.path) ? source.path.map((point) => point.slice()) : null,
      pathIndex: Number.isInteger(source.pathIndex) ? source.pathIndex : 0,
      motionTime: Number.isFinite(source.motionTime) ? source.motionTime : 0,
      motionPhase: Number.isFinite(source.motionPhase) ? source.motionPhase : 0,
      ballX: source.x,
      ballY: source.y,
      phase: Math.random() * Math.PI * 2
    }));
  }

  setEntities(sources) {
    this.entitySources = sources;
    this.entities = this.createEntities(sources);
    this.totalFruit = this.entities.filter((entity) => entity.kind === "fruit").length;
    this.collected = 0;
    this.notify();
  }

  snapshot() {
    return {
      level: this.level.id,
      totalLevels: this.data.levels.length,
      collected: this.collected,
      totalFruit: this.totalFruit,
      paused: this.paused,
      complete: this.complete,
      playerState: this.player?.state,
      skin: this.player?.skin
    };
  }

  notify() {
    this.onChange(this.snapshot());
  }

  setPaused(value) {
    this.paused = value;
    this.notify();
  }

  togglePause() {
    this.setPaused(!this.paused);
  }

  restart() {
    this.loadLevel(this.levelIndex, true);
  }

  previous() {
    if (this.levelIndex > 0) this.loadLevel(this.levelIndex - 1, true);
  }

  next() {
    if (this.levelIndex === this.data.levels.length - 1) {
      this.complete = true;
      this.paused = true;
      this.persist();
      this.notify();
      return "complete";
    }
    this.persist();
    this.loadLevel(this.levelIndex + 1, true);
    return "next";
  }

  getLayers(names) {
    return this.level.layers.filter((layer) => names.includes(layer.name));
  }

  getTileRects(layers, bounds) {
    const rects = [];
    for (const layer of layers) {
      const ox = layer.origin[0];
      const oy = layer.origin[1];
      const minX = Math.floor(bounds.left - ox);
      const maxX = Math.floor(bounds.right - ox);
      const minY = Math.floor(bounds.bottom - oy);
      const maxY = Math.floor(bounds.top - oy);
      const cells = this.layerCellSets.get(layer);
      for (let x = minX; x <= maxX; x++) {
        for (let y = minY; y <= maxY; y++) {
          const key = cellKey(x, y);
          if (!cells.has(key)) continue;
          const id = this.layerCellIds.get(layer).get(key);
          const shape = id >= 0 ? this.tileCollisionShapes[id] : null;
          if (!shape) continue;
          for (const rect of shape) rects.push({ left: x + ox + rect.left, right: x + ox + rect.right, bottom: y + oy + rect.bottom, top: y + oy + rect.top, layer });
        }
      }
    }
    return rects;
  }

  staticTileLayers() {
    return this.getLayers(["Ground", "Blocks", "Sand", "Mud", "Ice"]);
  }

  platformLayers() {
    return this.getLayers(["Platforms"]);
  }

  emitParticles(x, y, count, color, options = {}) {
    const life = options.life ?? 0.35;
    for (let i = 0; i < count; i++) {
      this.particles.push({
        x: x + (Math.random() - 0.5) * (options.originX ?? 0.3),
        y: y + (Math.random() - 0.5) * (options.originY ?? 0.2),
        vx: (options.vx ?? 0) + (Math.random() - 0.5) * (options.spreadX ?? 3),
        vy: (options.vy ?? 1) + (Math.random() - 0.5) * (options.spreadY ?? 2),
        gravity: options.gravity ?? 8,
        age: 0, life, size: options.size ?? 0.16, color,
        texture: Boolean(options.texture),
        sprite: options.sprite || (options.texture ? "Other/Dust Particle.png" : null)
      });
    }
    if (this.particles.length > 180) this.particles.splice(0, this.particles.length - 180);
  }

  shakeCamera(magnitude = 0.12, duration = 0.14) {
    if (duration > this.shakeTime) {
      this.shakeTime = duration;
      this.shakeDuration = duration;
    }
    this.shakeMagnitude = Math.max(this.shakeMagnitude, magnitude);
  }

  updateParticles(dt) {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const particle = this.particles[i];
      particle.age += dt;
      if (particle.age >= particle.life) {
        this.particles.splice(i, 1);
        continue;
      }
      if (particle.confetti) particle.rotation += particle.rotationSpeed * dt;
      const previousBottom = particle.y - particle.size * 0.42;
      particle.vy -= particle.gravity * dt;
      particle.x += particle.vx * dt;
      particle.y += particle.vy * dt;
      if (particle.debris) {
        particle.vx *= Math.exp(-1.2 * dt);
        const bounds = {
          left: particle.x - particle.size / 2,
          right: particle.x + particle.size / 2,
          bottom: particle.y - particle.size * 0.42,
          top: particle.y + particle.size * 0.42
        };
        for (const rect of this.getTileRects(this.staticTileLayers(), bounds)) {
          if (particle.vy >= 0 || previousBottom < rect.top - 0.04 || bounds.bottom > rect.top || bounds.right <= rect.left || bounds.left >= rect.right) continue;
          particle.y = rect.top + particle.size * 0.42;
          if (particle.bounces === 0) {
            particle.bounces++;
            particle.flashStart = particle.age + 0.16;
            particle.life = particle.age + 0.5;
            particle.vy = Math.abs(particle.vy) * 0.24;
            particle.vx *= 0.55;
          } else {
            particle.vy = 0;
          }
          break;
        }
      }
    }
    this.shakeTime = Math.max(0, this.shakeTime - dt);
    if (this.shakeTime === 0) this.shakeMagnitude = 0;
  }

  rockHeadHitsPlayer(entity, startX, startY, dx, dy) {
    const player = this.player;
    if (!player || player.deadTimer > 0 || player.ridingEntity === entity) return false;
    const bounds = bodyBounds(player);
    const endX = entity.x;
    const endY = entity.y;
    const tolerance = 0.045;
    if (dx > 0 && endX > startX + 1e-9) {
      return bounds.left >= startX + 1 - tolerance && bounds.left <= endX + 1 + tolerance && bounds.right > startX + 1 + tolerance
        && bounds.bottom < startY + 1 - tolerance && bounds.top > startY - 1 + tolerance;
    }
    if (dx < 0 && endX < startX - 1e-9) {
      return bounds.right <= startX - 1 + tolerance && bounds.right >= endX - 1 - tolerance && bounds.left < startX - 1 - tolerance
        && bounds.bottom < startY + 1 - tolerance && bounds.top > startY - 1 + tolerance;
    }
    const horizontalOverlap = bounds.left < startX + 1 - tolerance && bounds.right > startX - 1 + tolerance;
    if (dy > 0 && endY > startY + 1e-9) {
      return horizontalOverlap && bounds.bottom >= startY + 1 - tolerance && bounds.bottom <= endY + 1 + tolerance && bounds.top > startY + 1 + tolerance;
    }
    if (dy < 0 && endY < startY - 1e-9) {
      return horizontalOverlap && bounds.top <= startY - 1 + tolerance && bounds.top >= endY - 1 - tolerance && bounds.bottom < startY - 1 - tolerance;
    }
    return false;
  }

  updateMovingHead(entity, dt) {
    const startX = entity.x;
    const startY = entity.y;
    if (entity.waitClock > 0) {
      entity.waitClock = Math.max(0, entity.waitClock - dt);
      if (entity.waitClock === 0) entity.motionSpeed = 0;
      entity.deltaX = 0;
      entity.deltaY = 0;
      return;
    }
    const [dx, dy] = entity.direction;
    entity.motionSpeed = Math.min(entity.speed * 50, entity.motionSpeed + dt * 50);
    const moveX = dx * entity.motionSpeed * dt;
    const moveY = dy * entity.motionSpeed * dt;
    let collision;
    if (entity.name === "Spike Head") {
      const rayDistance = 1.3;
      const rayEndX = entity.x + dx * rayDistance;
      const rayEndY = entity.y + dy * rayDistance;
      const rayBounds = {
        left: Math.min(entity.x, rayEndX) - 0.01,
        right: Math.max(entity.x, rayEndX) + 0.01,
        bottom: Math.min(entity.y, rayEndY) - 0.01,
        top: Math.max(entity.y, rayEndY) + 0.01
      };
      let hit = null;
      for (const rect of this.getTileRects(this.staticTileLayers(), rayBounds)) {
        if (dx > 0 && entity.y >= rect.bottom - 1e-9 && entity.y <= rect.top + 1e-9 && rect.left > entity.x + 1e-9 && rect.left <= rayEndX + 1e-9 && (!hit || rect.left < hit.left)) hit = rect;
        else if (dx < 0 && entity.y >= rect.bottom - 1e-9 && entity.y <= rect.top + 1e-9 && rect.right < entity.x - 1e-9 && rect.right >= rayEndX - 1e-9 && (!hit || rect.right > hit.right)) hit = rect;
        else if (dy > 0 && entity.x >= rect.left - 1e-9 && entity.x <= rect.right + 1e-9 && rect.bottom > entity.y + 1e-9 && rect.bottom <= rayEndY + 1e-9 && (!hit || rect.bottom < hit.bottom)) hit = rect;
        else if (dy < 0 && entity.x >= rect.left - 1e-9 && entity.x <= rect.right + 1e-9 && rect.top < entity.y - 1e-9 && rect.top >= rayEndY - 1e-9 && (!hit || rect.top > hit.top)) hit = rect;
      }
      if (hit) {
        if (dx > 0) entity.x = hit.left - rayDistance;
        else if (dx < 0) entity.x = hit.right + rayDistance;
        else if (dy > 0) entity.y = hit.bottom - rayDistance;
        else entity.y = hit.top + rayDistance;
        collision = { wall: dx > 0 ? 1 : dx < 0 ? -1 : 0, ceiling: dy > 0, grounded: dy < 0 };
      } else {
        entity.x += moveX;
        entity.y += moveY;
        collision = { wall: 0, ceiling: false, grounded: false };
      }
    } else {
      const points = ROCK_HEAD_COLLIDER;
      const bounds = {
        left: entity.x - 1 + Math.min(0, moveX) - 0.1,
        right: entity.x + 1 + Math.max(0, moveX) + 0.1,
        bottom: entity.y - 1 + Math.min(0, moveY) - 0.1,
        top: entity.y + 1 + Math.max(0, moveY) + 0.1
      };
      const body = { x: entity.x, y: entity.y };
      collision = movePolygon(body, moveX, moveY, points, this.getTileRects(this.staticTileLayers(), bounds), null);
      entity.x = body.x;
      entity.y = body.y;
    }
    if (isRockHead(entity) && this.rockHeadHitsPlayer(entity, startX, startY, dx, dy)) this.die();
    const blocked = dx > 0 ? collision.wall > 0 : dx < 0 ? collision.wall < 0 : dy > 0 ? collision.ceiling : collision.grounded;
    if (blocked) {
      entity.hitDirection = [dx, dy];
      entity.hitElapsed = 0;
      entity.hitTime = 0.22;
      if (entity.linear) entity.direction = [-dx, -dy];
      else if (dx === 0) entity.direction = [dy, dx];
      else entity.direction = [-dy, -dx];
      entity.waitClock = 1;
      this.shakeCamera(0.16, 0.14);
      this.emitParticles(entity.x, entity.y, 6, "#aeb5b4", { spreadX: 4, spreadY: 4, vy: 1.5, life: 0.36, size: 0.16 });
      const playerBounds = bodyBounds(this.player);
      const crushing = intersects(playerBounds, entityRect(entity)) && ((dx > 0 && this.player.x >= entity.x) || (dx < 0 && this.player.x <= entity.x) || (dy > 0 && this.player.y >= entity.y) || (dy < 0 && this.player.y <= entity.y));
      if (isRockHead(entity) && crushing) this.die();
    }
    entity.deltaX = entity.x - startX;
    entity.deltaY = entity.y - startY;
  }

  updateSaw(entity, dt) {
    if (!Array.isArray(entity.path) || entity.path.length < 2) return;
    const startX = entity.x;
    const startY = entity.y;
    if (entity.motion === "oscillate") {
      entity.motionTime += dt;
      const progress = (Math.sin(entity.motionTime * entity.speed + entity.motionPhase) + 1) * 0.5;
      entity.x = entity.path[0][0] + (entity.path[1][0] - entity.path[0][0]) * progress;
      entity.y = entity.path[0][1] + (entity.path[1][1] - entity.path[0][1]) * progress;
    } else if (entity.motion === "waypoints") {
      let distanceLeft = entity.speed * dt;
      let transitions = 0;
      while (distanceLeft > 0 && transitions <= entity.path.length) {
        const nextIndex = (entity.pathIndex + 1) % entity.path.length;
        const [targetX, targetY] = entity.path[nextIndex];
        const dx = targetX - entity.x;
        const dy = targetY - entity.y;
        const distance = Math.hypot(dx, dy);
        if (distance <= distanceLeft + 1e-9) {
          entity.x = targetX;
          entity.y = targetY;
          entity.pathIndex = nextIndex;
          distanceLeft -= distance;
          transitions++;
        } else {
          entity.x += dx / distance * distanceLeft;
          entity.y += dy / distance * distanceLeft;
          distanceLeft = 0;
        }
      }
    }
    entity.deltaX = entity.x - startX;
    entity.deltaY = entity.y - startY;
  }

  updatePlatform(entity, dt) {
    if (!Array.isArray(entity.path) || entity.path.length < 2) return;
    const startX = entity.x;
    const startY = entity.y;
    const mode = entity.platformMode;
    let target;
    if (mode === "interactive") {
      target = entity.path[this.player.ridingEntity === entity ? 0 : 1];
    } else if (mode === "oscillate") {
      if (entity.platformWaitClock > 0) {
        entity.platformWaitClock = Math.max(0, entity.platformWaitClock - dt);
        entity.deltaX = 0;
        entity.deltaY = 0;
        return;
      }
      target = entity.path[entity.platformTarget];
    } else {
      return;
    }
    const dx = target[0] - entity.x;
    const dy = target[1] - entity.y;
    const distance = Math.hypot(dx, dy);
    const step = Math.max(0, entity.speed ?? 5) * dt;
    if (distance <= step + 1e-9) {
      entity.x = target[0];
      entity.y = target[1];
      if (mode === "oscillate") {
        entity.platformTarget = entity.platformTarget === 0 ? 1 : 0;
        entity.platformWaitClock = Math.max(0, entity.waitTime ?? 1);
      }
    } else if (distance > 0) {
      entity.x += dx / distance * step;
      entity.y += dy / distance * step;
    }
    entity.deltaX = entity.x - startX;
    entity.deltaY = entity.y - startY;
  }

  dynamicSolidRects(bounds) {
    const rects = [];
    for (const entity of this.entities) {
      const solidTrap = isFire(entity) || isRockHead(entity);
      const solidMarker = entity.kind === "checkpoint" && entity.name !== "Checkpoint";
      if (!entity.active || (!solidTrap && !solidMarker && !["box", "platform", "fallingPlatform", "trampoline"].includes(entity.kind))) continue;
      if (entity.kind === "fallingPlatform" && entity.falling) continue;
      const rect = entityRect(entity);
      if (rect.right < bounds.left - 1 || rect.left > bounds.right + 1 || rect.top < bounds.bottom - 1 || rect.bottom > bounds.top + 1) continue;
      rects.push({ ...rect, oneWay: !solidTrap && entity.kind !== "box" && !solidMarker });
    }
    return rects;
  }

  nearbySolids() {
    const bounds = bodyBounds(this.player);
    bounds.left -= 3; bounds.right += 3; bounds.bottom -= 3; bounds.top += 3;
    const staticRects = this.getTileRects(this.staticTileLayers(), bounds);
    const dynamicRects = this.dynamicSolidRects(bounds);
    return {
      solid: [...staticRects, ...dynamicRects.filter((rect) => !rect.oneWay)],
      platforms: [...this.getTileRects(this.platformLayers(), bounds).map((rect) => ({ ...rect, oneWay: true })), ...dynamicRects.filter((rect) => rect.oneWay)]
    };
  }

  currentSurface() {
    const footY = Math.floor(this.player.y + this.player.bottomOffset - 0.03);
    for (const layer of this.surfaceLayers) {
      const cx = Math.floor(this.player.x - layer.origin[0]);
      const cy = Math.floor(footY - layer.origin[1]);
      if (this.layerCellSets.get(layer).has(cellKey(cx, cy))) return layer;
    }
    return null;
  }

  updateEntityMotion(dt) {
    for (const entity of this.entities) {
      if (entity.collecting) {
        entity.collectTime = Math.max(0, entity.collectTime - dt);
        if (entity.collectTime === 0) entity.collecting = false;
      }
      if (entity.breaking) {
        entity.breakTime = Math.max(0, entity.breakTime - dt);
        if (entity.breakTime === 0) entity.breaking = false;
      }
      if (entity.kind === "checkpoint" && entity.triggerTime > 0) {
        entity.triggerTime = Math.max(0, entity.triggerTime - dt);
        if (entity.triggerTime === 0 && entity.name === "Checkpoint") entity.flagged = true;
      }
      if (!entity.active) continue;
      entity.phase += dt;
      if (entity.arrowHitTime > 0) {
        entity.arrowHitTime = Math.max(0, entity.arrowHitTime - dt);
        if (entity.arrowHitTime === 0) entity.active = false;
      }
      if (entity.hitTime > 0) { entity.hitTime = Math.max(0, entity.hitTime - dt); entity.hitElapsed += dt; }
      if (entity.fireHitTime > 0) entity.fireHitTime = Math.max(0, entity.fireHitTime - dt);
      if (entity.bounceTime > 0) entity.bounceTime = Math.max(0, entity.bounceTime - dt);
      if (entity.kind === "fan") {
        entity.fanClock += dt;
        if (entity.fanClock >= 5) { entity.fanClock = 0; entity.fanOn = !entity.fanOn; }
        if (entity.fanOn) {
          entity.effectClock -= dt;
          if (entity.effectClock <= 0) {
            this.emitParticles(entity.x, entity.y + 0.45, 1, "#e4f3ec", { texture: true, originX: 0.8, originY: 0.4, spreadX: 1.1, spreadY: 1.6, vy: 4.2, gravity: 0.25, life: 0.9, size: 0.28 });
            entity.effectClock = 0.12;
          }
        }
      }
      if (entity.pendulum) {
        const baseAngle = entity.pendulum.rotation * Math.PI / 180;
        const swing = entity.pendulum.circleMotion
          ? entity.pendulum.direction * entity.pendulum.w * 50 * this.elapsed * Math.PI / 180
          : entity.pendulum.thetaZero * 100 / Math.max(0.01, entity.pendulum.w) * Math.sin(entity.pendulum.w * 0.5 * this.elapsed) * Math.PI / 180;
        entity.pendulum.angle = baseAngle + swing;
        entity.ballX = entity.x + Math.sin(entity.pendulum.angle) * entity.pendulum.length;
        entity.ballY = entity.y - Math.cos(entity.pendulum.angle) * entity.pendulum.length;
      }
      if (isMovingHead(entity)) {
        entity.deltaX = 0;
        entity.deltaY = 0;
        this.updateMovingHead(entity, dt);
      } else if (entity.kind === "hazard" && entity.name === "Saw" && entity.path) {
        entity.deltaX = 0;
        entity.deltaY = 0;
        this.updateSaw(entity, dt);
      }
      if (entity.kind === "platform") {
        entity.deltaX = 0;
        entity.deltaY = 0;
        this.updatePlatform(entity, dt);
      }
      if (entity.spawned && entity.kind === "fruit") {
        const previousBottom = entity.y - 0.35;
        entity.vy -= 42 * dt;
        entity.x += entity.vx * dt;
        entity.y += entity.vy * dt;
        entity.vx *= 0.985;
        const bounds = { left: entity.x - 0.35, right: entity.x + 0.35, bottom: entity.y - 0.35, top: entity.y + 0.35 };
        for (const rect of this.getTileRects(this.staticTileLayers(), bounds)) {
          if (entity.vy < 0 && previousBottom >= rect.top - 0.04 && bounds.bottom <= rect.top && bounds.right > rect.left && bounds.left < rect.right) {
            entity.y = rect.top + 0.35;
            entity.vy = 0;
            entity.vx = 0;
            entity.spawned = false;
            break;
          }
        }
      }
      if (entity.kind === "fallingPlatform") {
        if (!entity.falling) {
          entity.y = entity.baseY + Math.sin(this.elapsed * 2 + entity.phase) * 0.01;
          entity.effectClock -= dt;
          if (entity.effectClock <= 0) {
            this.emitParticles(entity.x, entity.y + 0.18, 1, "#eee9d8", { texture: true, sprite: "Other/Dust Particle.png", originX: 1.1, spreadX: 0.8, vy: -4.2, gravity: 0.25, life: 0.9, size: 0.24 });
            entity.effectClock = 0.22;
          }
        } else {
          entity.vy -= 38 * dt;
          entity.y += entity.vy * dt;
          if (entity.y < this.level.bounds[1] - 6) entity.active = false;
        }
        if (entity.fallClock > 0) {
          entity.fallClock -= dt;
          if (entity.fallClock <= 0) { entity.falling = true; entity.vy = -1; }
        }
      } else if (isFire(entity)) {
        if (entity.fireState === "arming") {
          entity.fireClock -= dt;
          if (entity.fireClock <= 0) { entity.fireState = "on"; entity.fireClock = 2; }
        } else if (entity.fireState === "on") {
          entity.fireClock -= dt;
          if (entity.fireClock <= 0) { entity.fireState = "idle"; }
        }
      }
    }
  }

  jump(wallJump = false) {
    const player = this.player;
    if (wallJump) {
      player.wallJumpFrom = player.wall;
      player.wallJumpWallX = player.wallX;
      player.vx = -player.wall * 4.3;
      player.facing = Math.sign(player.vx) || player.facing;
      player.vy = 21.5;
      player.jumpsLeft = Math.max(0, player.jumpsLeft - 1);
      player.state = "wallJump";
    } else {
      player.wallJumpFrom = 0;
      player.wallJumpWallX = null;
      player.vy = 21.5;
      player.jumpsLeft = Math.max(0, player.jumpsLeft - 1);
      player.state = player.jumpsLeft === 1 ? "jump" : "doubleJump";
    }
    player.grounded = false;
    player.ridingEntity = null;
    player.coyote = 0;
  }

  updatePlayer(dt, input) {
    const player = this.player;
    if (player.deadTimer > 0) {
      const step = Math.min(dt, player.deadTimer);
      player.deadTimer = Math.max(0, player.deadTimer - dt);
      player.animTime += step;
      if (player.state === "hit") {
        player.y = Math.min(player.deathTargetY, player.y + player.vy * step);
        if (player.deadTimer <= 1e-9) {
          player.y = player.deathTargetY;
          player.vy = 0;
          player.state = "disappearing";
          player.animTime = 0;
          player.deadTimer = DISAPPEARING.frames / DISAPPEARING.fps;
        }
      } else if (player.state === "disappearing") {
        if (player.deadTimer <= 1e-9) {
          player.state = "deathWait";
          player.animTime = 0;
          player.deadTimer = 2.5;
        }
      } else if (player.deadTimer <= 1e-9) {
        this.loadLevel(this.levelIndex, false, this.entitySources);
      }
      return;
    }

    const riderAtStart = player.ridingEntity?.active ? player.ridingEntity : null;
    const carryX = riderAtStart?.deltaX || 0;
    const carryY = riderAtStart?.deltaY || 0;
    if (!riderAtStart) player.ridingEntity = null;
    const wasGrounded = player.grounded;
    const surfaceLayer = this.currentSurface();
    const surfaceName = surfaceLayer?.name;
    const jumpingFromSurface = input.jumpPressed && (player.grounded || player.coyote > 0) && (surfaceName === "Sand" || surfaceName === "Mud");
    if (jumpingFromSurface) {
      const sprite = "Traps/Sand Mud Ice/" + surfaceName + " Particle.png";
      this.emitParticles(player.x, player.y + player.bottomOffset, 8, "#eee4c1", { texture: true, sprite, spreadX: 5, spreadY: 3, vy: 3.2, gravity: 8, life: 0.48, size: 0.3 });
    }

    const solids = this.nearbySolids();
    const wallJump = input.jumpPressed && !player.grounded && player.wall !== 0 && player.vy < 1;
    if (input.jumpPressed && (player.grounded || player.coyote > 0) && player.jumpsLeft > 0) this.jump();
    else if (wallJump) this.jump(true);
    else if (input.jumpPressed && player.jumpsLeft > 0) this.jump();
    const carried = riderAtStart && player.ridingEntity === riderAtStart;
    if (carried) solids.solid = solids.solid.filter((rect) => rect.entity !== riderAtStart);

    const surfaceDrag = Math.max(0, Math.min(1, surfaceLayer?.physics?.drag ?? 0));
    const groundDrag = Math.max(0, Math.min(1, surfaceLayer?.physics?.endDrag ?? 0.3));
    const move = input.move;
    const surfaceSpeed = surfaceName === "Sand" ? 4.5 : surfaceName === "Mud" ? 3.5 : 10;
    const moveScale = surfaceName === "Sand" ? 0.48 : surfaceName === "Mud" ? 0.35 : 1;
    if (player.grounded) player.vx *= move ? 1 - surfaceDrag : 1 - groundDrag;
    else if (!move) player.vx *= 0.8;
    else if (player.vy < 0) player.vx *= 0.87;
    if (move) {
      player.vx += move * 45 * dt * moveScale;
      player.facing = move;
    }
    for (const fan of this.entities) {
      if (fan.active && fan.fanOn && fan.kind === "fan" && Math.abs(fan.x - player.x) < 1.25 && player.y >= fan.y && player.y <= fan.y + 14) {
        player.vx += 30 * dt;
        player.vy += 90 * dt;
      }
    }

    const gravityScale = player.grounded ? 0 : player.vy < 0 ? 8 : 7;
    player.vy -= FIXED_GRAVITY * gravityScale * dt;
    player.vx = Math.max(-surfaceSpeed, Math.min(surfaceSpeed, player.vx));

    const contacts = new Set();
    const hitBoxes = new Set();
    const result = moveBody(player, player.vx * dt + carryX, player.vy * dt + carryY, solids.solid, solids.platforms, (rect, side) => {
      const entity = rect.entity;
      if (!entity) return;
      contacts.add(entity);
      if (entity.kind === "box" && !player.contacts.has(entity) && !hitBoxes.has(entity)) {
        hitBoxes.add(entity);
        this.hitBox(entity, side);
      }
      if (isFire(entity) && !player.contacts.has(entity) && entity.fireState === "idle") {
        entity.fireState = "arming";
        entity.fireClock = 1;
        entity.fireHitTime = 0.3;
      }
      if (isRockHead(entity) && side === "top") player.ridingEntity = entity;
      if (entity.kind === "platform" && !player.contacts.has(entity) && player.y > entity.y) player.ridingEntity = entity;
      if (entity.kind === "checkpoint" && !player.contacts.has(entity)) this.activateCheckpoint(entity);
    });
    if (result.landing?.entity) contacts.add(result.landing.entity);
    if (result.wall) {
      player.wall = result.wall;
      player.wallX = result.wallRect ? result.wall > 0 ? result.wallRect.left : result.wallRect.right : null;
      player.wallEntity = result.wallRect?.entity || null;
      player.vx = 0;
    } else {
      player.wall = 0;
      player.wallX = null;
      player.wallEntity = null;
    }
    const riderBounds = carried ? entityRect(riderAtStart) : null;
    const playerBoundsAfter = bodyBounds(player);
    const riderSupported = Boolean(riderBounds && Math.abs(playerBoundsAfter.bottom - riderBounds.top) <= 0.045 && playerBoundsAfter.left < riderBounds.right && playerBoundsAfter.right > riderBounds.left);
    const riderTouching = Boolean(riderBounds && intersects(playerBoundsAfter, riderBounds));
    if (riderSupported) {
      player.y = riderBounds.top - player.bottomOffset;
      player.ridingEntity = riderAtStart;
      contacts.add(riderAtStart);
    } else if (carried && riderTouching) {
      player.ridingEntity = riderAtStart;
      contacts.add(riderAtStart);
    } else if (carried && player.ridingEntity === riderAtStart) {
      player.ridingEntity = null;
    }
    const landedBox = result.landing?.entity?.kind === "box" && hitBoxes.has(result.landing.entity);
    player.grounded = (result.grounded || riderSupported) && !landedBox;
    player.contacts = contacts;
    if (!player.grounded && player.ridingEntity && result.landing?.entity !== player.ridingEntity) player.ridingEntity = null;

    const groundedSurface = surfaceName || result.landing?.layer?.name;
    if (player.grounded && (groundedSurface === "Sand" || groundedSurface === "Mud")) {
      const maxSink = groundedSurface === "Sand" ? 0.58 : 0.8;
      player.sink = Math.min(maxSink, player.sink + dt * (groundedSurface === "Sand" ? 0.9 : 1.5));
    } else {
      player.sink = Math.max(0, player.sink - dt * 4);
    }

    if (landedBox) {
      player.vy = 20;
      player.jumpsLeft = 2;
      player.coyote = 0;
      player.state = "jump";
    } else if (player.grounded) {
      player.vy = 0;
      player.jumpsLeft = 2;
      player.coyote = 0.2;
      if (result.landing?.entity?.kind === "trampoline") {
        player.vy = 37;
        result.landing.entity.bounceTime = 0.4;
        this.shakeCamera(0.12, 0.12);
        this.emitParticles(player.x, player.y + player.bottomOffset, 7, "#f3e7b6", { spreadX: 4, spreadY: 2, vy: 1.5, life: 0.3, size: 0.14 });
      } else if (!wasGrounded) {
        const sprite = ["Sand", "Mud", "Ice"].includes(groundedSurface) ? "Traps/Sand Mud Ice/" + groundedSurface + " Particle.png" : "Other/Dust Particle.png";
        this.emitParticles(player.x, player.y + player.bottomOffset, 6, "#f3edcf", { texture: true, sprite, spreadX: 3, spreadY: 1, vy: 1.3, gravity: 12, life: 0.24, size: 0.3 });
      }
      if (result.landing?.entity?.kind === "fallingPlatform") result.landing.entity.fallClock ||= 0.5;
      const running = Math.abs(player.vx) > 0.45 && !(groundedSurface === "Ice" && move === 0);
      player.state = running ? "run" : "idle";
    } else {
      if (wasGrounded) player.coyote = 0.2;
      else player.coyote = Math.max(0, player.coyote - dt);
      if (player.wall && player.vy < 0 && (!move || move === player.wall)) {
        player.vy = Math.max(player.vy, -3);
        player.jumpsLeft = 2;
        player.state = "wall";
      } else if (player.vy < -0.5) player.state = "fall";
      else if (player.state !== "doubleJump" && player.state !== "wallJump") player.state = "jump";
    }

    if (player.grounded && move && Math.abs(player.vx) > 0.5) {
      player.moveDustClock += dt;
      const interval = surfaceName === "Sand" || surfaceName === "Mud" ? 0.11 : 0.15;
      if (player.moveDustClock >= interval) {
        const sprite = ["Sand", "Mud", "Ice"].includes(surfaceName) ? "Traps/Sand Mud Ice/" + surfaceName + " Particle.png" : "Other/Dust Particle.png";
        this.emitParticles(player.x - move * 0.38, player.y + player.bottomOffset, surfaceName === "Sand" || surfaceName === "Mud" ? 2 : 1, "#f3edcf", { texture: true, sprite, spreadX: 1.5, spreadY: 1.2, vy: surfaceName === "Sand" || surfaceName === "Mud" ? 2.2 : 0.8, gravity: 6, life: 0.34, size: 0.25 });
        player.moveDustClock = 0;
      }
    } else {
      player.moveDustClock = 0;
    }
    if (surfaceName === "Ice" && Math.abs(player.vx) > 5) {
      player.iceDustClock += dt;
      if (player.iceDustClock > 0.3) {
        this.emitParticles(player.x, player.y + player.bottomOffset, 1, "#cfeaf1", { texture: true, sprite: "Traps/Sand Mud Ice/Ice Particle.png", spreadX: 1.2, spreadY: 0.8, vy: 0.2, gravity: 0, life: 0.35, size: 0.2 });
        player.iceDustClock = 0;
      }
    } else {
      player.iceDustClock = 0;
    }

    player.animTime += dt;
    if (player.y < this.level.bounds[1] - 5) this.die();
    this.collectAndTrigger(dt);
  }

  hitBox(box, contact = "bottom") {
    if (!box.active || box.hits === Infinity) return;
    box.hits--;
    box.hitTime = 0.22;
    this.shakeCamera(0.06, 0.08);
    if (contact === "top" || (contact === "side" && this.player.y > box.y)) this.player.vy = 20;
    else this.player.vy = Math.min(0, this.player.vy);
    let drops = 0;
    if (box.name === "Box1") drops = box.hits <= 0 ? 3 : 0;
    if (box.name === "Box2") drops = 1;
    if (box.name === "Box3") drops = box.hits <= 0 ? 7 : 0;
    if (drops) this.spawnFruits(box, drops);
    if (box.hits <= 0) {
      this.spawnBoxDebris(box);
      box.active = false;
      box.breaking = true;
      box.breakTime = 0.2;
    }
  }

  spawnBoxDebris(box) {
    const variant = box.name === "Box2" || box.name === "Box3" ? box.name : "Box1";
    const sprite = "Items/Boxes/" + variant + "/Break.png";
    for (let i = 0; i < 4; i++) {
      this.particles.push({
        x: box.x + (Math.random() - 0.5) * 0.28,
        y: box.y + (Math.random() - 0.5) * 0.2,
        vx: (i - 1.5) * 1.7 + (Math.random() - 0.5) * 1.2,
        vy: 4.5 + Math.random() * 3,
        gravity: 24,
        age: 0,
        life: 2.5,
        size: 0.86,
        texture: true,
        sprite,
        debris: true,
        spriteFrame: i,
        bounces: 0,
        flashStart: null
      });
    }
  }

  spawnFruits(box, count) {
    const varieties = ["Apple", "Bananas", "Cherries", "Kiwi", "Melon", "Orange", "Pineapple", "Strawberry"];
    for (let i = 0; i < count; i++) {
      const name = varieties[Math.floor(Math.random() * varieties.length)];
      const entity = {
        kind: "fruit", name, label: name, x: box.x + (Math.random() - 0.5) * 0.35,
        y: box.y + 0.4, active: true, phase: Math.random() * Math.PI * 2,
        vx: (Math.random() - 0.5) * 6, vy: 7 + Math.random() * 3, spawned: true
      };
      this.entities.push(entity);
      this.totalFruit++;
    }
    this.notify();
  }

  activateCheckpoint(entity) {
    if (entity.triggered) return;
    entity.triggered = true;
    entity.triggerTime = entity.name === "Checkpoint" ? 1.3 : entity.name === "Start" ? 0.85 : 0.4;
    if (this.level.id === 18 && entity.name === "End") {
      const sprite = "Other/Confetti (16x16).png";
      for (let i = 0; i < 96; i++) {
        this.particles.push({
          x: this.player.x + (Math.random() - 0.5) * 22,
          y: this.player.y + 7.4 + Math.random() * 4.2,
          vx: (Math.random() - 0.5) * 1.3,
          vy: 0,
          gravity: 3.5 + Math.random() * 2,
          age: 0,
          life: 5.5,
          size: 0.3 + Math.random() * 0.12,
          texture: true,
          sprite,
          confetti: true,
          spriteFrame: i % 6,
          rotation: Math.random() * Math.PI * 2,
          rotationSpeed: (Math.random() - 0.5) * 8
        });
      }
      if (this.particles.length > 180) this.particles.splice(0, this.particles.length - 180);
    }
  }

  collectAndTrigger(dt = 1 / 60) {
    const player = this.player;
    if (player.deadTimer > 0) return;
    const bounds = bodyBounds(player);
    let changed = false;
    for (const entity of this.entities) {
      if (player.deadTimer > 0) break;
      if (!entity.active) continue;
      if (entity.kind === "checkpoint") {
        if (entity.name === "Checkpoint" && !entity.triggered && intersects(bounds, entityRect(entity))) this.activateCheckpoint(entity);
      } else if (entity.kind === "fruit") {
        const dx = player.x - entity.x;
        const dy = player.y - 0.25 - entity.y;
        if (dx * dx + dy * dy < 1.15 * 1.15) {
          entity.active = false;
          entity.collecting = true;
          entity.collectTime = 0.3;
          this.collected++;
          changed = true;
          this.onToast("FRUIT +1");
        }
      } else if (isFire(entity)) {
        if (entity.fireState === "on" && intersects(bounds, fireFlameRect(entity))) this.die();
      } else if (entity.kind === "hazard" && entity.name === "Arrow") {
        if (!entity.arrowTriggered && intersects(bounds, entityRect(entity))) {
          entity.arrowTriggered = true;
          entity.arrowHitTime = 0.3;
          player.vy = 0;
          player.vx += (entity.direction?.[0] ?? 0) * 1350 * dt;
          player.vy += (entity.direction?.[1] ?? 0) * 1350 * dt;
          player.grounded = false;
          player.coyote = 0;
          player.ridingEntity = null;
          this.shakeCamera(0.12, 0.12);
        }
      } else if (isRockHead(entity)) {
        continue;
      } else if (entity.kind === "hazard" && (entity.name === "Spike Head"
        ? polygonIntersectsRect(SPIKE_HEAD_COLLIDER, entity.x, entity.y, bounds)
        : intersects(bounds, entityRect(entity)))) {
        this.die();
      }
    }
    const hazardLayers = this.getLayers(["Spikes", "Traps"]);
    for (const layer of hazardLayers) {
      const ox = layer.origin[0]; const oy = layer.origin[1];
      for (const [x, y] of layer.cells) {
        const hazard = { left: x + ox + 0.12, right: x + ox + 0.88, bottom: y + oy + 0.12, top: y + oy + 0.88 };
        if (intersects(bounds, hazard)) { this.die(); return; }
      }
    }
    if (changed) this.notify();
  }

  die() {
    const player = this.player;
    if (player.deadTimer > 0) return;
    player.deadTimer = 0.25;
    player.deathTargetY = player.y + 32 / 16;
    player.spawning = false;
    player.ridingEntity = null;
    player.wall = 0; player.wallX = null; player.wallEntity = null;
    player.wallJumpFrom = 0; player.wallJumpWallX = null;
    player.sink = 0;
    this.shakeCamera(0.14, 0.18);
    player.state = "hit";
    player.animTime = 0;
    player.vy = 8;
    player.vx = 0;
    this.onToast("TRY AGAIN");
  }

  respawn() {
    this.player.x = this.level.spawn[0];
    this.player.y = this.level.spawn[1] + 32 / 16;
    this.player.vx = 0; this.player.vy = 0;
    this.player.grounded = false; this.player.wall = 0; this.player.wallX = null; this.player.wallEntity = null;
    this.player.ridingEntity = null; this.player.contacts.clear();
    this.player.jumpsLeft = 2; this.player.coyote = 0;
    this.player.deadTimer = 0; this.player.state = "appearing";
    this.player.animTime = 0; this.player.sink = 0;
    this.player.wallJumpFrom = 0; this.player.wallJumpWallX = null;
    this.player.moveDustClock = 0; this.player.iceDustClock = 0;
    this.player.spawning = true;
    this.spawnRevealWait = 0;
  }

  update(dt, input) {
    if (this.paused || this.complete) return;
    this.transitionAge += dt;
    if (this.player.spawning) {
      const player = this.player;
      if (this.spawnRevealWait > 0) {
        this.spawnRevealWait = Math.max(0, this.spawnRevealWait - dt);
        return;
      }
      player.animTime += dt;
      if (player.state === "appearing") {
        if (player.animTime >= APPEARING.frames / APPEARING.fps) {
          player.state = "jump";
          player.animTime = 0;
        }
      } else {
        player.vy -= FIXED_GRAVITY * 8 * dt;
        player.y += player.vy * dt;
        // The authored start's bottom is the landing plane for the spawn drop.
        if (player.y + player.bottomOffset <= this.level.spawn[1] + player.bottomOffset) {
          player.y = this.level.spawn[1];
          player.vy = 0;
          player.grounded = true;
          player.coyote = 0.2;
          player.state = "idle";
          player.animTime = 0;
          player.spawning = false;
          this.notify();
        }
      }
      return;
    }
    this.elapsed += dt;
    this.updateEntityMotion(dt);
    this.updatePlayer(dt, input);
    this.updateParticles(dt);
  }
}
