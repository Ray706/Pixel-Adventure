import { APPEARING, DISAPPEARING, LEVEL_REVEAL_DURATION, getImage } from "./assets.js";

const BACKGROUNDS = ["Blue", "Brown", "Gray", "Green", "Pink", "Purple", "Yellow"];
const TRANSITION_TILE_COLOR = "#211f30";
const PLAYER_FRAME_BOUNDS = new WeakMap();
const LAYER_ORDER = new Map([
  ["Shadows", 0], ["Ground Shadows", 1], ["Blocks Shadows", 2], ["Platform Shadows", 3],
  ["Ground", 10], ["Sand", 11], ["Mud", 11], ["Ice", 11], ["Blocks", 14], ["Platforms", 16],
  ["Spikes", 20], ["Traps", 21]
]);

function opaqueFrameBounds(image, frameWidth, frameHeight, index) {
  if (!image) return { left: 0, right: frameWidth };
  let frames = PLAYER_FRAME_BOUNDS.get(image);
  if (!frames) {
    frames = new Map();
    PLAYER_FRAME_BOUNDS.set(image, frames);
  }
  if (frames.has(index)) return frames.get(index);
  let bounds = { left: 0, right: frameWidth };
  try {
    const canvas = document.createElement("canvas");
    canvas.width = frameWidth;
    canvas.height = frameHeight;
    const ctx = canvas.getContext("2d", { willReadFrequently: true });
    ctx.drawImage(image, index * frameWidth, 0, frameWidth, frameHeight, 0, 0, frameWidth, frameHeight);
    const pixels = ctx.getImageData(0, 0, frameWidth, frameHeight).data;
    let left = frameWidth;
    let right = 0;
    for (let y = 0; y < frameHeight; y++) {
      for (let x = 0; x < frameWidth; x++) {
        if (pixels[(y * frameWidth + x) * 4 + 3] === 0) continue;
        left = Math.min(left, x);
        right = Math.max(right, x + 1);
      }
    }
    if (right > left) bounds = { left, right };
  } catch {
    // Keep the full-frame bounds if canvas pixel inspection is unavailable.
  }
  frames.set(index, bounds);
  return bounds;
}

export function wallSlideVisualNudge(player, spriteSize) {
  if (!player.wall || player.state !== "wall") return 0;
  const fireWall = player.wallEntity?.kind === "hazard" && player.wallEntity.name.toLowerCase().includes("fire");
  return player.wall * (fireWall ? spriteSize / 8 : 4);
}

export function wallSpriteOffset(player, bounds = { left: 0, right: 32 }) {
  const slidingSide = player.wall;
  const side = slidingSide || (player.state === "wallJump" ? player.wallJumpFrom : 0);
  const wallX = slidingSide ? player.wallX : player.wallJumpWallX;
  if (!side || !Number.isFinite(wallX)) return 0;
  const occupiedEdge = side > 0 ? bounds.right / 16 - 1 : 1 - bounds.left / 16;
  const offset = wallX - (player.x + side * occupiedEdge);
  if (slidingSide) return offset;
  return side > 0 ? Math.min(0, offset) : Math.max(0, offset);
}

function round(value) {
  return Math.round(value);
}

function frame(ctx, image, frameWidth, frameHeight, index, x, y, width, height, flip = false, rotation = 0) {
  if (!image) return;
  const count = Math.max(1, Math.floor(image.width / frameWidth));
  const frameIndex = ((index % count) + count) % count;
  const sx = frameIndex * frameWidth;
  const centerX = round(x);
  const centerY = round(y);
  ctx.save();
  ctx.translate(centerX, centerY);
  if (rotation) ctx.rotate(rotation);
  if (flip) ctx.scale(-1, 1);
  ctx.drawImage(image, sx, 0, frameWidth, frameHeight, round(-width / 2), round(-height / 2), round(width), round(height));
  ctx.restore();
}

export class Renderer {
  constructor(canvas, levelData, images) {
    this.canvas = canvas;
    this.ctx = canvas.getContext("2d", { alpha: false });
    this.levelData = levelData;
    this.images = images;
    this.width = 0;
    this.height = 0;
    this.dpr = 1;
    this.scale = 1;
    this.camera = null;
    this.cameraLocked = false;
    this.motionPreference = window.matchMedia?.("(prefers-reduced-motion: reduce)");
    this.reducedMotion = Boolean(this.motionPreference?.matches);
    this.motionPreference?.addEventListener("change", (event) => { this.reducedMotion = event.matches; });
    this.spriteById = new Map(levelData.sprites.map((sprite, index) => [index, sprite]));
    this.backgroundUrl = Object.fromEntries(BACKGROUNDS.map((name) => [name, "Background/" + name + ".png"]));
  }

  animationTime(game) {
    return this.reducedMotion ? 0 : game.elapsed;
  }

  resize() {
    const rect = this.canvas.getBoundingClientRect();
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const width = Math.max(1, Math.round(rect.width));
    const height = Math.max(1, Math.round(rect.height));
    if (this.width === width && this.height === height && this.dpr === dpr) return;
    this.width = width;
    this.height = height;
    this.dpr = dpr;
    this.canvas.width = Math.round(width * dpr);
    this.canvas.height = Math.round(height * dpr);
    this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    this.ctx.imageSmoothingEnabled = false;
  }

  cameraTarget(game) {
    const player = game.player;
    const bounds = game.level.bounds;
    const halfWidth = this.width / this.scale / 2;
    const halfHeight = this.height / this.scale / 2;
    const left = bounds[0] - 0.5;
    const right = bounds[2] + 0.5;
    const bottom = bounds[1] - 0.5;
    const top = bounds[3] + 0.5;
    const clampView = (value, min, max, half) => max - min <= half * 2 ? (min + max) / 2 : Math.max(min + half, Math.min(max - half, value));
    return {
      x: clampView(player.x + player.facing * 0.7, left, right, halfWidth),
      y: clampView(player.y + 0.15, bottom, top, halfHeight)
    };
  }

  screenPoint(x, y) {
    return {
      x: (x - this.camera.x) * this.scale + this.width / 2,
      y: this.height / 2 - (y - this.camera.y) * this.scale
    };
  }

  drawBackground(game) {
    const ctx = this.ctx;
    const bgName = BACKGROUNDS[game.level.background % BACKGROUNDS.length];
    const image = getImage(this.images, this.backgroundUrl[bgName]);
    ctx.fillStyle = "#000";
    ctx.fillRect(0, 0, this.width, this.height);
    if (!image) return;
    const worldTileSize = 4;
    const worldLeft = this.camera.x - this.width / this.scale / 2;
    const worldTop = this.camera.y + this.height / this.scale / 2;
    const originX = Math.floor((worldLeft - this.camera.x * 0.08) / worldTileSize) * worldTileSize + this.camera.x * 0.08;
    const originY = Math.floor((worldTop + this.camera.y * 0.08) / worldTileSize) * worldTileSize - this.camera.y * 0.08;
    for (let x = originX; x < worldLeft + this.width / this.scale + worldTileSize * 2; x += worldTileSize) {
      for (let y = originY; y > worldTop - this.height / this.scale - worldTileSize * 2; y -= worldTileSize) {
        const topLeft = this.screenPoint(x, y + worldTileSize);
        const bottomRight = this.screenPoint(x + worldTileSize, y);
        const x0 = round(topLeft.x);
        const y0 = round(topLeft.y);
        const x1 = round(bottomRight.x);
        const y1 = round(bottomRight.y);
        ctx.globalAlpha = 0.86;
        ctx.drawImage(image, x0, y0, x1 - x0, y1 - y0);
      }
    }
    ctx.globalAlpha = 1;
  }

  drawWorldEdgeMatte(game) {
    const [left, bottom, right, top] = game.level.bounds;
    const padding = 2;
    const regions = [
      [left - padding, bottom - padding, left, top + padding],
      [right, bottom - padding, right + padding, top + padding],
      [left - padding, bottom - padding, right + padding, bottom],
      [left - padding, top, right + padding, top + padding]
    ];
    const ctx = this.ctx;
    ctx.fillStyle = TRANSITION_TILE_COLOR;
    for (const [worldLeft, worldBottom, worldRight, worldTop] of regions) {
      const topLeft = this.screenPoint(worldLeft, worldTop);
      const bottomRight = this.screenPoint(worldRight, worldBottom);
      const x = round(topLeft.x);
      const y = round(topLeft.y);
      ctx.fillRect(x, y, round(bottomRight.x) - x, round(bottomRight.y) - y);
    }
  }

  drawTileLayer(layer) {
    const ctx = this.ctx;
    const left = this.camera.x - this.width / this.scale / 2 - 2;
    const right = this.camera.x + this.width / this.scale / 2 + 2;
    const bottom = this.camera.y - this.height / this.scale / 2 - 2;
    const top = this.camera.y + this.height / this.scale / 2 + 2;
    const [ox, oy] = layer.origin;
    for (const [cellX, cellY, id] of layer.cells) {
      const wx = cellX + ox;
      const wy = cellY + oy;
      if (wx > right || wx + 1 < left || wy > top || wy + 1 < bottom || id < 0) continue;
      const sprite = this.spriteById.get(id);
      const image = sprite && getImage(this.images, sprite.src);
      if (!image || !sprite) continue;
      const [rx, ry, sw, sh] = sprite.rect;
      const topLeft = this.screenPoint(wx, wy + 1);
      const bottomRight = this.screenPoint(wx + 1, wy);
      const x0 = round(topLeft.x);
      const y0 = round(topLeft.y);
      const x1 = round(bottomRight.x);
      const y1 = round(bottomRight.y);
      const sourceY = image.height - ry - sh;
      ctx.drawImage(image, rx, sourceY, sw, sh, x0, y0, x1 - x0, y1 - y0);
    }
  }

  drawFruit(entity, game) {
    const time = this.animationTime(game);
    if (entity.collecting) {
      const image = getImage(this.images, "Items/Fruits/Collected.png");
      const point = this.screenPoint(entity.x, entity.y);
      const index = this.reducedMotion ? 0 : Math.floor((0.3 - entity.collectTime) * 20);
      frame(this.ctx, image, 32, 32, index, point.x, point.y, this.scale * 1.5, this.scale * 1.5);
      return;
    }
    const image = getImage(this.images, "Items/Fruits/" + entity.name + ".png");
    const bob = this.reducedMotion ? 0 : Math.sin(time * 3 + entity.phase) * 0.035;
    const point = this.screenPoint(entity.x, entity.y + bob);
    frame(this.ctx, image, 32, 32, Math.floor((time + entity.phase) * 8), point.x, point.y, this.scale * 1.5, this.scale * 1.5);
  }

  drawBox(entity, game) {
    const variant = entity.name === "Box2" || entity.name === "Box3" ? entity.name : "Box1";
    const point = this.screenPoint(entity.x, entity.y);
    if (entity.breaking) {
      const image = getImage(this.images, "Items/Boxes/" + variant + "/Break.png");
      const frameIndex = this.reducedMotion ? 0 : Math.floor((0.2 - entity.breakTime) * 20);
      frame(this.ctx, image, 28, 24, frameIndex, point.x, point.y, this.scale * 1.55, this.scale * 1.35);
      return;
    }
    const image = getImage(this.images, "Items/Boxes/" + variant + (entity.hitTime > 0 ? "/Hit (28x24).png" : "/Idle.png"));
    const hitFrame = entity.hitTime > 0 ? Math.floor((this.animationTime(game) * 15) % 3) : 0;
    frame(this.ctx, image, 28, 24, hitFrame, point.x, point.y, this.scale * 1.55, this.scale * 1.35);
  }

  drawSawTrack(entity) {
    if (entity.motion !== "oscillate" || !Array.isArray(entity.path) || entity.path.length < 2) return;
    const chain = getImage(this.images, "Traps/Spiked Ball/Chain.png");
    if (!chain) return;
    const [start, end] = entity.path;
    const dx = end[0] - start[0];
    const dy = end[1] - start[1];
    const distance = Math.hypot(dx, dy);
    const links = Math.ceil(distance / 0.5);
    const rotation = Math.atan2(-dy, dx);
    for (let i = 0; i < links; i++) {
      const t = (i + 0.5) / links;
      const point = this.screenPoint(start[0] + dx * t, start[1] + dy * t);
      this.ctx.save();
      this.ctx.translate(point.x, point.y);
      this.ctx.rotate(rotation);
      this.ctx.drawImage(chain, -this.scale * 0.25, -this.scale * 0.25, this.scale * 0.5, this.scale * 0.5);
      this.ctx.restore();
    }
  }

  drawHazard(entity, game) {
    const ctx = this.ctx;
    const name = entity.name.toLowerCase();
    const point = this.screenPoint(entity.x, entity.y);
    if (name.includes("fire")) {
      const imagePath = entity.fireHitTime > 0 ? "Traps/Fire/Hit (16x32).png" : entity.fireState === "on" ? "Traps/Fire/On (16x32).png" : "Traps/Fire/Off.png";
      const image = getImage(this.images, imagePath);
      const rotate = name.includes("left") ? -Math.PI / 2 : name.includes("right") ? Math.PI / 2 : name.includes("down") ? Math.PI : 0;
      const fireFrame = this.reducedMotion ? 0 : entity.fireHitTime > 0 ? Math.floor((0.3 - entity.fireHitTime) * 20) : Math.floor(this.animationTime(game) * 8);
      frame(ctx, image, 16, 32, fireFrame, point.x, point.y, this.scale, this.scale * 2, false, rotate);
    } else if (name.includes("spike head") || name.includes("rock head")) {
      const rockHead = name.includes("rock head");
      const folder = rockHead ? "Rock Head" : "Spike Head";
      const frameWidth = rockHead ? 42 : 54;
      const frameHeight = rockHead ? 42 : 52;
      const direction = entity.hitDirection || entity.direction || [0, 1];
      const hitDirection = direction[0] > 0 ? "Right" : direction[0] < 0 ? "Left" : direction[1] > 0 ? "Top" : "Bottom";
      const blinking = !this.reducedMotion && this.animationTime(game) % 5.2 > 4.86;
      const imagePath = entity.hitTime > 0
        ? "Traps/" + folder + "/" + hitDirection + " Hit (" + frameWidth + "x" + frameHeight + ").png"
        : blinking ? "Traps/" + folder + "/Blink (" + frameWidth + "x" + frameHeight + ").png" : "Traps/" + folder + "/Idle.png";
      const image = getImage(this.images, imagePath);
      const frameIndex = this.reducedMotion ? 0 : entity.hitTime > 0 ? Math.floor(entity.hitElapsed * 20) : blinking ? Math.floor((this.animationTime(game) % 5.2 - 4.86) * 30) : 0;
      const width = this.scale * 2.625;
      const height = this.scale * 2.625;
      frame(ctx, image, frameWidth, frameHeight, frameIndex, point.x, point.y, width, height);
    } else if (name.includes("spiked ball")) {
      const image = getImage(this.images, "Traps/Spiked Ball/Spiked Ball.png");
      if (image) {
        ctx.save(); ctx.translate(point.x, point.y); ctx.rotate(this.animationTime(game) * 2.5);
        ctx.drawImage(image, -this.scale * 0.875, -this.scale * 0.875, this.scale * 1.75, this.scale * 1.75); ctx.restore();
      }
    } else if (name.includes("arrow")) {
      const image = getImage(this.images, "Traps/Arrow/Idle (18x18).png");
      const hitFrame = entity.arrowHitTime > 0
        ? 5 + Math.min(4, Math.floor((0.3 - entity.arrowHitTime) / 0.06))
        : this.reducedMotion ? 0 : Math.floor(this.animationTime(game) * 7) % 5;
      frame(ctx, image, 18, 18, hitFrame, point.x, point.y, this.scale * 1.125, this.scale * 1.125);
    } else if (name.includes("spikes")) {
      const direction = name.includes("down") ? "Down" : name.includes("left") ? "Left" : name.includes("right") ? "Right" : "Up";
      const image = getImage(this.images, "Traps/Spikes/Spikes" + direction + ".png");
      if (image) ctx.drawImage(image, round(point.x - this.scale / 2), round(point.y - this.scale / 2), round(this.scale), round(this.scale));
    } else if (name.includes("saw")) {
      this.drawSawTrack(entity);
      const image = getImage(this.images, "Traps/Saw/On (38x38).png");
      frame(ctx, image, 38, 38, Math.floor(this.animationTime(game) * 12), point.x, point.y, this.scale * 2.375, this.scale * 2.375);
    }
  }

  drawCheckpoint(entity, game) {
    const time = this.animationTime(game);
    let path;
    let index = 0;
    let duration = 0;
    if (entity.name === "Start") {
      path = entity.triggerTime > 0 ? "Items/Checkpoints/Start/Start (Moving) (64x64).png" : "Items/Checkpoints/Start/Start (Idle).png";
      duration = 0.85;
    } else if (entity.name === "End") {
      path = entity.triggerTime > 0 ? "Items/Checkpoints/End/End (Pressed) (64x64).png" : "Items/Checkpoints/End/End (Idle).png";
      duration = 0.4;
    } else if (entity.triggerTime > 0) {
      path = "Items/Checkpoints/Checkpoint/Checkpoint (Flag Out) (64x64).png";
      duration = 1.3;
    } else if (entity.flagged) {
      path = "Items/Checkpoints/Checkpoint/Checkpoint (Flag Idle)(64x64).png";
      index = this.reducedMotion ? 0 : Math.floor(time * 20) % 10;
    } else {
      path = "Items/Checkpoints/Checkpoint/Checkpoint (No Flag).png";
    }
    if (entity.triggerTime > 0) index = this.reducedMotion ? 0 : Math.floor((duration - entity.triggerTime) * 20);
    const point = this.screenPoint(entity.x, entity.y);
    frame(this.ctx, getImage(this.images, path), 64, 64, index, point.x, point.y, this.scale * 4, this.scale * 4);
  }

  drawEntity(entity, game) {
    if (!entity.active && !entity.collecting && !entity.breaking) return;
    if (entity.kind === "fruit") return this.drawFruit(entity, game);
    if (entity.kind === "box") return this.drawBox(entity, game);
    if (entity.kind === "checkpoint") return this.drawCheckpoint(entity, game);
    const point = this.screenPoint(entity.x, entity.y);
    if (entity.kind === "fallingPlatform") {
      const image = getImage(this.images, entity.falling ? "Traps/Falling Platforms/Off.png" : "Traps/Falling Platforms/On (32x10).png");
      frame(this.ctx, image, 32, 10, Math.floor(this.animationTime(game) * 8), point.x, point.y, this.scale * 2, this.scale * 0.625);
    } else if (entity.kind === "platform") {
      const variant = entity.style === "grey" ? "Grey" : "Brown";
      const image = getImage(this.images, "Traps/Platforms/" + variant + " On (32x8).png");
      frame(this.ctx, image, 32, 8, Math.floor(this.animationTime(game) * 8), point.x, point.y, this.scale * 2, this.scale * 0.5);
    } else if (entity.kind === "fan") {
      const path = entity.fanOn ? "Traps/Fan/On (24x8).png" : "Traps/Fan/Off.png";
      const image = getImage(this.images, path);
      frame(this.ctx, image, 24, 8, entity.fanOn ? Math.floor(this.animationTime(game) * 8) : 0, point.x, point.y, this.scale * 1.5, this.scale * 0.5);
    } else if (entity.kind === "trampoline") {
      const jumping = entity.bounceTime > 0;
      const image = getImage(this.images, jumping ? "Traps/Trampoline/Jump (28x28).png" : "Traps/Trampoline/Idle.png");
      frame(this.ctx, image, 28, 28, jumping ? Math.floor(this.animationTime(game) * 16) : 0, point.x, point.y, this.scale * 1.75, this.scale * 1.75);
    } else if (entity.kind === "hazard") {
      if (entity.pendulum) this.drawPendulum(entity);
      else this.drawHazard(entity, game);
    }
  }

  drawPendulum(entity) {
    const angle = entity.pendulum.angle;
    const ball = this.screenPoint(entity.ballX, entity.ballY);
    const chain = getImage(this.images, "Traps/Spiked Ball/Chain.png");
    const ballImage = getImage(this.images, "Traps/Spiked Ball/Spiked Ball.png");
    if (chain) {
      const step = 0.5;
      const links = Math.ceil(entity.pendulum.length / step);
      for (let i = 0; i < links; i++) {
        const t = Math.min(0.97, (i * step + step / 2) / entity.pendulum.length);
        const point = this.screenPoint(entity.x + (entity.ballX - entity.x) * t, entity.y + (entity.ballY - entity.y) * t);
        this.ctx.save();
        this.ctx.translate(point.x, point.y);
        this.ctx.rotate(-angle);
        this.ctx.drawImage(chain, -this.scale * 0.25, -this.scale * 0.25, this.scale * 0.5, this.scale * 0.5);
        this.ctx.restore();
      }
    }
    if (ballImage) this.ctx.drawImage(ballImage, round(ball.x - this.scale * 0.875), round(ball.y - this.scale * 0.875), round(this.scale * 1.75), round(this.scale * 1.75));
  }

  drawParticles(game) {
    if (this.reducedMotion || game.particles.length === 0) return;
    const ctx = this.ctx;
    for (const particle of game.particles) {
      const point = this.screenPoint(particle.x, particle.y);
      const size = Math.max(1, round(particle.size * this.scale));
      const texture = particle.sprite && getImage(this.images, particle.sprite);
      if (particle.confetti && texture) {
        frame(ctx, texture, 16, 16, particle.spriteFrame, point.x, point.y, size, size, false, particle.rotation);
      } else if (particle.debris && texture) {
        const flashing = particle.flashStart !== null && particle.age >= particle.flashStart;
        const flashPhase = flashing ? Math.floor((particle.age - particle.flashStart) * 28) % 2 : 0;
        ctx.globalAlpha = flashing && flashPhase ? 0.18 : 1;
        frame(ctx, texture, 28, 24, particle.spriteFrame, point.x, point.y, size * 1.15, size);
      } else {
        ctx.globalAlpha = Math.max(0, 1 - particle.age / particle.life);
        if (particle.texture && texture) {
          ctx.drawImage(texture, round(point.x - size / 2), round(point.y - size / 2), size, size);
        } else {
          ctx.fillStyle = particle.color;
          ctx.fillRect(round(point.x - size / 2), round(point.y - size / 2), size, size);
        }
      }
    }
    ctx.globalAlpha = 1;
  }

  drawPlayer(game) {
    const player = game.player;
    if (player.state === "deathWait") return;
    if (player.state === "appearing" || player.state === "disappearing") {
      const animation = player.state === "appearing" ? APPEARING : DISAPPEARING;
      const point = this.screenPoint(player.x, player.y);
      const index = Math.min(animation.frames - 1, Math.floor(player.animTime * animation.fps));
      frame(this.ctx, getImage(this.images, animation.path), 96, 96, index, point.x, point.y, this.scale * 6, this.scale * 6);
      return;
    }
    const shadow = this.screenPoint(player.x, player.y + player.bottomOffset + 0.02);
    this.ctx.fillStyle = "rgba(20, 31, 42, 0.24)";
    this.ctx.beginPath();
    this.ctx.ellipse(shadow.x, shadow.y, this.scale * 0.36, this.scale * 0.11, 0, 0, Math.PI * 2);
    this.ctx.fill();

    let state = player.state;
    if (state === "run") state = "Run";
    else if (state === "doubleJump") state = "Double Jump";
    else if (state === "wallJump" || state === "wall") state = "Wall Jump";
    else if (state === "jump") state = "Jump";
    else if (state === "fall") state = "Fall";
    else if (state === "hit") state = "Hit";
    else state = "Idle";
    const image = getImage(this.images, "Main Characters/" + player.skin + "/" + state + " (32x32).png");
    const frameRate = state === "Run" ? 13 : state === "Idle" ? 7 : state === "Hit" ? 8 : 9;
    const frameIndex = this.reducedMotion ? 0 : Math.floor(player.animTime * frameRate);
    const spriteSize = this.scale * 2;
    const sourceBounds = opaqueFrameBounds(image, 32, 32, frameIndex % Math.max(1, Math.floor((image?.width || 32) / 32)));
    const occupiedBounds = player.facing < 0
      ? { left: 32 - sourceBounds.right, right: 32 - sourceBounds.left }
      : sourceBounds;
    const point = this.screenPoint(player.x + wallSpriteOffset(player, occupiedBounds), player.y - (player.sink || 0));
    const side = player.wall || (player.state === "wallJump" ? player.wallJumpFrom : 0);
    const wallX = player.wall ? player.wallX : player.wallJumpWallX;
    if (side && Number.isFinite(wallX)) {
      const wallPixel = round(this.screenPoint(wallX, player.y).x);
      const edgeOffset = round(-spriteSize / 2 + occupiedBounds[side > 0 ? "right" : "left"] / 32 * spriteSize);
      const occupiedEdge = round(point.x) + edgeOffset;
      const correction = wallPixel - occupiedEdge;
      if (player.wall || (side > 0 ? correction < 0 : correction > 0)) point.x += correction;
    }
    point.x += wallSlideVisualNudge(player, spriteSize);
    frame(this.ctx, image, 32, 32, frameIndex, point.x, point.y, spriteSize, spriteSize, player.facing < 0);
  }

  drawTransition(game) {
    if (this.reducedMotion) return;
    const image = getImage(this.images, "Other/Transition.png");
    if (!image) return;
    const cellSize = this.scale * 44 / 16;
    const columns = Math.ceil(this.width / cellSize);
    const rows = Math.ceil(this.height / cellSize);
    const coverDuration = 0.3;
    const shrinkDuration = LEVEL_REVEAL_DURATION - coverDuration;
    if (game.transitionAge >= coverDuration + shrinkDuration) return;
    const left = (this.width - columns * cellSize) / 2;
    const top = (this.height - rows * cellSize) / 2;
    const progress = Math.max(0, (game.transitionAge - coverDuration) / shrinkDuration);
    const size = round(cellSize * 5 * (1 - progress));
    if (size < 1) return;
    const ctx = this.ctx;
    ctx.save();
    ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    ctx.imageSmoothingEnabled = false;
    for (let column = 0; column < columns; column++) {
      for (let row = 0; row < rows; row++) {
        const x = left + (column + 0.5) * cellSize;
        const y = top + (row + 0.5) * cellSize;
        ctx.drawImage(image, round(x - size / 2), round(y - size / 2), size, size);
      }
    }
    ctx.restore();
  }

  draw(game, dt = 1 / 60) {
    this.resize();
    this.scale = this.height / 14.5;
    const target = this.cameraTarget(game);
    if (!this.camera) this.camera = { ...target };
    if (!this.cameraLocked) {
      const ease = this.reducedMotion ? 1 : 1 - Math.exp(-Math.max(0, dt) * 5.5);
      this.camera.x += (target.x - this.camera.x) * ease;
      this.camera.y += (target.y - this.camera.y) * ease;
    }
    const ctx = this.ctx;
    ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    ctx.imageSmoothingEnabled = false;
    ctx.save();
    if (!this.reducedMotion && game.shakeTime > 0) {
      const amount = game.shakeMagnitude * (game.shakeTime / game.shakeDuration) * this.scale;
      const phase = game.elapsed * 91;
      ctx.translate(Math.sin(phase) * amount, Math.cos(phase * 1.37) * amount);
    }
    this.drawBackground(game);
    this.drawWorldEdgeMatte(game);
    for (const entity of game.entities) {
      if (entity.kind === "hazard" && entity.name === "Saw") this.drawEntity(entity, game);
    }
    const layers = [...game.level.layers].sort((a, b) => (LAYER_ORDER.get(a.name) ?? 12) - (LAYER_ORDER.get(b.name) ?? 12));
    const foregroundSurfaces = layers.filter((layer) => layer.name === "Sand" || layer.name === "Mud");
    for (const layer of layers) if (!foregroundSurfaces.includes(layer)) this.drawTileLayer(layer);
    for (const entity of game.entities) {
      if (entity.kind !== "hazard" || entity.name !== "Saw") this.drawEntity(entity, game);
    }
    this.drawPlayer(game);
    for (const layer of foregroundSurfaces) this.drawTileLayer(layer);
    this.drawParticles(game);
    this.drawTransition(game);
    ctx.restore();
  }
}
