const CONTROL_KEYS = new Map([
  ["ArrowLeft", "left"], ["KeyA", "left"],
  ["ArrowRight", "right"], ["KeyD", "right"],
  ["ArrowUp", "jump"], ["KeyW", "jump"], ["Space", "jump"]
]);

export class InputController {
  constructor(root, onPause) {
    this.keys = new Set();
    this.pointerKeys = new Map();
    this.jumpPressed = false;
    this.onPause = onPause;
    const isFocusedControl = (event) => event.target?.closest?.("button, select, input, textarea, [contenteditable='true']");

    window.addEventListener("keydown", (event) => {
      const focusedControl = isFocusedControl(event);
      if (event.code === "Escape" || event.code === "KeyP") {
        event.preventDefault();
        if (!event.repeat) this.onPause();
        return;
      }
      if (event.code === "KeyR") {
        if (focusedControl) return;
        event.preventDefault();
        root.dispatchEvent(new CustomEvent("game-restart"));
        return;
      }
      const key = CONTROL_KEYS.get(event.code);
      if (!key || focusedControl) return;
      event.preventDefault();
      const wasHeld = this.isHeld(key);
      this.keys.add(event.code);
      if (key === "jump" && !wasHeld) this.jumpPressed = true;
    });

    window.addEventListener("keyup", (event) => {
      const key = CONTROL_KEYS.get(event.code);
      if (!key) return;
      if (!isFocusedControl(event)) event.preventDefault();
      this.keys.delete(event.code);
    });

    const releasePointer = (event) => this.pointerKeys.delete(event.pointerId);
    window.addEventListener("pointerup", releasePointer, true);
    window.addEventListener("pointercancel", releasePointer, true);
    window.addEventListener("lostpointercapture", releasePointer, true);
    window.addEventListener("blur", () => this.clear());
    window.addEventListener("pagehide", () => this.clear());
    if (typeof document !== "undefined") document.addEventListener("visibilitychange", () => { if (document.hidden) this.clear(); });

    for (const button of root.querySelectorAll("[data-control]")) {
      const control = button.dataset.control;
      button.addEventListener("pointerdown", (event) => {
        event.preventDefault();
        const wasHeld = this.isHeld(control);
        this.pointerKeys.set(event.pointerId, control);
        try { button.setPointerCapture(event.pointerId); } catch { /* Global release listeners still clear this pointer. */ }
        if (control === "jump" && !wasHeld) this.jumpPressed = true;
      });
      button.addEventListener("pointerup", releasePointer);
      button.addEventListener("pointercancel", releasePointer);
      button.addEventListener("lostpointercapture", releasePointer);
      button.addEventListener("contextmenu", (event) => event.preventDefault());
    }
  }

  clear() {
    this.keys.clear();
    this.pointerKeys.clear();
    this.jumpPressed = false;
  }

  isHeld(control) {
    return [...this.keys].some((code) => CONTROL_KEYS.get(code) === control) || [...this.pointerKeys.values()].includes(control);
  }

  read() {
    const held = new Set([...this.keys].map((code) => CONTROL_KEYS.get(code)).filter(Boolean));
    for (const control of this.pointerKeys.values()) held.add(control);
    const move = Number(held.has("right")) - Number(held.has("left"));
    const frame = { move, jumpPressed: this.jumpPressed };
    this.jumpPressed = false;
    return frame;
  }
}
