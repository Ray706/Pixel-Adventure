# Pixel Adventure Web Review

Date: 2026-10-21

The first two iteration sections preserve findings as they stood at that time; Iteration 3 reflects the user's later direction and supersedes earlier R1 status. The Upstream Source Audit Follow-Up below supersedes earlier statements that Unity source files were unavailable.

## Iteration 1/3

### Summary

The static conversion loads all 18 demo-level recreations, preserves 15,775 tile placements and 157 sprite crop records, and now has direct world selection, reduced-motion rendering, spawn-only respawn, and a dependency-free regression suite. Runtime assets were reduced from 274 to 71 PNGs without missing data or renderer paths. The official Pixel Frog asset page identifies the artwork as CC0 1.0, but this does not grant rights to the upstream Unity scene layouts.

### Findings

#### P1 - Redistribution rights for extracted scene layouts remain unverified

- Pixel Frog's official asset page (https://pixelfrog-assets.itch.io/pixel-adventure-1, checked 2026-10-21) identifies the art pack as CC0 1.0 Universal. ATTRIBUTION.md now records that scope.
- The upstream Unity repository has no root license covering its scene layouts or other project-specific data. data/levels.json contains extracted layouts from those scenes. Do not publish those layouts until permission is verified or the layouts are replaced.

#### P1 - Tile collision remains a full-cell approximation

- src/game.js lines 164-177 converts Ground and Blocks tile cells into unit AABBs. The converted bundle has tile IDs and placements but no Unity collider polygons/composite-collider metadata, so edge and corner geometry cannot be reconstructed exactly from the available files.
- Existing and new tests cover collision primitives, not terrain-shape parity across all 18 worlds. Avoid inventing shape data; obtain the source collider metadata before improving fidelity.

#### P1 - Several trap routes and trigger timings are not recoverable from converted data

- data/levels.json stores trap kind/name and x/y placement, not serialized paths or timing values. src/game.js lines 223-272 therefore uses approximations for fan cycling, falling platforms, and fire arming; Spike Head / Rock Head routes, moving-saw paths, and projectile timing are not represented.
- This can change timing and reachable routes on trap-heavy worlds. Recover the Unity prefab/scene properties before attempting a faithful port.

#### P2 - Space is intercepted while native controls have focus

- src/input.js lines 12-27 handles game keys at window and prevents their defaults without checking the focused element. In an interactive browser check, ArrowDown successfully selected the next world, but Space on the focused Resume button did not activate it; the pause dialog remained open. The same handler can suppress Space activation on other HUD buttons.
- Keep gameplay keys from consuming native keyboard interaction while a button or editable/select control is focused. Add a regression test for focused controls and for clearing any queued jump on window blur.

### Resolved In This Pass

- Verified and documented CC0 licensing for Pixel Frog artwork; upstream scene-layout licensing remains open.
- Removed checkpoint code that had no placed instances in the 18 scenes; respawn now consistently uses the authored world spawn.
- Added an 18-option world selector, canvas-level reduced-motion handling, and regression tests for collision primitives, keyboard/touch input state, collection, boxes, hazards, respawn, navigation, and saved resume.
- Removed 203 unused PNGs and unused loader requests, retaining all 71 referenced runtime images.

### Validation

- node --experimental-default-type=module tests/run.js passes, including existence checks for runtime asset paths.
- Data integrity check: 18 levels, 15,775 tile placements, 157 sprite crop records; all referenced sprite sheets exist.
- websim_check_page loads the page with no application JavaScript errors or failed project asset requests. It reports one injected-host postMessage origin warning, unrelated to project code.
- Interactive browser check: world selection by ArrowDown/Enter worked; Space on the focused Resume button failed as described above. The browser was closed after the check.

### Enhancement Opportunities

- R1 - Verify permission to redistribute the extracted Unity scene layouts, or replace them with newly authored layouts.
- R2 - Obtain and apply original tile collider shapes/composite collision metadata; validate edge/corner traversal across all worlds.
- R3 - Recover original trap routes, movement timing, and trigger/projectile properties; port and validate representative trap-heavy worlds.
- R9 - Preserve native keyboard activation for focused HUD controls and clear stale jump input on blur; add regression coverage.

Overall, the core conversion is stable and its current remaining gameplay gaps are bounded by missing upstream metadata. Scene-data redistribution rights remain the release gate; the focused-button keyboard issue was fixed in iteration 2.

## Iteration 2/3

### Results

- R9 is implemented in src/input.js: gameplay movement/restart keys are ignored when a native button, select, input, textarea, or contenteditable control has focus. Keyup preserves native defaults in those controls, while Escape/P still operate globally. Window blur now clears queued jump presses as well as held keys/pointers.
- tests/run.js now verifies select ArrowDown is not consumed, focused-button Space keydown/keyup remain native, and blur discards a pending jump. The full regression command passes.
- The post-fix websim_check_page check reports no application errors or failed project requests; only the injected-host origin warning remains. The earlier real-browser reproduction was not repeated after the code edit, so native activation is covered by the focused-target regression test but not a second interactive browser pass.
- R1-R3 remain blocked after rechecking the workspace: no Unity scene/prefab/asset/meta files are present, and serialized entity fields are only kind, label, name, x, and y. No safe source-derived remediation is available in this checkout.

### Iteration 2 Findings

No new code or data-integrity findings were found. The unresolved release gate (R1), collision fidelity limit (R2), and trap route fidelity limit (R3) remain the only open review actions.

### Enhancement Opportunities

- R1 - Verify permission to redistribute extracted Unity scene layouts or replace them.
- R2 - Obtain original collider-shape metadata and validate terrain edge/corner movement.
- R3 - Obtain serialized trap route/timing/trigger data and port it faithfully.

## Iteration 3/3

### Final Audit

- A final source-rights check found no upstream main-branch LICENSE or LICENSE.md at the conventional repository root (both raw URLs returned 404). This does not establish permission for recreated demo layouts. The official Pixel Frog pack's CC0 1.0 status applies to its art only; the user's later retention direction and release-only follow-up are recorded below.
- A final workspace search found no Unity scene, prefab, asset, or meta files. The converted entity records still contain only kind, label, name, x, and y. R2 and R3 therefore remain blocked by absent collider and movement metadata; inventing data would reduce fidelity rather than improve it.
- R1 is complete for current project scope per user direction: retain the recreated demo layouts. This is not a rights determination; R18 is the release-only policy/permission check.
- R4-R11 and R16-R17 are complete. The final pass disabled text selection/callouts, added persistent guide visibility, and implemented a toolbelt editor for the 27 currently supported runtime entity templates with pan, placement, erase/undo, validation, local custom saves, and JSON export. All 157 sprite crop records resolve to existing files.
- The renderer draws no debug/path tracking strokes; the keyboard hint is the only on-canvas guide. R11 hides that hint without suppressing authored shadows or other level art.
- Interactive verification after these edits confirmed Space activates the focused Resume button, and unchecking Show on-screen guides hides the keyboard hint only. The editor palette opened; selecting Apple and tapping the canvas incremented the entity count, and Undo restored it. The browser session ended without saving, so R19 remains for browser verification of persistence and file download. The world selector and touch-input simulation remain functional; authored shadows and gameplay are unchanged.
- The last successful websim_check_page before the final editor-state/feedback polish reported no project JavaScript errors or failed requests. A final repeat was refused by the three-check per-turn cap; node --experimental-default-type=module --check src/main.js and the Node regression suite pass. The known host-injected postMessage warning is unrelated to the app.
- At the time of this final audit, R12-R15 were unverified because the workspace lacked Unity scripts/prefabs and the converted levels had no enemy, projectile, or powerup entities. The GitHub source audit below supersedes this status. R18 tracks the release-only policy/permission check for retaining the demo layouts.

### Final Assessment

The implementation and runtime bundle are stable for the source data available at this point in Iteration 3. Per user direction, keep the recreated demo layouts in the project; assess platform policy and seek permission only if required before public release (R18). The source metadata and system audit were updated in the follow-up below. Focused controls, guide visibility, editor placement, undo, and custom-save/export model validation were exercised; the Save & Exit and downloaded-file browser flow remains unverified (R19). No unverified enemy/projectile/powerup behavior was fabricated.

### Iteration 3 Enhancement Opportunities (Before Upstream Source Audit Follow-Up)

- R2 - Obtain original tile collider shapes and composite-collider metadata.
- R20 - Implement source-verified tile-shape/composite collision.
- R21 - Add terrain edge/corner regression tests across the campaign.
- R3 - Inventory original trap route/timing/trigger metadata.
- R22 - Port Spike Head/Rock Head routes and collisions.
- R23 - Port arrow/projectile spawning, direction, timing, and collision.
- R24 - Port moving-saw/pendulum routes.
- R12 - Audit complete Unity source for enemy, projectile, and powerup behavior, sprites, dependencies, and rights.
- R13 - Port source-verified enemy behaviors and required sprites.
- R14 - Port source-verified projectiles and collisions.
- R15 - Port source-verified powerups and effects.
- R18 - Before public/WebSim release, check platform policy for recreated demo layouts and seek owner permission if required; retain the layouts in the meantime.
- R19 - Browser-verify custom save/reload and JSON download flows without changing campaign data.

## Upstream Source Audit Follow-Up (2026-10-21)

### Source Findings

- Audited the current GitHub main branch read-only: 19 Unity scenes (BaseLevel plus Level1-Level18), C# scripts, prefabs, terrain tile assets, and serialized trap data are present upstream. No Unity source files were copied into this web project.
- There are no enemy behavior scripts, enemy prefabs, or enemy instances in the 18 level scenes. Assets/Scripts/Entities/Enemeis.meta is metadata only. Enemy and bullet artwork exists under Assets/Sprites/Enemies, including Bee, Plant, and Trunk bullet sprites, but the art does not define runtime behavior.
- Player combat is scaffolding rather than an implemented attack system: Combat.Damage only logs, Core leaves Combat initialization/updates commented out, and Player attack-state wiring/transitions are commented out. No projectile spawning or movement implementation was found.
- There are no powerup scripts or prefabs. Fruit.cs implements collection; it is not a powerup.
- Level18 has three Checkpoint.cs instances, but the script only plays a one-shot Trigger animation on collision/contact; it never changes the player spawn or persists progress. The web runtime's spawn-based respawn remains source-consistent; the old no-checkpoints wording meant no functional checkpoint-save system.

### Verified Trap Data

- Assets/Scripts/Data/Concrete Data/TrapsData.asset overrides the script defaults: bounce velocity 20; Box1/2/3 lives 1/5/5; explosion velocity 100; trampoline force 37; fan toggle interval 5 seconds; ArrowForce 1350; platform speed 0.1 and wait 1 second; falling-platform wait 0.5 seconds; MovingSaw speed 5; fire delay/on duration 1/2 seconds; RockHead/SpikeHead speeds 0.4/0.35.
- Scene instances identify the trap families: Level3 has two trampolines; Level5 has three Fan components; Level6 has six Arrow prefabs; Level7 has two moving Platform and one StaticPlatform; Level8 has four Falling Platforms; Level9 has a static Spikes component; Level10 has two MovingSaw and two Saw; Level11 has 39 Fire prefabs (9 left, 7 right, 23 up); Level12 has four Rock Heads; Level13 has four Spike Heads; Level14 has four Spiked Balls.
- Arrow.cs does not spawn or move an arrow. The prefab is a trigger with direction (0, 1); on player entry it zeros vertical velocity and applies direction * ArrowForce, then plays the hit animation. Level6 instances retain the prefab's upward direction. The browser currently treats Arrow as a lethal generic hazard; R23 tracks this parity correction.
- MovingSaw routes are serialized as four child transforms of their parent; its script traverses those waypoints at sawSpeed / 100 per physics step. Level10's two Saw components serialize endpoint pairs (0, -2.5) to (0, 2.5) and (3.5, 0) to (-3.5, 0), each with speed 1. Spike Head/Rock Head movement settings are on their prefabs and the placed instances are in Level13/12 respectively.
- R3's inventory is complete; R2/R20/R21, R22, and R24 are implemented, while R23's Arrow interaction remains open. The used terrain and Sand/Mud/Ice tile IDs map to Unity physics shapes or actual sprite-alpha fallback masks in data/levels.json; adjacent masks resolve as a continuous collision union.
- The upstream repository has no root license declaring rights for its project-specific code or scene data; the README credits Bardent for core/state-machine logic. This audit does not establish reuse rights. Pixel Frog's CC0 statement applies to artwork only, and R18 remains the release-only layout policy/permission check.

### Updated Assessment

The enemy/projectile/powerup behavior gap is bounded: there are no such implemented systems to port, though enemy artwork is present. Trap metadata is now recoverable from the upstream source, so route and interaction parity can proceed without guessing. Level18's checkpoint components are animation-only, so spawn-based respawn remains appropriate. R2, R20, R21, R22, and R24 are now implemented; R23 remains open.

## Level10 Saw and Ride-Collision Follow-Up (2026-10-21)

- Ported all four Level10 saws. The two MovingSaw blades share the world-space loop [[4, 1], [4, -3], [-3, -3], [-3, 1]], starting at waypoints 0 and 2, and move at 2.5 units/second as configured by the source's sawSpeed and 50Hz FixedUpdate.
- Ported the two Saw endpoint oscillators from the scene and Saw.cs: vertical from (11.1, 0.98) to (11.1, 5.98), horizontal from (20, -0.3) to (13, -0.3), both at speed 1. Their route metadata is preserved when campaign entities are serialized by the editor. Saws render before terrain tilemaps, matching the Unity sorting and allowing terrain to mask the blades for their half-submerged appearance.
- Rock Head rider displacement now goes through moveBody with player velocity, so wall and ceiling contacts resolve before player position is committed. A 1e-9 overlap tolerance prevents floating-point edge contact from turning into a false side collision. Riders lose support and fall when the moving head leaves them.
- Added regression coverage for both saw motion types, source route coordinates, editor serialization, wall/ceiling clipping, and stepping off moving support. `node --experimental-default-type=module tests/run.js` passes.
- `websim_check_page` reports no project JavaScript errors or failed requests. The only console warning is the existing host-injected postMessage origin mismatch.

## Sprite Collision and Flush Geometry Follow-Up (2026-10-22)

- Added 16x16 collision masks for all used Terrain and Sand/Mud/Ice sprites in data/levels.json. The masks follow each PNG's pixel alpha where Unity generates fallback physics shapes and preserve every used explicit importer physics polygon as pixel rows. This leaves transparent pixels non-solid and composes adjacent tile shapes by their exact union.
- Moving-head terrain motion uses swept polygon collision against those sprite-derived shapes. Rock Head uses its source BoxCollider2D 2x2; Spike Head uses its serialized PolygonCollider2D points. Player movement retains its source BoxCollider2D 1.4x1.5 at offset y=-0.25.
- A rider's own moving collider is excluded from its self-collision step; after terrain resolution the player's foot is snapped to the source collider top only while horizontal support remains. This prevents motion jitter/fall-through and still detaches the rider at an edge or blocked ceiling.
- Tile rendering now snaps shared tile edges to identical device pixels, preventing camera-scaled fractional rounding gaps. Wall slide/jump rendering offsets the actual 2-unit player frame to the contacted sprite boundary. Spike Head frames render at the prefab's authored 2.625-unit size.
- Added sprite-shape, wall/ceiling, rider stability, wall alignment, and per-world collision regressions. `node --experimental-default-type=module tests/run.js` passes. The final page check loads without application errors; only the known host postMessage warning remains.

## Level14 and Background Follow-Up (2026-10-22)

- Corrected three Level14 pendulum anchors that had been taken from child chain transforms instead of the Unity prefab parent transforms: Spiked Ball (3) at (14.5, -3.5), Spiked Ball (1) at (4.5, 5.5), and Spiked Ball (2) at (15.5, 2.5). Their lengths, rotations, and swing modes were already source-correct. Added exact anchor regression coverage.
- Background tiles now draw from their world-space top edge and cover the full vertical viewport; the canvas and stage use black as the full-frame backing.
- Wall-slide and wall-jump sprites now correct their rendered edge in screen pixels against the source wall plane, including while sliding with no horizontal input.
- Regression suite passes; websim_check_page loads with no project errors or failed requests. The remaining console warning is injected by the host.

## Level10 and Campaign Audit Follow-Up (2026-10-22)

- Added repeated Chain sprites across the horizontal and vertical Level10 endpoint-saw paths; the saw sprites render over the chains and terrain continues masking both as before.
- Audited entity kinds and source interactions across all 18 campaign levels. The outstanding Level6 Arrow mismatch was fixed: six up-facing triggers now zero vertical velocity, apply the source force for one simulation step, play the hit animation, and disappear without damaging the player.
- Restored Level18's omitted Start, End, and Checkpoint markers at their source positions, with the source collider bounds and one-shot animations. The checkpoint ends flagged but does not change spawn or saved progress, matching Checkpoint.cs.
- Added regression coverage for Arrow force/retrigger/removal and all three Level18 markers. Moving Rock Heads now also damage on leading-face impacts from any cardinal direction while top riders remain safe. `node tests/run.js` passes. Remaining open work is editor save/export browser verification (R19) and release-only layout policy/permission review (R18), not missing campaign gameplay.


